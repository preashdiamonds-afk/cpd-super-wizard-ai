# C.P.D SUPER WIZARD AI V7.1 Premium Upgrade

## Included
- Premium dark/futuristic gradient command-center background and upgraded gold/cyan/purple visual system.
- App access password: `200825` (app UI lock only; it is not an Exness credential).
- Spoken launch greeting: **Welcome, Captain Preash Diamond** using Android Text-to-Speech.
- Demo and Live account modes are separate in the UI.
- Separate saved Demo and Live login/server/password fields.
- Exact account-mode verification: the bridge must report DEMO for Demo mode or REAL for Live mode before a command is queued.
- Live execution is available behind an explicit in-app Enable Live Execution control.
- The MT5 EA also checks whether the account is REAL/DEMO and whether its Live inputs permit execution.
- Normal Auto confidence threshold changed to 70 CPD confluence points, with the score displayed on a 70–99 scale. This is a setup-evidence score, not a probability of profit.
- Normal mode uses balanced filtering: HTF alignment, structure, liquidity sweep, displacement, M5 trigger and risk checks remain; pattern/S&R are evidence rather than mandatory final gates.
- Normal Auto repeats scanning every 30 seconds while enabled and avoids opening a duplicate position for the same symbol when it can read the MT5 bridge.
- Normal signal direction (BUY/SELL) is passed through the bridge correctly; the earlier bridge always-buy issue is fixed.
- C.P.D Scanner has a **COPY C.P.D SCANNER SIGNAL** button.
- C.P.D Academy contains all 10 requested lessons, written in simple English with built-in illustrative chart diagrams.
- If market/MT5 data is unavailable, the app opens normally but scanner/auto execution remains unavailable rather than inventing data.

## Connection reality
The Android app does not directly log into Exness MT5 with a retail password. The supported architecture remains:

Android C.P.D app -> HTTPS CPD Bridge -> MT5 terminal + C.P.D EA -> Exness.

The password fields are retained as local account setup references. The actual MT5 terminal/EA performs the broker authentication.

## Live safety
Live mode is a real-money capability. The app requires an explicit Live enable action and checks the actual terminal-reported mode. The bridge rejects Demo/Live mode mismatches. Review volume, SL, TP and account mode before enabling live execution.

## Build
The included `.github/workflows/build-apk.yml` avoids `android-actions/setup-android@v3` and uses the Android SDK already installed on the GitHub runner. It installs the required Android 35 packages, repairs missing JSON imports, builds with Gradle 8.10.2 and uploads the APK.
