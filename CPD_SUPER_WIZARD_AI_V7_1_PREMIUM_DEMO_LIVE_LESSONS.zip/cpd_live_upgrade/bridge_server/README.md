# C.P.D MT5 Bridge Server

This is the missing transport layer between the Android command center and the MT5 EA.
It never receives an Exness password. The MT5 terminal remains the broker connection.

## Free deployment

Deploy this folder as a Render Web Service (Free plan). Set the secret environment variable `CPD_BRIDGE_TOKEN` to a long random value. Render free web services provide a public HTTPS URL, but can spin down after inactivity; MT5 polling/heartbeats keep the bridge active while the EA is connected. Do not treat the free service as a production uptime guarantee.

## Security

- Only the shared bearer token authenticates requests.
- The server queues trade commands only when the latest MT5 heartbeat identifies the account as DEMO.
- Real-account heartbeats cause `/trade` to reject commands.
- The EA also independently rejects real accounts.
