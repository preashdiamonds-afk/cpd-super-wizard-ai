# C.P.D SUPER WIZARD AI V4 PRO COMMAND CENTER

This is a substantial UI/flow rebuild over V3, not a version-number-only change.

## New command-center layout
- Home dashboard with account safety, engine snapshot, intelligence stack and system description.
- Dedicated Auto screen with separate Normal Auto and Aggressive Auto controls.
- Dedicated Signal Center with Normal-only signal feed, copy-to-Telegram and setup vision.
- Dedicated CPD Scanner with chart upload, live M5/M15/H1/H4 confirmation and BUY/SELL/WAIT verdict.
- Dedicated MT5 Bridge screen with Demo-first connection messaging and Live hard-lock status.
- Live account remains locked in the app and must not be executable by default.

## Execution truth
The Android client is not an MT5 terminal. Actual broker execution requires an authenticated MT5-side EA/bridge. This package does not claim that an unconfigured bridge is already connected to Exness.
