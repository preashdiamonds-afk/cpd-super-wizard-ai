# C.P.D SUPER WIZARD AI V5 — REAL DEMO CONNECTION

This release completes the **transport contract** instead of leaving the MT5 bridge as a placeholder.

## Architecture

Android app → CPD Bridge HTTPS → MT5 Expert Advisor → Exness MT5 Demo.

The Android app does not receive or store the Exness trading password. The MT5 terminal remains the broker session.

## What is now implemented

- App stores MT5 login, exact Exness server, bridge HTTPS URL and bridge token.
- App can test the bridge and read the MT5 account heartbeat.
- App accepts execution only when the bridge reports `DEMO`.
- Normal Auto can queue an actual MT5 demo order with symbol, 0.01 lot, SL and TP.
- MT5 EA polls the bridge every few seconds, executes the queued order with `CTrade`, and reports the result.
- EA sends account and open-position snapshots back to the bridge.
- REAL accounts are rejected by both the server and EA while Live Trading Lock is enabled.
- Aggressive Auto remains a separate mode.

## One unavoidable deployment step

A phone app cannot itself host the MT5 desktop execution terminal. The bridge server must have a public HTTPS address, and the MT5 EA must be running in an MT5 terminal. Exness currently advertises a free VPS for eligible accounts, which can keep an EA running when a personal computer is off. Check eligibility in the Exness Personal Area.

For a free prototype bridge, this repository includes `bridge_server/` and `render.yaml`. Render currently offers free web services, but free services can spin down after inactivity, so this is suitable for demo/testing rather than guaranteed production uptime.

## MT5 EA setup

1. Put `mt5/CPD_SUPER_WIZARD_AI_BRIDGE.mq5` into MetaEditor and compile it.
2. Attach the EA to one Exness MT5 demo chart.
3. In MT5, allow WebRequest for the bridge HTTPS domain.
4. Set:
   - `CPD_Bridge_URL` = your bridge HTTPS URL
   - `CPD_Bridge_Token` = the same secret used by the bridge
   - `AllowDemoAuto=true`
   - `AllowNormalAuto=true`
   - `AllowAggressiveAuto=true` if you want to test that engine
   - `LiveTradingLocked=true`
5. Confirm the EA journal reports `DEMO ACCOUNT detected`.

## Android setup

Open **MT5** in C.P.D → **CONNECT / CONFIGURE EXNESS DEMO** and enter:

- MT5 login number
- Exact Exness MT5 server name
- Bridge HTTPS URL
- Same bridge token

The status should become `BRIDGE ONLINE / ACCOUNT: DEMO / DEMO EXECUTION READY`.

Then enable Normal Auto. A validated signal can queue a real demo order; the EA executes it in Exness MT5 and reports the result back.

## Live lock

Live trading is intentionally not enabled in this release. If the EA detects `ACCOUNT_TRADE_MODE_REAL`, it rejects execution regardless of what the Android app requests.
