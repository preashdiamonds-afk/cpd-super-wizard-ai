# V3 upgrade notes

- Added explicit DEMO UNLOCKED / LIVE LOCKED account-mode presentation.
- Added an in-app live lock information dialog.
- Added MT5 bridge-side real-account detection and hard rejection while LiveTradingLocked=true.
- Kept Normal Auto and Aggressive Auto separate.
- Kept Manual/Signal Center Normal-only.
- Improved Telegram signal formatting.
- Updated Android version to 3.0-protected-demo-live-locked.
- Updated GitHub Actions workflow to build from the V3 ZIP and publish a V3 APK artifact.

Important: this package does not falsely claim that direct Android-to-Exness order execution is already complete. A real automated order path still requires an authenticated MT5-side bridge/EA transport, and that transport should be demo-tested before any live authorization.
