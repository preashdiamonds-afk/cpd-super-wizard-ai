# C.P.D SUPER WIZARD AI V6 — Aggressive Settings

This version adds a dedicated Settings screen and persistent Aggressive Auto controls.

## Video-derived behavior observed
The supplied ~90-second video shows an MT5-style positions screen with rapid XAUUSD multi-position scaling, changing position sizes, and large swings in balance/equity. The app does **not** assume that the video proves a profitable strategy. Instead, V6 exposes the behavior as configurable rules for demo testing.

## Controls
- Base lot
- Lot multiplier
- Maximum lot
- Maximum open positions
- Add-position distance in ATR
- High-water-mark loss lock percentage
- Minimum margin-level protection
- Direction mode: FOLLOW_SIGNAL / LONG_ONLY / SHORT_ONLY / REVERSAL_ONLY
- Profit banking profile
- Cooldown between additions

The 5% high-water-mark lock remains the default protection design: protection is measured from the highest observed equity, not the starting balance.

## Important
These settings are configuration controls. The current V6 Android build keeps live execution hard-locked. Aggressive execution should be demo-tested and validated before any consideration of real-money use.
