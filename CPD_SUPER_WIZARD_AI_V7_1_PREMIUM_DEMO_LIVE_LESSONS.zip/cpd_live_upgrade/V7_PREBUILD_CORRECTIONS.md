# C.P.D SUPER WIZARD AI V7 — PRE-BUILD CORRECTIONS

- Reworked CPD Scanner into a TradeBuddy-style chart review flow: upload/capture screenshot, preview it, optional instruction, structured report, BUY/SELL/WAIT, confidence, trend, volatility, pattern, S/R, momentum, and M5/M15/H1/H4 confirmation.
- Screenshot analysis is visual context only; it never invents price levels from pixels. Live market candles remain authoritative for Entry/SL/TP.
- Added live MT5 demo account dashboard: balance, equity, floating P/L, open positions, entry/SL/TP, lot and position P/L.
- Added weekly and monthly closed-trade win-rate/net dashboards, supplied by MT5 history.
- Bridge now exposes performance data and rejects duplicate pending orders for the same mode/symbol.
- MT5 EA now sends rolling 7-day and 30-day performance statistics with its heartbeat.
- Live trading remains hard-locked in both Android and EA layers.
- Demo connection still requires a running MT5 desktop terminal/EA and a public HTTPS bridge.

- Added a dedicated PERFORMANCE dashboard tab for weekly and monthly win rate, closed counts, net P/L, and current balance/equity/floating P/L.
