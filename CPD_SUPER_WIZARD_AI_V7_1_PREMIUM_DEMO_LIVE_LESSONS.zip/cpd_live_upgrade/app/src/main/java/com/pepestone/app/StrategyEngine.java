package com.pepestone.app;

import java.util.*;
import org.json.*;

/**
 * C.P.D SUPER WIZARD AI V10.35 strategy core.
 *
 * The strategy core produces validated signals. The connected Android controller may pass an approved demo signal to the authenticated MT5 bridge; this class itself never talks to the broker.
 *
 * Confidence is a 70–99 CPD confluence score, not a win probability:
 * HTF alignment 20 + structure 20 + liquidity sweep 15 + displacement 15 +
 * M15 momentum 5 + chart pattern 10 + support/resistance 10 = 95.
 */
public class StrategyEngine {
  public static final double NORMAL_RISK=1.0, AGG_RISK=0.75;
  public static final double MAX_TRADE_RISK=1.0, MAX_PORTFOLIO_RISK=3.0;
  public static final double NORMAL_THRESHOLD=70.0, AGG_THRESHOLD=60.0;
  public static final double MAX_SL_ATR=3.5;

  public static class Candle {
    double o,h,l,c; long v; String t;
    Candle(JSONObject x){
      o=x.optDouble("open"); h=x.optDouble("high"); l=x.optDouble("low"); c=x.optDouble("close");
      v=x.optLong("tickVolume",x.optLong("volume")); t=x.optString("time");
    }
  }

  public static class Signal {
    boolean valid; int dir; double confidence,entry,sl,tp,atr;
    double tp1,tp2,tp3,tp4;
    String reason="", pattern="NONE", patternQuality="NONE", sr="NONE", srQuality="NONE", breakout="NONE";
    String symbol; boolean tvConfirmed,newsRisk,vixRisk; double vix;
    Signal(String s){symbol=s;}
  }

  static double ema(List<Candle> r,int p){
    if(r==null||r.size()<p)return 0;
    double k=2.0/(p+1),e=r.get(r.size()-p).c;
    for(int i=r.size()-p+1;i<r.size();i++)e=r.get(i).c*k+e*(1-k);
    return e;
  }
  static double atr(List<Candle> r,int p){
    if(r==null||r.size()<p+1)return 0; double sum=0;
    for(int i=r.size()-p;i<r.size();i++){Candle x=r.get(i),q=r.get(i-1);sum+=Math.max(x.h-x.l,Math.max(Math.abs(x.h-q.c),Math.abs(x.l-q.c)));}
    return sum/p;
  }
  static double rsi(List<Candle> r,int p){
    if(r==null||r.size()<p+1)return 50; double g=0,l=0;
    for(int i=r.size()-p;i<r.size();i++){double d=r.get(i).c-r.get(i-1).c;if(d>0)g+=d;else l-=d;}
    if(l==0)return 100; return 100-100/(1+(g/l));
  }

  static boolean bullSweep(List<Candle> r,double a){
    if(r.size()<15||a<=0)return false; Candle x=r.get(r.size()-2); double prior=Double.POSITIVE_INFINITY;
    for(int i=Math.max(0,r.size()-16);i<r.size()-2;i++)prior=Math.min(prior,r.get(i).l);
    return x.l<prior-0.05*a && x.c>prior && (x.c>x.o || Math.abs(x.c-x.o)>=0.35*a);
  }
  static boolean bearSweep(List<Candle> r,double a){
    if(r.size()<15||a<=0)return false; Candle x=r.get(r.size()-2); double prior=Double.NEGATIVE_INFINITY;
    for(int i=Math.max(0,r.size()-16);i<r.size()-2;i++)prior=Math.max(prior,r.get(i).h);
    return x.h>prior+0.05*a && x.c<prior && (x.c<x.o || Math.abs(x.c-x.o)>=0.35*a);
  }

  static int structure(List<Candle> r,int d,double a){
    if(r.size()<30)return 0; int n=r.size();
    double lastHigh=-1e99,prevHigh=-1e99,lastLow=1e99,prevLow=1e99;
    for(int i=n-18;i<n-2;i++){
      Candle x=r.get(i); boolean ph=x.h>=r.get(i-1).h&&x.h>=r.get(i+1).h;
      boolean pl=x.l<=r.get(i-1).l&&x.l<=r.get(i+1).l;
      if(ph){prevHigh=lastHigh;lastHigh=x.h;}
      if(pl){prevLow=lastLow;lastLow=x.l;}
    }
    Candle x=r.get(n-2); boolean bosUp=x.c>lastHigh+0.10*a, bosDn=x.c<lastLow-0.10*a;
    boolean seqUp=lastHigh>prevHigh+0.10*a&&lastLow>prevLow+0.10*a;
    boolean seqDn=lastHigh<prevHigh-0.10*a&&lastLow<prevLow-0.10*a;
    if(d>0)return seqUp&&bosUp?2:(seqUp||bosUp?1:0);
    return seqDn&&bosDn?-2:(seqDn||bosDn?-1:0);
  }

  static boolean disp(List<Candle> r,int d,double a){
    if(r.size()<8||a<=0)return false; Candle x=r.get(r.size()-2); double body=Math.abs(x.c-x.o),range=x.h-x.l;
    if(range<=0)return false; double loc=d>0?(x.c-x.l)/range:(x.h-x.c)/range;
    return (d>0?x.c>x.o:x.c<x.o)&&body>=0.80*a&&loc>=0.65;
  }
  static boolean fastTrigger(List<Candle> r,int d,double ask,double bid,double a){
    if(r.size()<5||a<=0)return false; Candle prev=r.get(r.size()-2),live=r.get(r.size()-1); double px=d>0?ask:bid,buffer=0.02*a;
    return d>0?px>prev.h+buffer&&px>=live.o:px<prev.l-buffer&&px<=live.o;
  }
  static boolean momentum(List<Candle> r,int d){
    if(r.size()<205)return false; double f=ema(r,50),s=ema(r,200),q=rsi(r,14);
    return d>0?f>s&&q>50&&q<75:f<s&&q<50&&q>25;
  }
  static boolean extension(List<Candle> r,int d,double a){double px=r.get(r.size()-2).c,f=ema(r,50);return a>0&&Math.abs(px-f)<=2.5*a;}

  static class Pivot { int i; double p; Pivot(int ii,double pp){i=ii;p=pp;} }
  static List<Pivot> highs(List<Candle> r,int from,int to){
    List<Pivot> out=new ArrayList<>(); int lo=Math.max(2,from),hi=Math.min(r.size()-3,to);
    for(int i=lo;i<=hi;i++){double h=r.get(i).h;if(h>=r.get(i-1).h&&h>=r.get(i+1).h&&h>=r.get(i-2).h&&h>=r.get(i+2).h)out.add(new Pivot(i,h));} return out;
  }
  static List<Pivot> lows(List<Candle> r,int from,int to){
    List<Pivot> out=new ArrayList<>(); int lo=Math.max(2,from),hi=Math.min(r.size()-3,to);
    for(int i=lo;i<=hi;i++){double l=r.get(i).l;if(l<=r.get(i-1).l&&l<=r.get(i+1).l&&l<=r.get(i-2).l&&l<=r.get(i+2).l)out.add(new Pivot(i,l));} return out;
  }

  /** Returns 1 bullish, -1 bearish, 0 none and writes a named confirmed pattern. */
  static int pattern(List<Candle> r,StringBuilder name,StringBuilder quality,double a){
    name.setLength(0);quality.setLength(0);name.append("NONE");quality.append("NONE");
    if(r.size()<40||a<=0)return 0;
    int n=r.size(),i=n-2; Candle x=r.get(i),q=r.get(i-1),q2=r.get(i-2);
    double body=Math.abs(x.c-x.o),range=Math.max(a*0.10,x.h-x.l),lw=Math.min(x.o,x.c)-x.l,uw=x.h-Math.max(x.o,x.c);
    if(q.c<q.o&&x.c>x.o&&x.o<=q.c&&x.c>=q.o){name.setLength(0);name.append("Bullish Engulfing");quality.setLength(0);quality.append("TRUE");return 1;}
    if(q.c>q.o&&x.c<x.o&&x.o>=q.c&&x.c<=q.o){name.setLength(0);name.append("Bearish Engulfing");quality.setLength(0);quality.append("TRUE");return -1;}
    if(lw>=Math.max(2*body,0.25*a)&&uw<=Math.max(body*0.8,0.05*a)&&x.c>x.o){name.setLength(0);name.append("Hammer");quality.setLength(0);quality.append("TRUE");return 1;}
    if(uw>=Math.max(2*body,0.25*a)&&lw<=Math.max(body*0.8,0.05*a)&&x.c<x.o){name.setLength(0);name.append("Shooting Star");quality.setLength(0);quality.append("TRUE");return -1;}

    List<Pivot> hs=highs(r,Math.max(3,n-55),n-3), ls=lows(r,Math.max(3,n-55),n-3);
    if(hs.size()>=2){
      Pivot p1=hs.get(hs.size()-2),p2=hs.get(hs.size()-1); double tol=0.45*a;
      double valley=Double.POSITIVE_INFINITY; for(int k=p1.i+1;k<p2.i;k++)valley=Math.min(valley,r.get(k).l);
      boolean separated=p2.i-p1.i>=4, equal=Math.abs(p1.p-p2.p)<=tol, necklineBroken=x.c<valley-0.05*a;
      if(separated&&equal&&necklineBroken){name.setLength(0);name.append("Double Top");quality.setLength(0);quality.append("TRUE");return -1;}
    }
    if(ls.size()>=2){
      Pivot p1=ls.get(ls.size()-2),p2=ls.get(ls.size()-1); double tol=0.45*a;
      double peak=Double.NEGATIVE_INFINITY; for(int k=p1.i+1;k<p2.i;k++)peak=Math.max(peak,r.get(k).h);
      boolean separated=p2.i-p1.i>=4, equal=Math.abs(p1.p-p2.p)<=tol, necklineBroken=x.c>peak+0.05*a;
      if(separated&&equal&&necklineBroken){name.setLength(0);name.append("Double Bottom");quality.setLength(0);quality.append("TRUE");return 1;}
    }
    // Head & shoulders / inverse H&S using the last three confirmed pivots.
    if(hs.size()>=3){
      Pivot a1=hs.get(hs.size()-3),head=hs.get(hs.size()-2),a2=hs.get(hs.size()-1);
      double shoulderTol=0.55*a;
      double n1=Double.POSITIVE_INFINITY; for(int k=a1.i+1;k<head.i;k++)n1=Math.min(n1,r.get(k).l);
      double n2=Double.POSITIVE_INFINITY; for(int k=head.i+1;k<a2.i;k++)n2=Math.min(n2,r.get(k).l);
      double neckline=(n1+n2)/2.0;
      if(Math.abs(a1.p-a2.p)<=shoulderTol&&head.p>Math.max(a1.p,a2.p)+0.35*a&&x.c<neckline-0.05*a){name.setLength(0);name.append("Head & Shoulders");quality.setLength(0);quality.append("TRUE");return -1;}
    }
    if(ls.size()>=3){
      Pivot a1=ls.get(ls.size()-3),head=ls.get(ls.size()-2),a2=ls.get(ls.size()-1);
      double shoulderTol=0.55*a;
      double n1=Double.NEGATIVE_INFINITY; for(int k=a1.i+1;k<head.i;k++)n1=Math.max(n1,r.get(k).h);
      double n2=Double.NEGATIVE_INFINITY; for(int k=head.i+1;k<a2.i;k++)n2=Math.max(n2,r.get(k).h);
      double neckline=(n1+n2)/2.0;
      if(Math.abs(a1.p-a2.p)<=shoulderTol&&head.p<Math.min(a1.p,a2.p)-0.35*a&&x.c>neckline+0.05*a){name.setLength(0);name.append("Inverse Head & Shoulders");quality.setLength(0);quality.append("TRUE");return 1;}
    }
    // Consolidation breakout: tight recent range followed by a decisive close.
    int start=Math.max(2,n-9); double hi=-1e99,lo=1e99;
    for(int k=start;k<n-2;k++){hi=Math.max(hi,r.get(k).h);lo=Math.min(lo,r.get(k).l);}
    boolean tight=(hi-lo)<=2.2*a;
    if(tight&&x.c>hi+0.05*a&&x.c>x.o){name.setLength(0);name.append("Bullish Consolidation Breakout");quality.setLength(0);quality.append("TRUE");return 1;}
    if(tight&&x.c<lo-0.05*a&&x.c<x.o){name.setLength(0);name.append("Bearish Consolidation Breakout");quality.setLength(0);quality.append("TRUE");return -1;}
    return 0;
  }

  /** Classifies the latest breakout/sweep as TRUE or FALSE rather than treating every breakout as valid. */
  static String breakoutQuality(List<Candle> r,int d,double a){
    if(r.size()<20||a<=0)return "NONE"; int n=r.size(); Candle x=r.get(n-2);
    double hi=-1e99,lo=1e99; for(int i=Math.max(0,n-18);i<n-2;i++){hi=Math.max(hi,r.get(i).h);lo=Math.min(lo,r.get(i).l);}
    if(d>0){if(x.h>hi+0.05*a&&x.c>hi+0.02*a)return "TRUE BREAKOUT"; if(x.l<lo-0.05*a&&x.c>lo)return "FALSE BREAKOUT / BULLISH SWEEP";}
    else {if(x.l<lo-0.05*a&&x.c<lo-0.02*a)return "TRUE BREAKOUT"; if(x.h>hi+0.05*a&&x.c<hi)return "FALSE BREAKOUT / BEARISH SWEEP";}
    return "NO CONFIRMED BREAKOUT";
  }

  /** Strong/weak S/R from clustered pivots, touches and reaction distance. */
  static int sr(List<Candle> r,int dir,StringBuilder name,StringBuilder quality,double a){
    name.setLength(0);quality.setLength(0);name.append("NO_CLEAR_LEVEL");quality.append("NONE");
    if(r.size()<50||a<=0)return 0; int n=r.size(); double px=r.get(n-2).c,tol=0.65*a;
    List<Pivot> ps=dir>0?lows(r,Math.max(3,n-75),n-3):highs(r,Math.max(3,n-75),n-3);
    if(ps.isEmpty())return 0;
    Pivot best=null; double bd=Double.POSITIVE_INFINITY; int touches=0; double reaction=0;
    for(Pivot p:ps){double d=Math.abs(p.p-px);if(d<bd){bd=d;best=p;}}
    if(best==null||bd>1.25*a)return 0;
    for(Pivot p:ps)if(Math.abs(p.p-best.p)<=0.45*a){touches++; reaction=Math.max(reaction,Math.abs(r.get(Math.min(n-2,p.i+2)).c-best.p));}
    boolean strong=touches>=2 && reaction>=0.60*a;
    boolean weak=touches>=1;
    name.setLength(0);name.append(dir>0?"Support":"Resistance");
    quality.setLength(0);quality.append(strong?"STRONG":weak?"WEAK":"NONE");
    return strong?2:(weak?1:0);
  }

  public Signal evaluate(String symbol,List<Candle> h4,List<Candle> h1,List<Candle> m15,List<Candle> m5,double bid,double ask,boolean aggressive){
    return evaluate(symbol,h4,h1,m15,m5,bid,ask,aggressive,null,false,0);
  }

  public Signal evaluate(String symbol,List<Candle> h4,List<Candle> h1,List<Candle> m15,List<Candle> m5,double bid,double ask,boolean aggressive,MarketContextClient.Context ctx,boolean tvConfirmed,double tvPrice){
    Signal s=new Signal(symbol);
    if(h4==null||h1==null||m15==null||m5==null||h4.size()<205||h1.size()<205||m15.size()<80||m5.size()<40)return s;
    double e4=ema(h4,50),e42=ema(h4,200),e1=ema(h1,50),e12=ema(h1,200);
    double c4=h4.get(h4.size()-2).c,c1=h1.get(h1.size()-2).c;
    int d=(c4>e4&&e4>e42&&c1>e1&&e1>e12)?1:(c4<e4&&e4<e42&&c1<e1&&e1<e12?-1:0); if(d==0)return s;
    double a15=atr(m15,14),a5=atr(m5,14); if(a15<=0||a5<=0)return s;
    int st=structure(m15,d,a15); boolean liq=d>0?bullSweep(m15,a15):bearSweep(m15,a15);
    boolean dis=disp(m15,d,a15); boolean trig=fastTrigger(m5,d,ask,bid,a5); boolean mom=momentum(m15,d);
    StringBuilder pn=new StringBuilder(),pq=new StringBuilder(),sn=new StringBuilder(),sq=new StringBuilder();
    int pd=pattern(m15,pn,pq,a15),srScore=sr(m15,d,sn,sq,a15); String bq=breakoutQuality(m15,d,a15);
    if(st==0||!liq||!dis||!trig)return s;
    boolean newsRisk=ctx!=null&&(ctx.investingHighImpact||ctx.forexFactoryHighImpact);
    boolean vixRisk=ctx!=null&&ctx.vixAvailable&&ctx.vix>=25;
    double mid=(bid>0&&ask>0)?(bid+ask)/2.0:0;
    double tvGap=(tvConfirmed&&tvPrice>0&&mid>0)?Math.abs(tvPrice-mid):0;
    boolean tvAligned=!tvConfirmed||tvGap<=2.5*a5; if(!tvAligned)return s;
    // 95-point core score. External feeds are validation/context gates, not bonus points.
    double score=20+(st==2?20:10)+(liq?15:0)+(dis?15:0)+(mom?5:0)+(pd==d?10:0)+(srScore>0?10:0);
    // Structure partials never produce a false 95: require full BOS for normal-quality signals.
    if(st<2)return s;
    // The V10.35 normal mode is the default mobile mode. Aggressive mode remains stricter than raw 60 when quality is weak.
    double need=aggressive?Math.max(60, (pd==d?70:75)):NORMAL_THRESHOLD;
    if(newsRisk && !aggressive)return s;
    if(vixRisk && !aggressive && srScore<2)return s;
    if(score<need)return s;
    // Balanced Normal mode: the core structure/liquidity/displacement/trigger gates remain, while pattern/SR are evidence rather than mandatory final gates.

    s.dir=d; s.entry=d>0?ask:bid;
    Candle last=m5.get(m5.size()-2); double swing=d>0?last.l:last.h;
    for(int i=Math.max(0,m5.size()-10);i<m5.size()-2;i++)swing=d>0?Math.min(swing,m5.get(i).l):Math.max(swing,m5.get(i).h);
    s.sl=d>0?swing-0.20*a15:swing+0.20*a15; double risk=Math.abs(s.entry-s.sl);
    if(risk<=0||risk>MAX_SL_ATR*a15||!extension(m15,d,a15))return s;
    s.atr=a15; s.tp1=d>0?s.entry+0.80*risk:s.entry-0.80*risk; s.tp2=d>0?s.entry+1.60*risk:s.entry-1.60*risk;
    s.tp3=d>0?s.entry+2.60*risk:s.entry-2.60*risk; s.tp4=d>0?s.entry+4.00*risk:s.entry-4.00*risk; s.tp=d>0?s.entry+6.00*risk:s.entry-6.00*risk;
    s.valid=true; s.confidence=Math.min(99,score*99.0/95.0); s.pattern=pn.toString(); s.patternQuality=pq.toString(); s.sr=sn.toString(); s.srQuality=sq.toString(); s.breakout=bq;
    s.tvConfirmed=tvConfirmed;s.newsRisk=newsRisk;s.vixRisk=vixRisk;s.vix=ctx!=null?ctx.vix:0;
    s.reason="HTF ALIGNMENT 20/20 • STRUCTURE 20/20 • LIQUIDITY SWEEP 15/15 • DISPLACEMENT 15/15 • M15 MOMENTUM "+(mom?"5/5":"0/5")+
      " • PATTERN "+(pd==d?"10/10 "+s.pattern+" [TRUE]":"0/10")+" • S/R "+(srScore>0?"10/10 "+s.sr+" ["+s.srQuality+"]":"0/10")+
      " • BREAKOUT "+s.breakout+(tvConfirmed?" • TRADINGVIEW ALIGNED":"")+(newsRisk?" • HIGH-IMPACT NEWS CONTEXT":"")+(vixRisk?" • VIX HIGH":"");
    return s;
  }

  public Signal evaluate(String symbol,List<Candle> h4,List<Candle> h1,List<Candle> m15,List<Candle> m5,double bid,double ask){return evaluate(symbol,h4,h1,m15,m5,bid,ask,false);}
}
