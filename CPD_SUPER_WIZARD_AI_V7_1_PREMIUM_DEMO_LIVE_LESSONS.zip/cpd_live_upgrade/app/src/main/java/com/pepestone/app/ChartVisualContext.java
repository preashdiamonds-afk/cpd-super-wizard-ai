package com.pepestone.app;

import android.graphics.Bitmap;

/**
 * Local chart-image inspection. It validates the screenshot and extracts visual
 * characteristics only; it never invents prices from pixels. Live market data
 * remains the authoritative source for Entry/SL/TP.
 */
public final class ChartVisualContext {
  public static class Report {
    public int width,height,avgLuma,edgeScore;
    public boolean darkChart,likelyChart,hasGrid;
    public String summary;
  }
  public static Report inspect(Bitmap b){
    Report r=new Report();
    if(b==null){r.summary="No screenshot attached.";return r;}
    r.width=b.getWidth(); r.height=b.getHeight();
    if(r.width<240||r.height<160){r.summary="Screenshot received, but it is too small for reliable chart inspection.";return r;}
    long lum=0; long edges=0; int n=0; int step=Math.max(2,Math.min(r.width,r.height)/90);
    for(int y=0;y<r.height;y+=step){
      int prev=-1;
      for(int x=0;x<r.width;x+=step){
        int p=b.getPixel(x,y); int rr=(p>>16)&255,gg=(p>>8)&255,bb=p&255;
        int l=(rr*30+gg*59+bb*11)/100; lum+=l; n++;
        if(prev>=0 && Math.abs(l-prev)>42) edges++;
        prev=l;
      }
    }
    r.avgLuma=n==0?0:(int)(lum/n); r.edgeScore=n==0?0:(int)Math.min(100,edges*100.0/n);
    r.darkChart=r.avgLuma<105; r.hasGrid=r.edgeScore>=8; r.likelyChart=r.width>=480&&r.height>=260&&r.edgeScore>=3;
    r.summary=(r.likelyChart?"CHART IMAGE READY":"CHART IMAGE NEEDS REVIEW")+
      " • "+r.width+"×"+r.height+
      " • "+(r.darkChart?"dark theme":"light theme")+
      " • visual edge score "+r.edgeScore+"%"+
      " • live M5/M15/H1/H4 data remains authoritative for trade levels.";
    return r;
  }
  public static String describe(Bitmap b){ return inspect(b).summary; }
}
