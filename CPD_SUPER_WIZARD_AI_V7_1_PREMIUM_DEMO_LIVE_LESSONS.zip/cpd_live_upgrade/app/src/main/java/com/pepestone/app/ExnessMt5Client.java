package com.pepestone.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Exness/MT5 bridge client.
 *
 * This app does NOT pretend that Exness exposes a public retail MT5 REST
 * endpoint. Instead, it speaks a small documented CPD Bridge REST contract.
 * The bridge is responsible for talking to MT5/Exness and must be hosted by
 * the user or a supported service. No Exness password is sent by this app.
 */
public class ExnessMt5Client implements BrokerApiClient {
  private String login="", server="", baseUrl="", bearer="";
  private boolean configured=false;

  public void configure(String login, String server) {
    configure(login, server, baseUrl, bearer);
  }
  public void configure(String login, String server, String baseUrl, String bearer) {
    this.login=login==null?"":login.trim();
    this.server=server==null?"":server.trim();
    this.baseUrl=baseUrl==null?"":baseUrl.trim();
    this.bearer=bearer==null?"":bearer.trim();
    this.configured=!this.login.isEmpty() && !this.server.isEmpty() && !this.baseUrl.isEmpty();
  }
  public boolean isConfigured(){ return configured; }
  public String getServer(){ return server; }
  public String getBaseUrl(){ return baseUrl; }
  public boolean hasBridge(){ return !baseUrl.isEmpty(); }

  private void requireConfigured() throws IOException {
    if(!configured) throw new IOException("Enter the Exness account, exact server, and CPD Bridge URL.");
  }
  private JSONObject basePayload(){
    JSONObject x=new JSONObject();
    try { x.put("login",login); x.put("server",server); } catch(Exception ignored) {}
    return x;
  }
  private String url(String path){
    String b=baseUrl.replaceAll("/+$","");
    return b+"/"+path.replaceFirst("^/+","");
  }
  private JSONObject request(String method,String path,JSONObject payload) throws Exception {
    if(baseUrl.isEmpty()) throw new IOException("CPD Bridge URL is not configured.");
    HttpURLConnection c=(HttpURLConnection)new URL(url(path)).openConnection();
    c.setRequestMethod(method); c.setConnectTimeout(8000); c.setReadTimeout(12000);
    c.setRequestProperty("Accept","application/json");
    c.setRequestProperty("Content-Type","application/json; charset=utf-8");
    if(!bearer.isEmpty()) c.setRequestProperty("Authorization","Bearer "+bearer);
    if(payload!=null){ c.setDoOutput(true); byte[] body=payload.toString().getBytes(StandardCharsets.UTF_8); try(OutputStream o=c.getOutputStream()){o.write(body);} }
    int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();
    StringBuilder sb=new StringBuilder(); if(is!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)sb.append(line);}
    if(code<200||code>=300) throw new IOException("Bridge HTTP "+code+": "+sb);
    String raw=sb.toString().trim(); return raw.isEmpty()?new JSONObject():new JSONObject(raw);
  }
  private JSONObject post(String path, JSONObject payload) throws Exception { return request("POST",path,payload); }
  private JSONArray array(JSONObject x){ return x.optJSONArray("data")!=null?x.optJSONArray("data"):x.optJSONArray("items")!=null?x.optJSONArray("items"):new JSONArray(); }

  public JSONObject health() throws Exception { return request("GET","health",null); }
  public JSONObject performance() throws Exception { requireConfigured(); return post("performance",basePayload()); }
  @Override public JSONObject accountInfo() throws Exception { requireConfigured(); return post("account",basePayload()); }
  @Override public JSONArray positions() throws Exception { requireConfigured(); return array(post("positions",basePayload())); }
  @Override public JSONArray candles(String symbol,String tf,int limit) throws Exception { requireConfigured(); JSONObject x=basePayload();x.put("symbol",symbol);x.put("timeframe",tf);x.put("limit",limit);return array(post("candles",x)); }
  @Override public JSONObject tick(String symbol) throws Exception { requireConfigured(); JSONObject x=basePayload();x.put("symbol",symbol);return post("tick",x); }
  @Override public JSONObject price(String symbol) throws Exception { return tick(symbol); }
  @Override public JSONObject spec(String symbol) throws Exception { requireConfigured(); JSONObject x=basePayload();x.put("symbol",symbol);return post("spec",x); }
  @Override public JSONObject trade(JSONObject trade) throws Exception { requireConfigured(); JSONObject x=basePayload();JSONArray keys=trade.names();if(keys!=null)for(int i=0;i<keys.length();i++){String k=keys.getString(i);x.put(k,trade.get(k));}return post("trade",x); }
}
