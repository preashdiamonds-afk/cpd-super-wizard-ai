package com.pepestone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;
import java.util.concurrent.*;

/**
 * C.P.D SUPER WIZARD AI — PRO COMMAND CENTER.
 * V4 is a substantial UI/flow rebuild over the protected V3 base.
 * Demo and Live are separate modes with explicit account-mode verification.
 */
public class MainActivity extends Activity {
  private final String[] PAIRS={"EURUSD","GBPUSD","USDJPY","GBPJPY","AUDUSD","USDCAD","USDCHF","AUDJPY","AUDCAD","AUDCHF","XAUUSD"};
  private LinearLayout content; private TextView topStatus; private Spinner pairSpinner; private TextView scannerResult,visualInfo,manualSignal,connectionState,accountSummary,positionSummary,performanceSummary;
  private ImageView chartPreview; private EditText scannerInstruction;
  private Bitmap uploadedChart; private StrategyEngine.Signal lastNormalSignal; private SignalChartView vision;
  private final PublicMarketDataClient market=new PublicMarketDataClient();
  private final ExnessMt5Client bridge=new ExnessMt5Client();
  private android.content.SharedPreferences prefs;
  private final Handler bridgeHandler=new Handler(Looper.getMainLooper()); private final Handler normalHandler=new Handler(Looper.getMainLooper());
  private final Runnable bridgeRefresh=()->{refreshBridgeStatus();refreshAccountPanels();bridgeHandler.postDelayed(bridgeRefresh,5000);};
  private final Runnable normalLoop=()->{if(normalOn){scanNormal();normalHandler.postDelayed(normalLoop,30000);}};
  private boolean normalOn=false, aggressiveOn=false;
  private double agBaseLot=0.01, agMultiplier=1.50, agMaxLot=2.55, agAddDistanceAtr=0.50, agLockPct=5.0, agMarginFloor=150.0;
  private int agMaxPositions=20, agCooldownSec=5;
  private String agDirection="FOLLOW_SIGNAL", agProfitBank="0.80R / 1.60R / 2.60R"; private final ExecutorService io=Executors.newSingleThreadExecutor();
  private int gold=Color.rgb(255,210,82), bg=Color.rgb(4,6,16), card=Color.rgb(13,18,31), card2=Color.rgb(21,29,48), white=Color.rgb(244,248,255), muted=Color.rgb(151,164,184), green=Color.rgb(70,230,150), red=Color.rgb(255,92,112), blue=Color.rgb(91,177,255), cyan=Color.rgb(73,232,255), purple=Color.rgb(151,105,255);
  private TextToSpeech tts; private boolean locked=true; private static final String APP_PASSWORD="200825";
  private String accountMode="DEMO"; private boolean liveEnabled=false;

  @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("cpd_bridge",MODE_PRIVATE);loadBridgeConfig();loadAggressiveConfig();liveEnabled=prefs.getBoolean("liveEnabled",false);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);build();initVoice();showAppLock();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);}
  private TextView tv(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setFontFeatureSettings("kern");return v;}
  private GradientDrawable box(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);g.setStroke(1,Color.rgb(49,61,86));return g;}
  private GradientDrawable gradient(int[] colors,float r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(r);g.setStroke(1,Color.rgb(57,70,98));return g;}
  private LinearLayout card(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(18,16,18,16);x.setBackground(gradient(new int[]{Color.rgb(16,23,40),Color.rgb(10,15,28)},24));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,9,0,0);x.setLayoutParams(p);return x;}
  private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(11);b.setTypeface(null,Typeface.BOLD);b.setAllCaps(false);b.setTextColor(primary?Color.rgb(5,8,15):white);b.setBackground(gradient(primary?new int[]{gold,Color.rgb(255,151,68)}:new int[]{card2,Color.rgb(27,40,65)},18));b.setPadding(8,0,8,0);return b;}
  private TextView badge(String s,int c){TextView v=tv(s,11,c);v.setTypeface(null,Typeface.BOLD);v.setPadding(12,7,12,7);v.setBackground(box(Color.rgb(22,28,37),18));return v;}

  private void build(){
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackground(gradient(new int[]{Color.rgb(4,7,18),Color.rgb(10,8,30),Color.rgb(3,10,19)},0));setContentView(root);
    LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setPadding(18,15,18,10);head.setBackground(gradient(new int[]{Color.rgb(12,18,38),Color.rgb(9,10,25)},0));
    LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView t=tv("C.P.D",25,gold);t.setTypeface(null,Typeface.BOLD);row.addView(t,new LinearLayout.LayoutParams(0,42,1));TextView lock=badge(liveEnabled?"● LIVE READY":"● LIVE AVAILABLE",liveEnabled?red:purple);row.addView(lock);head.addView(row);
    topStatus=tv("COMMAND CENTER  •  DEMO + LIVE ACCOUNT CENTER",11,green);topStatus.setPadding(2,2,0,0);head.addView(topStatus);root.addView(head,new LinearLayout.LayoutParams(-1,-2));
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(13,4,13,18);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=new LinearLayout(this);nav.setPadding(5,6,5,7);nav.setBackgroundColor(Color.rgb(7,10,20));String[] tabs={"⌂ HOME","◉ AUTO","≡ SIGNAL","◈ SCAN","▥ PERF","⚙ SET"};for(String s:tabs){Button b=button(s,false);b.setTextSize(9);String key=s.substring(2);b.setOnClickListener(v->show(key));nav.addView(b,new LinearLayout.LayoutParams(0,56,1));}root.addView(nav,new LinearLayout.LayoutParams(-1,70));show("HOME");
  }
  private void initVoice(){
    tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS){tts.setLanguage(Locale.US);tts.setSpeechRate(0.86f);tts.setPitch(0.82f);}});
  }
  private void speakWelcome(){if(tts!=null){tts.speak("Welcome, Captain Preash Diamond.",TextToSpeech.QUEUE_FLUSH,null,"cpd_welcome");}}
  private void showAppLock(){
    locked=true;
    final EditText pass=new EditText(this); pass.setHint("Enter app password"); pass.setInputType(0x81); pass.setTextColor(white); pass.setHintTextColor(muted); pass.setGravity(Gravity.CENTER);
    LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,8,28,4);
    box.addView(tv("SECURE COMMAND CENTER",15,gold));
    box.addView(tv("Enter your C.P.D access password to continue.",11,muted));
    box.addView(pass,new LinearLayout.LayoutParams(-1,58));
    AlertDialog d=new AlertDialog.Builder(this).setTitle("C.P.D SUPER WIZARD AI").setView(box).setCancelable(false).setPositiveButton("UNLOCK",null).create();
    d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(APP_PASSWORD.equals(pass.getText().toString())){locked=false;d.dismiss();speakWelcome();new Handler().postDelayed(this::welcome,350);}else{pass.setError("Incorrect password");}}); pass.requestFocus(); d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});
    d.show();
  }
  private void welcome(){new Handler().postDelayed(()->new AlertDialog.Builder(this).setTitle("WELCOME, CAPTAIN PREASH DIAMOND").setMessage("C.P.D SUPER WIZARD AI is ready. It needs valid market data before it can analyze or execute. Demo and Live account modes are separated and verified from the actual MT5 account type before orders are sent.").setPositiveButton("ENTER COMMAND CENTER",null).show(),250);}
  private void show(String tab){content.removeAllViews();if(tab.equals("AUTO"))auto();else if(tab.equals("SIGNAL"))signal();else if(tab.equals("SCAN"))scan();else if(tab.equals("PERF"))performance();else if(tab.equals("MT5"))mt5();else if(tab.equals("SET"))settings();else home();}
  private void header(String title,String sub){LinearLayout c=card();c.addView(tv(title,22,gold));TextView x=tv(sub,12,muted);x.setPadding(0,5,0,0);c.addView(x);content.addView(c);}
  private void home(){
    header("WELCOME, CAPTAIN PREASH DIAMOND","PRO COMMAND CENTER  •  MULTI-ENGINE TRADING SYSTEM");
    LinearLayout mode=card();mode.addView(tv("ACCOUNT MODES",13,gold));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView d=badge("● DEMO  READY",green);TextView l=badge(liveEnabled?"● LIVE  ENABLED":"● LIVE  AVAILABLE",liveEnabled?red:purple);r.addView(d,new LinearLayout.LayoutParams(0,42,1));r.addView(l,new LinearLayout.LayoutParams(0,42,1));mode.addView(r);TextView m=tv("C.P.D reads the actual MT5 account mode before every order. DEMO commands are rejected on REAL accounts; LIVE commands are rejected on DEMO accounts.",11,muted);m.setPadding(0,10,0,0);mode.addView(m);content.addView(mode);
    LinearLayout stats=card();stats.addView(tv("SYSTEM SNAPSHOT",13,gold));stats.addView(statRow("NORMAL AUTO",normalOn?"SCANNING":"STANDBY",normalOn?green:muted));stats.addView(statRow("AGGRESSIVE AUTO",aggressiveOn?"ISOLATED / ON":"STANDBY",aggressiveOn?blue:muted));stats.addView(statRow("SIGNAL CENTER",lastNormalSignal==null?"NO ACTIVE SIGNAL":"SIGNAL READY",lastNormalSignal==null?muted:green));stats.addView(statRow("CPD SCANNER","M5 • M15 • H1 • H4",blue));content.addView(stats);
    LinearLayout acct=card(); acct.addView(tv("DEMO ACCOUNT DASHBOARD",13,gold));
    accountSummary=tv("Waiting for MT5 demo connection…",12,white); acct.addView(accountSummary);
    positionSummary=tv("No synchronized positions yet.",11,muted); positionSummary.setPadding(0,10,0,0); acct.addView(positionSummary);
    performanceSummary=tv("Weekly win rate: —\nMonthly win rate: —",11,white); performanceSummary.setPadding(0,10,0,0); acct.addView(performanceSummary);
    content.addView(acct);
    LinearLayout engines=card();engines.addView(tv("INTELLIGENCE STACK",13,gold));String[] es={"01  MARKET STRUCTURE","02  TRUE / FALSE PATTERN","03  STRONG / WEAK SUPPORT & RESISTANCE","04  LIQUIDITY / SWEEP","05  MOMENTUM + DISPLACEMENT","06  BREAKOUT / FAKEOUT","07  MULTI-TIMEFRAME VALIDATION","08  RISK + FINAL DECISION"};for(String e:es){TextView q=tv("◆ "+e,11,white);q.setPadding(0,7,0,7);engines.addView(q);}content.addView(engines);
    LinearLayout about=card();about.addView(tv("WHAT THIS VERSION IS",13,gold));about.addView(tv("A redesigned command-center shell for the C.P.D strategy. The scanner uses live market candles when available and the uploaded chart as visual context. It can return BUY, SELL or WAIT. If market/MT5 data is unavailable, the app remains open but analysis and execution stay unavailable.",12,white));Button lessons=button("◆ C.P.D ACADEMY • 10 LESSONS",true);lessons.setOnClickListener(v->lessons());about.addView(lessons,new LinearLayout.LayoutParams(-1,52));content.addView(about);
  }
  private TextView statRow(String a,String b,int c){TextView v=tv(a+"                                      "+b,11,c);v.setPadding(0,9,0,3);return v;}
  private void auto(){
    header("AUTO ENGINE","NORMAL and AGGRESSIVE are independent systems");
    LinearLayout p=card();p.addView(tv("MARKET",13,gold));pairSpinner=new Spinner(this);pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS));p.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));content.addView(p);
    LinearLayout n=card();n.addView(tv("NORMAL AUTO",17,gold));n.addView(tv("Primary strategy • feeds Signal Center • DEMO or LIVE, with exact account-mode verification",11,muted));Button nb=button(normalOn?"● NORMAL AUTO ON  •  STOP":"NORMAL AUTO  •  START",!normalOn);nb.setOnClickListener(v->{normalOn=!normalOn;topStatus.setText(normalOn?"NORMAL AUTO  •  SCANNING "+accountMode:"COMMAND CENTER  •  "+accountMode+" READY");show("AUTO");if(normalOn){scanNormal();normalHandler.removeCallbacks(normalLoop);normalHandler.postDelayed(normalLoop,30000);}else normalHandler.removeCallbacks(normalLoop);});n.addView(nb,new LinearLayout.LayoutParams(-1,52));n.addView(tv("Balanced normal filtering: HTF bias → structure → liquidity → displacement → execution trigger → risk gate. Confidence target: 70–99 CPD confluence score, not a win-probability guarantee.",10,white));Button cl=button("◆ OPEN C.P.D ACADEMY",false);cl.setOnClickListener(v->lessons());n.addView(cl,new LinearLayout.LayoutParams(-1,48));content.addView(n);
    LinearLayout a=card();a.addView(tv("AGGRESSIVE AUTO",17,blue));a.addView(tv("Separate engine • never feeds Normal Signal Center",11,muted));Button ab=button(aggressiveOn?"● AGGRESSIVE ON  •  STOP":"AGGRESSIVE AUTO  •  START",false);ab.setOnClickListener(v->{aggressiveOn=!aggressiveOn;Toast.makeText(this,aggressiveOn?"Aggressive engine isolated and enabled for demo testing.":"Aggressive engine stopped.",Toast.LENGTH_SHORT).show();show("AUTO");});a.addView(ab,new LinearLayout.LayoutParams(-1,52));a.addView(tv("Protection design: high-water-mark loss lock and separate risk controls.",10,white));Button as=button("⚙ AGGRESSIVE SETTINGS",true);as.setOnClickListener(v->aggressiveSettingsDialog());a.addView(as,new LinearLayout.LayoutParams(-1,50));content.addView(a);
    LinearLayout lock=card();lock.addView(tv("LIVE EXECUTION",13,red));lock.addView(tv("🔒 HARD LOCKED  •  app + MT5 bridge protection",14,white));Button lb=button("VIEW LIVE LOCK",false);lb.setOnClickListener(v->liveLock());lock.addView(lb,new LinearLayout.LayoutParams(-1,48));content.addView(lock);
  }
  private void signal(){
    header("SIGNAL CENTER","Normal Auto only • mirrors the Normal strategy feed");
    LinearLayout c=card();c.addView(tv("ACTIVE NORMAL SETUP",13,gold));manualSignal=tv(lastNormalSignal==null?"No Normal Auto signal yet. Start Normal Auto from the AUTO tab.":format(lastNormalSignal),12,white);manualSignal.setPadding(0,10,0,10);c.addView(manualSignal);if(lastNormalSignal!=null){vision=new SignalChartView(this);vision.setSignal(lastNormalSignal);c.addView(vision,new LinearLayout.LayoutParams(-1,440));Button cp=button("COPY SIGNAL FOR TELEGRAM",true);cp.setOnClickListener(v->copySignal());c.addView(cp,new LinearLayout.LayoutParams(-1,50));}content.addView(c);
    LinearLayout info=card();info.addView(tv("POSITION SYNC",13,gold));positionSummary=tv("Synchronizing actual MT5 positions…",11,white); info.addView(positionSummary);content.addView(info);
  }
  private void scan(){
    header("CPD SCANNER","TRADEBUDDY-STYLE CHART REVIEW • screenshot + live M5/M15/H1/H4 confirmation");
    LinearLayout input=card();
    input.addView(tv("1 • CHOOSE MARKET",13,gold));
    pairSpinner=new Spinner(this); pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS)); input.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));
    input.addView(tv("2 • ADD CHART SCREENSHOT",13,gold));
    LinearLayout row=new LinearLayout(this); Button up=button("UPLOAD / CAPTURE CHART",true); up.setOnClickListener(v->pick()); Button go=button("ANALYZE CHART",false); go.setOnClickListener(v->runScanner()); row.addView(up,new LinearLayout.LayoutParams(0,52,1)); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,52,1); gp.setMargins(8,0,0,0); row.addView(go,gp); input.addView(row);
    chartPreview=new ImageView(this); chartPreview.setScaleType(ImageView.ScaleType.CENTER_INSIDE); chartPreview.setBackground(box(Color.rgb(9,13,19),18)); chartPreview.setAdjustViewBounds(true); chartPreview.setMinimumHeight(230); if(uploadedChart!=null) chartPreview.setImageBitmap(uploadedChart); input.addView(chartPreview,new LinearLayout.LayoutParams(-1,230));
    visualInfo=tv(uploadedChart==null?"No chart uploaded yet.":ChartVisualContext.describe(uploadedChart),10,muted); visualInfo.setPadding(0,9,0,0); input.addView(visualInfo);
    input.addView(tv("3 • OPTIONAL ANALYSIS INSTRUCTION",13,gold)); scannerInstruction=new EditText(this); scannerInstruction.setHint("Example: Find a confirmed breakout and only return BUY/SELL if M5-M15-H1-H4 agree."); scannerInstruction.setTextColor(white); scannerInstruction.setHintTextColor(muted); scannerInstruction.setMinLines(2); input.addView(scannerInstruction,new LinearLayout.LayoutParams(-1,90)); content.addView(input);
    LinearLayout result=card(); result.addView(tv("CPD SCANNER REPORT",13,gold)); scannerResult=tv("WAITING FOR CHART ANALYSIS\n\nUpload a chart or choose a pair, then tap ANALYZE CHART.\n\nThe scanner can return BUY, SELL or WAIT.",12,white); scannerResult.setPadding(0,12,0,12); result.addView(scannerResult); Button copy=button("COPY C.P.D SCANNER SIGNAL",true); copy.setOnClickListener(v->copyScannerSignal()); result.addView(copy,new LinearLayout.LayoutParams(-1,50)); content.addView(result);
  }
  private void loadBridgeConfig(){accountMode=prefs.getString("accountMode","DEMO");String prefix="LIVE".equalsIgnoreCase(accountMode)?"live":"demo";bridge.configure(prefs.getString(prefix+"Login",prefs.getString("login","")),prefs.getString(prefix+"Server",prefs.getString("server","")),prefs.getString("url",""),prefs.getString("token",""));}
  private void saveBridgeConfig(String login,String server,String url,String token){prefs.edit().putString("login",login).putString("server",server).putString("url",url).putString("token",token).apply();bridge.configure(login,server,url,token);}
  private void mt5(){
    header("MT5 ACCOUNT CENTER","DEMO + LIVE • exact account-mode verification before every command");
    LinearLayout mode=card();mode.addView(tv("ACTIVE ACCOUNT MODE",13,gold));
    Spinner sm=new Spinner(this);String[] modes={"DEMO","LIVE"};sm.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,modes));sm.setSelection("LIVE".equals(accountMode)?1:0);mode.addView(sm,new LinearLayout.LayoutParams(-1,52));
    Button use=button("USE SELECTED ACCOUNT",true);use.setOnClickListener(v->{accountMode=String.valueOf(sm.getSelectedItem());prefs.edit().putString("accountMode",accountMode).apply();String px="LIVE".equalsIgnoreCase(accountMode)?"live":"demo";bridge.configure(prefs.getString(px+"Login",""),prefs.getString(px+"Server",""),prefs.getString("url",""),prefs.getString("token",""));refreshBridgeStatus();Toast.makeText(this,"C.P.D will only accept "+accountMode+" account data for this session.",Toast.LENGTH_SHORT).show();});mode.addView(use,new LinearLayout.LayoutParams(-1,50));content.addView(mode);
    LinearLayout c=card();c.addView(tv("EXNESS MT5 CONNECTION",13,gold));connectionState=tv("● BRIDGE STATUS\nCHECKING...",14,green);c.addView(connectionState);
    Button b=button("CONNECT / CONFIGURE ACCOUNT",true);b.setOnClickListener(v->bridgeDialog());c.addView(b,new LinearLayout.LayoutParams(-1,50));
    Button test=button("REFRESH ACCOUNT STATUS",false);test.setOnClickListener(v->refreshBridgeStatus());c.addView(test,new LinearLayout.LayoutParams(-1,50));content.addView(c);
    LinearLayout how=card();how.addView(tv("HOW THIS REAL CONNECTION WORKS",13,gold));how.addView(tv("Android app → CPD Bridge → MT5 terminal → Exness. The MT5 terminal/EA is what actually authenticates the broker account. The app can store the account label, login, server and a masked password field, but it does not pretend to log directly into Exness through a public REST API.",11,white));content.addView(how);
    LinearLayout live=card();live.addView(tv("LIVE TRADING CONTROL",14,red));live.addView(tv(liveEnabled?"● LIVE FEATURE ENABLED • actual REAL-account verification required":"○ LIVE FEATURE AVAILABLE • enable it after reading the safety confirmation",12,white));
    Button le=button(liveEnabled?"DISABLE LIVE EXECUTION":"ENABLE LIVE EXECUTION",!liveEnabled);le.setOnClickListener(v->toggleLive());live.addView(le,new LinearLayout.LayoutParams(-1,50));content.addView(live);refreshBridgeStatus();
  }
  private void toggleLive(){
    if(liveEnabled){liveEnabled=false;prefs.edit().putBoolean("liveEnabled",false).apply();Toast.makeText(this,"Live execution disabled.",Toast.LENGTH_SHORT).show();show("MT5");return;}
    new AlertDialog.Builder(this).setTitle("ENABLE LIVE TRADING").setMessage("This enables C.P.D to send commands only when the MT5 bridge reports ACCOUNT_TRADE_MODE_REAL and the selected account mode is LIVE. DEMO accounts will still be rejected. Review your lot size, SL and TP before using a live account.").setNegativeButton("CANCEL",null).setPositiveButton("ENABLE LIVE", (d,w)->{liveEnabled=true;prefs.edit().putBoolean("liveEnabled",true).apply();show("MT5");}).show();
  }
  private void loadAggressiveConfig(){
    agBaseLot=prefs.getFloat("agBaseLot",0.01f); agMultiplier=prefs.getFloat("agMultiplier",1.50f); agMaxLot=prefs.getFloat("agMaxLot",2.55f); agAddDistanceAtr=prefs.getFloat("agAddDistanceAtr",0.50f); agLockPct=prefs.getFloat("agLockPct",5.0f); agMarginFloor=prefs.getFloat("agMarginFloor",150.0f); agMaxPositions=prefs.getInt("agMaxPositions",20); agCooldownSec=prefs.getInt("agCooldownSec",5); agDirection=prefs.getString("agDirection","FOLLOW_SIGNAL"); agProfitBank=prefs.getString("agProfitBank","0.80R / 1.60R / 2.60R");
  }
  private void saveAggressiveConfig(){prefs.edit().putFloat("agBaseLot",(float)agBaseLot).putFloat("agMultiplier",(float)agMultiplier).putFloat("agMaxLot",(float)agMaxLot).putFloat("agAddDistanceAtr",(float)agAddDistanceAtr).putFloat("agLockPct",(float)agLockPct).putFloat("agMarginFloor",(float)agMarginFloor).putInt("agMaxPositions",agMaxPositions).putInt("agCooldownSec",agCooldownSec).putString("agDirection",agDirection).putString("agProfitBank",agProfitBank).apply();}
  private EditText numField(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setInputType(2|0x2000);e.setTextColor(white);return e;}
  private void aggressiveSettingsDialog(){
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,0,8,0);
    box.addView(tv("VIDEO-INSPIRED PROFILE",12,gold));box.addView(tv("The uploaded video shows rapid XAUUSD multi-position scaling, increasing lot size and aggressive profit growth. These controls let you define that behavior without hard-coding it.",10,muted));
    EditText base=numField("Base lot",String.valueOf(agBaseLot));EditText mult=numField("Lot multiplier",String.valueOf(agMultiplier));EditText max=numField("Maximum lot",String.valueOf(agMaxLot));EditText maxPos=numField("Maximum open positions",String.valueOf(agMaxPositions));EditText dist=numField("Add-position distance (ATR)",String.valueOf(agAddDistanceAtr));EditText lock=numField("High-water-mark lock %",String.valueOf(agLockPct));EditText margin=numField("Minimum margin level %",String.valueOf(agMarginFloor));EditText cool=numField("Cooldown seconds",String.valueOf(agCooldownSec));
    box.addView(base);box.addView(mult);box.addView(max);box.addView(maxPos);box.addView(dist);box.addView(lock);box.addView(margin);box.addView(cool);
    Spinner dir=new Spinner(this);String[] dirs={"FOLLOW_SIGNAL","LONG_ONLY","SHORT_ONLY","REVERSAL_ONLY"};dir.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,dirs));for(int i=0;i<dirs.length;i++)if(dirs[i].equals(agDirection))dir.setSelection(i);box.addView(dir);
    Spinner bank=new Spinner(this);String[] banks={"0.80R / 1.60R / 2.60R","1R / 2R / 3R","NO STAGED BANKING"};bank.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,banks));for(int i=0;i<banks.length;i++)if(banks[i].equals(agProfitBank))bank.setSelection(i);box.addView(bank);
    new AlertDialog.Builder(this).setTitle("⚙ AGGRESSIVE AUTO SETTINGS").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE SETTINGS",(d,w)->{try{agBaseLot=Double.parseDouble(base.getText().toString());agMultiplier=Double.parseDouble(mult.getText().toString());agMaxLot=Double.parseDouble(max.getText().toString());agMaxPositions=Integer.parseInt(maxPos.getText().toString());agAddDistanceAtr=Double.parseDouble(dist.getText().toString());agLockPct=Double.parseDouble(lock.getText().toString());agMarginFloor=Double.parseDouble(margin.getText().toString());agCooldownSec=Integer.parseInt(cool.getText().toString());agDirection=String.valueOf(dir.getSelectedItem());agProfitBank=String.valueOf(bank.getSelectedItem());if(agBaseLot<=0||agMultiplier<1||agMaxLot<agBaseLot||agMaxPositions<1||agAddDistanceAtr<0||agLockPct<=0||agMarginFloor<0||agCooldownSec<0)throw new IllegalArgumentException();saveAggressiveConfig();Toast.makeText(this,"Aggressive settings saved for DEMO testing.",Toast.LENGTH_LONG).show();}catch(Exception ex){Toast.makeText(this,"Invalid settings. Nothing was changed.",Toast.LENGTH_LONG).show();}}).show();
  }
  private void lessons(){
    header("C.P.D ACADEMY","10 simple trading lessons • plain English + visual examples");
    String[] titles={
      "1. Difference Between Trading and Gambling",
      "2. How to Be Profitable in Forex and Binary",
      "3. Mindset of a Profitable Trader",
      "4. How to Grow a Small Account to a Larger One",
      "5. When to Trade and When Not to Trade",
      "6. How to Identify a Strong and Weak Trend",
      "7. How to Identify True and False Chart Patterns",
      "8. How to Read Candlesticks and Charts",
      "9. How to Identify Strong and Weak Support and Resistance",
      "10. How to Place a Trade: Entry, TP and SL"
    };
    for(int i=0;i<titles.length;i++){
      final int k=i; LinearLayout c=card(); TextView h=tv("◆ "+titles[i],14,i==8?cyan:gold);h.setTypeface(null,Typeface.BOLD);c.addView(h);
      TextView d=tv(lessonShort(i),10,muted);d.setPadding(0,6,0,8);c.addView(d);
      Button open=button("OPEN C.P.D LESSON",i==8);open.setOnClickListener(v->lessonDialog(k));c.addView(open,new LinearLayout.LayoutParams(-1,46));content.addView(c);
    }
  }
  private String lessonShort(int i){
    String[] x={
      "Trading uses a plan, risk and repeatable rules. Gambling relies mainly on chance and emotion.",
      "Profitability is about positive expectancy, controlled losses and disciplined execution. Binary options have different payout and expiry mechanics.",
      "A profitable mindset focuses on process, patience, risk limits and accepting losses without revenge trading.",
      "Small accounts need controlled position size, realistic targets and compounding discipline. There is no guaranteed shortcut.",
      "Trade when your setup, market conditions and liquidity are suitable. Stand aside when data is missing or conditions conflict.",
      "A strong trend makes clear higher highs/higher lows or lower highs/lower lows and shows momentum. Weak trends break structure easily.",
      "A true pattern has structure plus confirmation. A false breakout often breaks a level then closes back inside it.",
      "Candles show open, high, low and close. Read candle shape together with location, trend and nearby levels.",
      "Strong levels usually have repeated reactions, clean structure and meaningful distance from price. Weak levels have little confirmation.",
      "Entry is where the setup triggers. SL defines the invalidation point. TP defines the planned profit target. Risk comes first."
    };
    return x[i];
  }
  private String lessonBody(int i){
    String[] x={
      "Trading is a decision process. You choose a setup, define the amount you can lose, enter only when your rules are met, and record the result. Gambling becomes dangerous when decisions are driven by luck, excitement or chasing losses. A trading plan cannot remove losses; it makes risk measurable.",
      "There is no guaranteed profitable strategy. In forex, a positive edge can come from setups where the average gain relative to the average loss and win rate produce positive expectancy after costs. Binary products have fixed expiry/payout structures and can lose the full stake, so understand the product rules before risking money.",
      "Think in series, not one trade. Follow the same checklist, accept that a valid setup can lose, avoid revenge trades, and protect your downside. Confidence should describe evidence in the setup, not certainty about the future.",
      "Growth should come from controlled risk and consistency, not oversized lots. A small account can also be lost quickly when leverage and position size are too large. Compound only after you have tested your process and keep a hard loss limit.",
      "Trade when the market has usable liquidity, a clear setup, acceptable spread and enough data. Do not force a trade when M5/M15/H1/H4 disagree, when the feed is offline, or when your risk limits fail.",
      "Bullish strength often shows higher highs and higher lows with decisive candles. Bearish strength shows lower highs and lower lows. A weak trend may have overlapping candles, broken structure and poor follow-through.",
      "A true breakout closes beyond a level with follow-through and supporting structure. A false breakout can pierce the level, fail to hold it and return inside the range. Wait for confirmation instead of treating every wick as a breakout.",
      "A candle has four key prices: open, high, low and close. A long lower wick can show rejection of lower prices; a strong body can show displacement. Never read one candle alone—use its location and the surrounding structure.",
      "Strong support/resistance can have multiple meaningful touches and strong reactions. Weak levels may have one reaction or poor follow-through. Clustered levels can matter more than a single isolated line. When price is too close to opposing levels, risk/reward can become poor.",
      "Entry is the trigger price. Stop Loss sits beyond the price level that proves the setup wrong. Take Profit is placed at a planned target such as a structural level or risk multiple. Always check spread, lot size, margin and the broker's minimum stop distance."
    };
    return x[i];
  }
  private void lessonDialog(int i){
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(4,0,4,0);
    TextView body=tv(lessonBody(i),12,white);body.setPadding(0,4,0,14);box.addView(body);
    LessonDiagramView diagram=new LessonDiagramView(this,i);box.addView(diagram,new LinearLayout.LayoutParams(-1,270));
    TextView note=tv("C.P.D visual example — educational illustration, not a prediction or guaranteed trade.",10,muted);note.setPadding(0,8,0,0);box.addView(note);
    new AlertDialog.Builder(this).setTitle("C.P.D LESSON "+(i+1)).setView(box).setPositiveButton("DONE",null).show();
  }
  private class LessonDiagramView extends View{
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); int type;
    LessonDiagramView(Context c,int t){super(c);type=t;p.setStrokeWidth(5);setBackground(gradient(new int[]{Color.rgb(8,13,25),Color.rgb(13,20,38)},20));}
    protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(66,82,112));c.drawLine(35,h-45,w-25,h-45,p);c.drawLine(35,25,35,h-45,p);
      if(type==8){p.setColor(red);c.drawLine(45,70,w-45,70,p);p.setColor(green);c.drawLine(45,h-85,w-45,h-85,p);label(c,"RESISTANCE",55,58,red);label(c,"SUPPORT",55,h-92,green);}
      else if(type==9){p.setColor(cyan);c.drawLine(65,150,w-65,150,p);p.setColor(red);c.drawLine(65,205,w-65,205,p);p.setColor(green);c.drawLine(65,95,w-65,95,p);label(c,"SL",w-90,200,red);label(c,"ENTRY",w/2-30,145,cyan);label(c,"TP",w-75,90,green);}
      else if(type==6){p.setColor(red);c.drawLine(70,80,150,145,p);c.drawLine(150,145,230,90,p);c.drawLine(230,90,310,160,p);c.drawLine(310,160,w-65,110,p);label(c,"FALSE BREAK",w/2-45,45,red);}
      else if(type==7){p.setColor(gold);for(int i=0;i<6;i++){float x=70+i*55;float y=h-70-i*25;c.drawLine(x,y-25,x,y+25,p);c.drawRect(x-10,y-8,x+10,y+8,p);}label(c,"CANDLE",60,45,gold);}
      else if(type==5){p.setColor(green);c.drawLine(70,h-70,145,100,p);c.drawLine(145,100,220,h-140,p);c.drawLine(220,h-140,300,90,p);c.drawLine(300,90,w-65,60,p);label(c,"STRONG TREND",w/2-55,45,green);}
      else if(type==4){p.setColor(blue);c.drawLine(65,150,150,150,p);c.drawLine(150,150,235,150,p);c.drawLine(235,150,w-65,75,p);label(c,"WAIT FOR CONFIRMATION",w/2-80,55,blue);}
      else if(type==3){p.setColor(gold);c.drawLine(65,h-65,w-65,55,p);label(c,"CONTROL RISK",w/2-45,75,gold);}
      else if(type==2){p.setColor(cyan);c.drawLine(65,h-70,150,125,p);c.drawLine(150,125,235,h-145,p);c.drawLine(235,h-145,w-65,75,p);label(c,"PROCESS > EMOTION",w/2-75,55,cyan);}
      else if(type==1){p.setColor(purple);c.drawRect(90,85,220,h-75,p);c.drawRect(250,105,380,h-105,p);label(c,"EXPECTANCY",w/2-45,55,purple);}
      else {p.setColor(gold);c.drawLine(65,h-70,150,135,p);c.drawLine(150,135,235,h-125,p);c.drawLine(235,h-125,w-65,80,p);label(c,"PLAN • RISK • REVIEW",w/2-65,55,gold);}
    }
    void label(Canvas c,String s,float x,float y,int color){p.setStyle(Paint.Style.FILL);p.setTextSize(20);p.setTypeface(Typeface.DEFAULT_BOLD);p.setColor(color);c.drawText(s,x,y,p);p.setStyle(Paint.Style.STROKE);}
  }
  private void performance(){
    header("PERFORMANCE DASHBOARD","Actual MT5 demo history • rolling 7-day and 30-day analytics");
    LinearLayout live=card(); live.addView(tv("ACCOUNT / P&L",13,gold)); accountSummary=tv("Synchronizing…",12,white); live.addView(accountSummary); content.addView(live);
    LinearLayout wr=card(); wr.addView(tv("WEEKLY WIN RATE",13,gold)); TextView wv=tv("Loading MT5 history…",18,white); wv.setPadding(0,8,0,8); wr.addView(wv); content.addView(wr);
    LinearLayout mo=card(); mo.addView(tv("MONTHLY WIN RATE",13,blue)); TextView mv=tv("Loading MT5 history…",18,white); mv.setPadding(0,8,0,8); mo.addView(mv); content.addView(mo);
    LinearLayout detail=card(); detail.addView(tv("WHAT IS COUNTED",13,gold)); detail.addView(tv("Win rate is calculated from closed MT5 deals reported by the bridge. Open floating P/L is shown separately from closed net P/L. The dashboard does not invent results when the MT5 history is unavailable.",11,muted)); content.addView(detail);
    io.execute(()->{try{JSONObject a=bridge.accountInfo(),perf=bridge.performance();JSONObject w=perf.optJSONObject("weekly"),m=perf.optJSONObject("monthly");if(w==null)w=new JSONObject();if(m==null)m=new JSONObject();double eq=a.optDouble("equity",0),bal=a.optDouble("balance",0);String ac="Balance "+fmtMoney(bal)+"  •  Equity "+fmtMoney(eq)+"  •  Floating P/L "+fmtMoney(eq-bal);String ws=rate(w)+"\\n"+w.optInt("wins",0)+" wins • "+w.optInt("losses",0)+" losses • "+w.optInt("closed",0)+" closed • Net "+fmtMoney(w.optDouble("net",0));String ms=rate(m)+"\\n"+m.optInt("wins",0)+" wins • "+m.optInt("losses",0)+" losses • "+m.optInt("closed",0)+" closed • Net "+fmtMoney(m.optDouble("net",0));runOnUiThread(()->{accountSummary.setText(ac);wv.setText(ws);mv.setText(ms);});}catch(Exception e){runOnUiThread(()->{accountSummary.setText("MT5 history unavailable\\n"+e.getMessage());wv.setText("—");mv.setText("—");});}});
  }
  private void settings(){
    header("SETTINGS","Configure how C.P.D SUPER WIZARD AI should operate");
    LinearLayout ag=card();ag.addView(tv("AGGRESSIVE AUTO",16,blue));ag.addView(tv("Separate engine • settings are saved on this device • DEMO testing only",11,muted));ag.addView(tv("Base lot: "+agBaseLot+"\nMultiplier: "+agMultiplier+"x\nMax lot: "+agMaxLot+"\nMax positions: "+agMaxPositions+"\nAdd distance: "+agAddDistanceAtr+" ATR\nHigh-water lock: "+agLockPct+"%\nMargin floor: "+agMarginFloor+"%\nDirection: "+agDirection+"\nProfit banking: "+agProfitBank,11,white));Button edit=button("⚙ EDIT AGGRESSIVE MODE",true);edit.setOnClickListener(v->aggressiveSettingsDialog());ag.addView(edit,new LinearLayout.LayoutParams(-1,52));content.addView(ag);
    LinearLayout sig=card();sig.addView(tv("SIGNAL CENTER",15,gold));sig.addView(tv("Normal Auto signals only. Every posted signal includes a COPY SIGNAL button for the full Telegram-ready text.",11,white));Button learn=button("◆ OPEN C.P.D ACADEMY",true);learn.setOnClickListener(v->lessons());sig.addView(learn,new LinearLayout.LayoutParams(-1,48));content.addView(sig);
    LinearLayout safe=card();safe.addView(tv("SAFETY",15,red));safe.addView(tv((liveEnabled?"● LIVE FEATURE ENABLED.":"○ LIVE FEATURE AVAILABLE.")+" Actual account-mode verification remains mandatory.",11,white));content.addView(safe);
  }
  private void bridgeDialog(){
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,4,8,0);
    String prefix="LIVE".equalsIgnoreCase(accountMode)?"live":"demo";
    EditText login=new EditText(this);login.setHint(accountMode+" MT5 login number");login.setText(prefs.getString(prefix+"Login",""));box.addView(login);
    EditText server=new EditText(this);server.setHint("Exact Exness "+accountMode+" MT5 server");server.setText(prefs.getString(prefix+"Server",""));box.addView(server);
    EditText password=new EditText(this);password.setHint(accountMode+" MT5 password (stored locally / not sent to bridge)");password.setText(prefs.getString(prefix+"Password",""));password.setInputType(0x81);box.addView(password);
    EditText url=new EditText(this);url.setHint("CPD Bridge HTTPS URL");url.setText(prefs.getString("url",""));box.addView(url);
    EditText token=new EditText(this);token.setHint("Bridge secret token");token.setText(prefs.getString("token",""));token.setInputType(0x81);box.addView(token);
    TextView note=tv("The MT5 password field is a local reference for your account setup. The actual broker login is performed by the MT5 terminal/EA. The app verifies the terminal-reported account mode before sending any command.",10,muted);note.setPadding(0,8,0,0);box.addView(note);
    new AlertDialog.Builder(this).setTitle("CONFIGURE EXNESS MT5").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE & TEST",(d,w)->{String l=login.getText().toString().trim(),s=server.getText().toString().trim(),pw=password.getText().toString(),u=url.getText().toString().trim(),t=token.getText().toString().trim();prefs.edit().putString(prefix+"Login",l).putString(prefix+"Server",s).putString(prefix+"Password",pw).apply();saveBridgeConfig(l,s,u,t);refreshBridgeStatus();}).show();
  }
  private void refreshBridgeStatus(){if(connectionState==null)return;if(!bridge.hasBridge()){connectionState.setText("● BRIDGE STATUS\nNOT CONFIGURED\n\nEnter your CPD Bridge URL and token.");return;}io.execute(()->{try{JSONObject h=bridge.health();JSONObject a=bridge.accountInfo();String mode=a.optString("mode","UNKNOWN");runOnUiThread(()->{boolean demoOk="DEMO".equalsIgnoreCase(accountMode)&&"DEMO".equalsIgnoreCase(mode);boolean liveOk="LIVE".equalsIgnoreCase(accountMode)&&liveEnabled&&"REAL".equalsIgnoreCase(mode);refreshAccountPanels();connectionState.setText("● BRIDGE ONLINE\nACTUAL ACCOUNT: "+mode+"\nSELECTED MODE: "+accountMode+"\nLOGIN: "+a.optString("login",bridge.getServer())+"\nBALANCE: "+a.optDouble("balance",0)+"\nEQUITY: "+a.optDouble("equity",0)+"\n"+((demoOk||liveOk)?"EXECUTION READY":"⚠ MODE MISMATCH / EXECUTION BLOCKED"));});}catch(Exception e){runOnUiThread(()->connectionState.setText("● BRIDGE OFFLINE\n"+e.getMessage()));}});}

  private void refreshAccountPanels(){
    if(!bridge.isConfigured()) return;
    io.execute(()->{try{
      JSONObject a=bridge.accountInfo(); JSONObject perf=bridge.performance(); JSONArray ps=bridge.positions();
      String mode=a.optString("mode","UNKNOWN"); double bal=a.optDouble("balance",0),eq=a.optDouble("equity",0),floating=eq-bal;
      String acct="ACCOUNT  "+a.optString("login","")+"  •  "+mode+"\nBALANCE   "+fmtMoney(a.optDouble("balance",0))+"\nEQUITY    "+fmtMoney(a.optDouble("equity",0))+"\nFLOATING P/L  "+fmtMoney(floating)+"\nCURRENCY  "+a.optString("currency","USD");
      StringBuilder pos=new StringBuilder(); pos.append("OPEN POSITIONS  ").append(ps.length()).append("\\n");
      for(int i=0;i<ps.length();i++){JSONObject p=ps.optJSONObject(i); if(p==null)continue; pos.append(p.optString("symbol","")) .append("  ").append(p.optString("type","")) .append("  lot ").append(p.optDouble("volume",0)).append("  P/L ").append(fmtMoney(p.optDouble("profit",0))).append("\\nEntry ").append(fmtPrice(p.optDouble("entry",0))).append("  SL ").append(fmtPrice(p.optDouble("sl",0))).append("  TP ").append(fmtPrice(p.optDouble("tp",0))).append("\\n");}
      JSONObject w=perf.optJSONObject("weekly"),m=perf.optJSONObject("monthly"); String per="WEEKLY  "+rate(w)+"  •  "+w.optInt("wins",0)+"W / "+w.optInt("losses",0)+"L  • Net "+fmtMoney(w.optDouble("net",0))+"\\nMONTHLY "+rate(m)+"  •  "+m.optInt("wins",0)+"W / "+m.optInt("losses",0)+"L  • Net "+fmtMoney(m.optDouble("net",0));
      runOnUiThread(()->{if(accountSummary!=null)accountSummary.setText(acct); if(positionSummary!=null)positionSummary.setText(pos.toString()); if(performanceSummary!=null)performanceSummary.setText(per);});
    }catch(Exception e){runOnUiThread(()->{if(accountSummary!=null)accountSummary.setText("MT5 SYNC ERROR\\n"+e.getMessage());});}});
  }
  private String rate(JSONObject x){if(x==null)return "—";return String.format(Locale.US,"Win rate %.1f%%",x.optDouble("winRate",0));}
  private String fmtMoney(double x){return String.format(Locale.US,"%.2f",x);}
  private String fmtPrice(double x){return x==0?"—":String.format(Locale.US,"%.5f",x);}

  private void liveLock(){new AlertDialog.Builder(this).setTitle("🔒 LIVE TRADING LOCKED").setMessage("Real-money execution is disabled. This is intentional. Demo testing comes first. The app should never silently switch a real MT5 account into an executable state.").setPositiveButton("KEEP LOCKED",null).show();}
  private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,9001);}
  @Override protected void onActivityResult(int r,int code,Intent d){super.onActivityResult(r,code,d);if(r!=9001||code!=RESULT_OK||d==null||d.getData()==null)return;try{Uri u=d.getData();uploadedChart=MediaStore.Images.Media.getBitmap(getContentResolver(),u);if(visualInfo!=null)visualInfo.setText(ChartVisualContext.describe(uploadedChart)); if(chartPreview!=null)chartPreview.setImageBitmap(uploadedChart);}catch(Exception e){if(visualInfo!=null)visualInfo.setText("Could not read chart: "+e.getMessage());}}
  private String selected(){return pairSpinner==null?"EURUSD":String.valueOf(pairSpinner.getSelectedItem());}
  private void runScanner(){final String sym=selected();if(scannerResult!=null)scannerResult.setText("SCANNING "+sym+"\n\nChart Vision → Structure → Pattern → S/R → Liquidity → Momentum → MTF → Risk…");io.execute(()->{CPDScannerEngine.ScanResult r=CPDScannerEngine.scan(sym,market,uploadedChart!=null);runOnUiThread(()->scannerResult.setText(scannerText(r)));});}
  private String scannerText(CPDScannerEngine.ScanResult r){return "PAIR  "+r.symbol+"\n\nVERDICT        "+r.direction+"\nCONFIDENCE     "+String.format(Locale.US,"%.0f%%",r.confidence)+"\nMARKET STATE   "+r.marketState+"\n\nMULTI-TIMEFRAME\nM5   "+r.timeframes[3]+"\nM15  "+r.timeframes[2]+"\nH1   "+r.timeframes[1]+"\nH4   "+r.timeframes[0]+"\n\nTREND          "+r.trend+"\nVOLATILITY     "+r.volatility+"\nPATTERN        "+r.pattern+"\nSUPPORT/RES.   "+r.supportResistance+"\nMOMENTUM       "+r.momentum+"\n\nSETUP\nEntry          "+r.entry+"\nStop Loss      "+r.sl+"\nTake Profit    "+r.tp+"\nATR %          "+String.format(Locale.US,"%.3f",r.atrPercent)+"\n\nANALYSIS\n"+r.reason+"\n\nSCREENSHOT MODE: "+(r.screenshotReceived?"VISUAL CONTEXT ATTACHED":"NO SCREENSHOT")+"\nThe scanner will WAIT when live timeframe evidence conflicts.";}
  private boolean hasOpenPosition(String sym){try{org.json.JSONArray ps=bridge.positions();for(int i=0;i<ps.length();i++){org.json.JSONObject p=ps.optJSONObject(i);if(p!=null&&sym.equalsIgnoreCase(p.optString("symbol","")))return true;}}catch(Exception ignored){}return false;}
  private void scanNormal(){final String sym=selected();io.execute(()->{try{List<StrategyEngine.Candle> h4=list(market.candles(sym,"4h",250)),h1=list(market.candles(sym,"1h",250)),m15=list(market.candles(sym,"15m",160)),m5=list(market.candles(sym,"5m",160));org.json.JSONObject p=market.price(sym);StrategyEngine.Signal s=new StrategyEngine().evaluate(sym,h4,h1,m15,m5,p.optDouble("bid"),p.optDouble("ask"),false);if(s.valid){lastNormalSignal=s; boolean canExecute=bridge.isConfigured(); if(canExecute){ try { JSONObject a=bridge.accountInfo(); String mode=a.optString("mode",""); boolean demoOk="DEMO".equalsIgnoreCase(accountMode)&&"DEMO".equalsIgnoreCase(mode); boolean liveOk="LIVE".equalsIgnoreCase(accountMode)&&liveEnabled&&"REAL".equalsIgnoreCase(mode); if(!(demoOk||liveOk)) canExecute=false; } catch(Exception ex){canExecute=false;} } if(canExecute && hasOpenPosition(sym)){runOnUiThread(()->Toast.makeText(this,"Existing "+sym+" position detected. C.P.D will not duplicate the trade.",Toast.LENGTH_SHORT).show()); return;} if(canExecute){ JSONObject t=new JSONObject(); t.put("mode","NORMAL"); t.put("action","OPEN"); t.put("selected_mode",accountMode); t.put("live_enabled",liveEnabled); t.put("direction",s.dir>0?"BUY":"SELL"); t.put("symbol",s.symbol); t.put("volume",0.01); t.put("sl",s.sl); t.put("tp",s.tp); JSONObject r=bridge.trade(t); final String q=r.optString("status",r.optString("accepted","QUEUED")); runOnUiThread(()->{topStatus.setText("NORMAL AUTO  •  DEMO ORDER QUEUED  •  "+sym);Toast.makeText(this,"MT5 "+accountMode+" order queued: "+q,Toast.LENGTH_LONG).show();}); } else runOnUiThread(()->{topStatus.setText("NORMAL AUTO  •  SIGNAL READY  •  "+sym);Toast.makeText(this,"Signal ready. Connect the "+accountMode+" MT5 Bridge to enable execution.",Toast.LENGTH_LONG).show();});}else runOnUiThread(()->topStatus.setText("NORMAL AUTO  •  WAIT  •  "+sym));}catch(Exception e){runOnUiThread(()->topStatus.setText("NORMAL AUTO  •  DATA ERROR"));}});}
  private List<StrategyEngine.Candle> list(org.json.JSONArray a){List<StrategyEngine.Candle> r=new ArrayList<>();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null)r.add(new StrategyEngine.Candle(a.optJSONObject(i)));return r;}
  private String format(StrategyEngine.Signal s){return "🚨 C.P.D SUPER WIZARD AI\n\n"+s.symbol+"  •  "+(s.dir>0?"BUY":"SELL")+"\n\nEntry  "+fmt(s.entry)+"\nSL     "+fmt(s.sl)+"\nTP1    "+fmt(s.tp1)+"\nTP2    "+fmt(s.tp2)+"\nTP3    "+fmt(s.tp3)+"\nFinal  "+fmt(s.tp)+"\n\nConfidence  "+String.format(Locale.US,"%.0f/99",s.confidence)+"\nMode  NORMAL\n\nPattern: "+s.pattern+" ("+s.patternQuality+")\nS/R: "+s.sr+" ("+s.srQuality+")\nBreakout: "+s.breakout+"\n"+s.reason+"\n\nRisk-managed execution only.";}
  private void copyScannerSignal(){if(scannerResult==null)return;String text=scannerResult.getText().toString();if(text.contains("WAITING FOR CHART ANALYSIS")){Toast.makeText(this,"No scanner result to copy.",Toast.LENGTH_SHORT).show();return;}((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("CPD Scanner Signal",text));Toast.makeText(this,"C.P.D Scanner result copied.",Toast.LENGTH_SHORT).show();}
  private void copySignal(){if(lastNormalSignal==null){Toast.makeText(this,"No Normal signal to copy.",Toast.LENGTH_SHORT).show();return;}((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("CPD Signal",format(lastNormalSignal)));Toast.makeText(this,"Signal copied.",Toast.LENGTH_SHORT).show();}
  private String fmt(double x){return String.format(Locale.US,"%.5f",x);}
  @Override protected void onResume(){super.onResume();bridgeHandler.post(bridgeRefresh);}
  @Override protected void onPause(){bridgeHandler.removeCallbacks(bridgeRefresh);super.onPause();}
  @Override protected void onDestroy(){bridgeHandler.removeCallbacks(bridgeRefresh);normalHandler.removeCallbacks(normalLoop);io.shutdownNow();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
