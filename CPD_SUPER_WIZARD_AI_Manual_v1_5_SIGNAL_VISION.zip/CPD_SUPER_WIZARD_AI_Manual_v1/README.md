# C.P.D SUPER WIZARD AI — Manual Signal Vision Edition

V10.35 SMART AGGRESSIVE mobile-first manual trading app.

## New signal features
- Beautiful **C.P.D SIGNAL INCOMING** confirmation stage.
- Two-minute warning before a manual signal is published.
- **AI SETUP VISION** chart showing entry, SL, TP1, TP2, TP3 and final 6R levels.
- One-tap **COPY SIGNAL + REASON + CONFIDENCE**.
- Signal reason and confidence/confluence score shown under every published signal.
- TP1 / TP2 / SL trade-update buttons with notifications and suggested protective-SL action.
- Weekly manual signal journal with signals, wins, losses and win rate.
- Automatic mode remains visible but **LOCKED**. It cannot place orders.

## Important
The setup drawing is an illustrative AI-style visualization, not a broker screenshot. Live market prices/signals still require a supported market-data/MT5 bridge. No Exness password or API secret is required for the manual-only workflow.
