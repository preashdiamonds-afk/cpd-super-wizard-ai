package com.pepestone.app;

import org.json.*; import java.util.*;

/** Deterministic mobile translation of the V10.35 SMART AGGRESSIVE rules. */
public class StrategyEngine {
  public static final double NORMAL_RISK=1.0, AGG_RISK=0.75;
  public static final double MAX_TRADE_RISK=1.0, MAX_PORTFOLIO_RISK=3.0;
  public static final double NORMAL_THRESHOLD=85.0, AGG_THRESHOLD=60.0;
  public static final double MAX_SL_ATR=3.5;
  public static final double[] LADDER={2.0,3.0,4.0,5.0,6.0};

  public static class Candle { double o,h,l,c; long v; String t; Candle(JSONObject x){o=x.optDouble("open");h=x.optDouble("high");l=x.optDouble("low");c=x.optDouble("close");v=x.optLong("tickVolume",x.optLong("volume"));t=x.optString("time");} }
  public static class Signal { boolean valid; int dir; double confidence,entry,sl,tp,atr; String reason=""; String symbol; Signal(String s){symbol=s;} }
  static double ema(List<Candle> r,int p){if(r.size()<p)return 0; double k=2.0/(p+1),e=r.get(r.size()-p).c; for(int i=r.size()-p+1;i<r.size();i++)e=r.get(i).c*k+e*(1-k); return e;}
  static double atr(List<Candle> r,int p){if(r.size()<p+1)return 0; double sum=0; for(int i=r.size()-p;i<r.size();i++){Candle x=r.get(i),q=r.get(i-1);sum+=Math.max(x.h-x.l,Math.max(Math.abs(x.h-q.c),Math.abs(x.l-q.c)));} return sum/p;}
  static double rsi(List<Candle> r,int p){if(r.size()<p+1)return 50; double g=0,l=0; for(int i=r.size()-p;i<r.size();i++){double d=r.get(i).c-r.get(i-1).c;if(d>0)g+=d;else l-=d;} if(l==0)return 100; return 100-100/(1+(g/l));}
  static boolean bullSweep(List<Candle> r,double a){if(r.size()<15)return false; Candle x=r.get(r.size()-2);double prior=r.get(r.size()-3).l;for(int i=r.size()-4;i>=Math.max(0,r.size()-15);i--)prior=Math.min(prior,r.get(i).l);return x.l<prior-0.05*a&&x.c>prior&&(x.c>x.o||Math.abs(x.c-x.o)>=0.35*a);}
  static boolean bearSweep(List<Candle> r,double a){if(r.size()<15)return false; Candle x=r.get(r.size()-2);double prior=r.get(r.size()-3).h;for(int i=r.size()-4;i>=Math.max(0,r.size()-15);i--)prior=Math.max(prior,r.get(i).h);return x.h>prior+0.05*a&&x.c<prior&&(x.c<x.o||Math.abs(x.c-x.o)>=0.35*a);}
  static int structure(List<Candle> r,int d,double a){if(r.size()<30)return 0;int n=r.size();double lh=-1e99,ph=-1e99,ll=1e99,pl=1e99;int fh=0,fl=0;for(int i=n-17;i<n-3;i++){Candle x=r.get(i);if(x.h>lh){ph=lh;lh=x.h;fh++;}if(x.l<ll){pl=ll;ll=x.l;fl++;}}Candle x=r.get(n-2);boolean bosUp=x.c>lh+0.15*a,bosDn=x.c<ll-0.15*a;boolean seqUp=lh>ph+0.15*a&&ll>pl+0.15*a,seqDn=lh<ph-0.15*a&&ll<pl-0.15*a;if(d>0)return seqUp&&bosUp?2:(seqUp||bosUp?1:0);return seqDn&&bosDn?-2:(seqDn||bosDn?-1:0);}
  static boolean disp(List<Candle> r,int d,double a){if(r.size()<8)return false;Candle x=r.get(r.size()-2);double body=Math.abs(x.c-x.o),range=x.h-x.l;if(range<=0)return false;double loc=d>0?(x.c-x.l)/range:(x.h-x.c)/range;return (d>0?x.c>x.o:x.c<x.o)&&body>=0.8*a&&loc>=0.65;}
  static boolean fvg(List<Candle> r,int d,double a){if(r.size()<12)return false;int n=r.size();for(int i=1;i<=8&&i+2<n;i++){Candle x=r.get(n-1-i),z=r.get(n-3-i);if(d>0&&x.l-z.h>=0.05*a&&r.get(n-2).c>=z.h)return true;if(d<0&&z.l-x.h>=0.05*a&&r.get(n-2).c<=z.l)return true;}return false;}
  static boolean trigger(List<Candle> r,int d){if(r.size()<5)return false;Candle x=r.get(r.size()-2),q=r.get(r.size()-3);return d>0?x.c>x.o&&x.c>q.h:x.c<x.o&&x.c<q.l;}
  static boolean fastTrigger(List<Candle> r,int d,double ask,double bid,double a){if(r.size()<5)return false;Candle prev=r.get(r.size()-2);Candle live=r.get(r.size()-1);double px=d>0?ask:bid;double buffer=0.02*a;return d>0?px>prev.h+buffer&&px>live.o:px<prev.l-buffer&&px<live.o;}
  static int pattern(List<Candle> r,StringBuilder name,double a){name.setLength(0);name.append("NONE");if(r.size()<60)return 0;Candle x=r.get(r.size()-2),q=r.get(r.size()-3);double b=Math.abs(x.c-x.o),lw=Math.min(x.o,x.c)-x.l,uw=x.h-Math.max(x.o,x.c);if(q.c<q.o&&x.c>x.o&&x.o<=q.c&&x.c>=q.o){name.setLength(0);name.append("Bullish Engulfing");return 1;}if(q.c>q.o&&x.c<x.o&&x.o>=q.c&&x.c<=q.o){name.setLength(0);name.append("Bearish Engulfing");return -1;}if(lw>=Math.max(2*b,0.25*a)&&uw<=b*0.8&&x.c>x.o){name.setLength(0);name.append("Hammer");return 1;}if(uw>=Math.max(2*b,0.25*a)&&lw<=b*0.8&&x.c<x.o){name.setLength(0);name.append("Shooting Star");return -1;}double hi1=-1e99,hi2=-1e99,lo1=1e99,lo2=1e99;int hi1i=-1,hi2i=-1,lo1i=-1,lo2i=-1;for(int i=3;i<45&&i<r.size();i++){if(r.get(i).h>hi1){hi2=hi1;hi2i=hi1i;hi1=r.get(i).h;hi1i=i;}else if(r.get(i).h>hi2){hi2=r.get(i).h;hi2i=i;}if(r.get(i).l<lo1){lo2=lo1;lo2i=lo1i;lo1=r.get(i).l;lo1i=i;}else if(r.get(i).l<lo2){lo2=r.get(i).l;lo2i=i;}}if(hi1i>0&&hi2i>0&&Math.abs(hi1-hi2)<=0.35*a&&Math.abs(hi1i-hi2i)>=5){name.setLength(0);name.append("Double Top");return -1;}if(lo1i>0&&lo2i>0&&Math.abs(lo1-lo2)<=0.35*a&&Math.abs(lo1i-lo2i)>=5){name.setLength(0);name.append("Double Bottom");return 1;}return 0;}
  static int sr(List<Candle> r,int dir,StringBuilder name,double a){name.setLength(0);name.append("NO_CLEAR_LEVEL");if(r.size()<80)return 0;double px=r.get(r.size()-2).c,sup=1e99,res=-1e99;for(int i=2;i<70&&i<r.size();i++){sup=Math.min(sup,r.get(r.size()-1-i).l);res=Math.max(res,r.get(r.size()-1-i).h);}double tol=.35*a;if(dir>0&&Math.abs(px-sup)<=tol){name.setLength(0);name.append("Support");return 1;}if(dir<0&&Math.abs(px-res)<=tol){name.setLength(0);name.append("Resistance");return 1;}if(dir>0&&Math.abs(px-res)<=tol){name.setLength(0);name.append("Opposing Resistance");return -1;}if(dir<0&&Math.abs(px-sup)<=tol){name.setLength(0);name.append("Opposing Support");return -1;}return 0;}
  static boolean momentum(List<Candle> r,int d){if(r.size()<205)return false;double f=ema(r,50),s=ema(r,200),q=rsi(r,14);if(d>0)return f>s&&q>50&&q<75;return f<s&&q<50&&q>25;}
  static boolean extension(List<Candle> r,int d,double a){double px=r.get(r.size()-2).c,f=ema(r,50);return a>0&&Math.abs(px-f)<=2.5*a;}

  public Signal evaluate(String symbol,List<Candle> h4,List<Candle> h1,List<Candle> m15,List<Candle> m5,double bid,double ask,boolean aggressive){
    Signal s=new Signal(symbol);double e4=ema(h4,50),e42=ema(h4,200),e1=ema(h1,50),e12=ema(h1,200);if(e4==0||e42==0||e1==0||e12==0)return s;
    double c4=h4.get(h4.size()-2).c,c1=h1.get(h1.size()-2).c;int d=(c4>e4&&e4>e42&&c1>e1&&e1>e12)?1:(c4<e4&&e4<e42&&c1<e1&&e1<e12?-1:0);if(d==0)return s;
    double a15=atr(m15,14),a5=atr(m5,14);if(a15<=0||a5<=0)return s;
    int st=structure(m15,d,a15);boolean liq=d>0?bullSweep(m15,a15):bearSweep(m15,a15),dis=disp(m5,d,a5),trig=fastTrigger(m5,d,ask,bid,a5);boolean mom=momentum(m15,d);StringBuilder pn=new StringBuilder(),sn=new StringBuilder();int pd=pattern(m15,pn,a15),sr=sr(m15,d,sn,a15);
    if(st==0||!liq||!dis||!trig)return s;
    double score=20+20+15+15+(mom?5:0)+(pd==d?10:0)+(sr>0?10:0);double total=95; s.confidence=Math.min(95,score);double need=aggressive?60:85;if(s.confidence<need)return s;
    s.dir=d;s.entry=d>0?ask:bid;Candle last=m5.get(m5.size()-2);double swing=d>0?last.l:last.h;for(int i=Math.max(0,m5.size()-7);i<m5.size()-2;i++)swing=d>0?Math.min(swing,m5.get(i).l):Math.max(swing,m5.get(i).h);s.sl=d>0?swing-.20*a15:swing+.20*a15;double risk=Math.abs(s.entry-s.sl);if(risk<=0||risk>MAX_SL_ATR*a15||!extension(m15,d,a15))return s;s.atr=a15;s.tp=d>0?s.entry+6*risk:s.entry-6*risk;s.valid=true;s.reason="HTF+STRUCT+LIQ+DISP+FASTTRIGGER"+(mom?"+MOM":"")+(pd==d?"+PATTERN:"+pn:"")+(sr>0?"+SR:"+sn:"");return s;
  }
  public Signal evaluate(String symbol,List<Candle> h4,List<Candle> h1,List<Candle> m15,List<Candle> m5,double bid,double ask){return evaluate(symbol,h4,h1,m15,m5,bid,ask,false);}
}
