package com.pepestone.app;

import android.app.*;import android.content.*;import android.os.*;import java.util.concurrent.*;import java.util.*;

/** Optional future/live bridge worker. It never enables automatic orders by itself. */
public class TradingService extends Service {
  private ScheduledExecutorService exec; private ExnessMt5Client api; private TradeStateStore state; private TradingController controller; private volatile boolean running; private NotificationHelper notifications; private SignalScheduler signalScheduler; private SignalStore signalStore; private String lastSignalKey=""; private long lastSignalAt=0;
  @Override public void onCreate(){super.onCreate();notifications=new NotificationHelper(this);signalScheduler=new SignalScheduler();signalStore=new SignalStore(this);createChannel();startForeground(7001,notification("C.P.D SUPER WIZARD AI monitoring active"));}
  @Override public int onStartCommand(Intent intent,int flags,int startId){startWorker();return START_STICKY;}
  private void startWorker(){
    if(running)return;running=true;SecureStore secure=new SecureStore(this);state=new TradeStateStore(this);
    String key=secure.get("exnessAccount","");String base=secure.get("exnessServer","");String bridge=secure.get("bridgeUrl","");String token=secure.get("bridgeToken","");
    if(key.isEmpty()||base.isEmpty()||bridge.isEmpty()){android.util.Log.i("C.P.D SUPER WIZARD AI","Manual mode ready; live bridge not configured.");stopSelf();return;}
    api=new ExnessMt5Client();api.configure(key,base,bridge,token);
    controller=new TradingController(this,new TradingController.Logger(){
      public void log(String s){android.util.Log.i("C.P.D SUPER WIZARD AI",s);}
      public void milestone(String symbol,String milestone,String instruction){notifications.notifyMilestone(symbol,milestone,instruction);}
      public void signal(StrategyEngine.Signal s){
        String k=s.symbol+"|"+s.dir+"|"+String.format(Locale.US,"%.5f",s.entry);long now=System.currentTimeMillis();if(k.equals(lastSignalKey)&&now-lastSignalAt<300000)return;lastSignalKey=k;lastSignalAt=now;
        String id="live_"+now;signalStore.record(id,s.symbol,s.dir>0?"BUY":"SELL",s.confidence,now);
        signalScheduler.schedule(120000,()->notifications.notifyIncoming(s),()->notifications.notifySignal(s));
        android.util.Log.i("C.P.D SUPER WIZARD AI","SIGNAL QUEUED "+s.symbol+" "+s.confidence+"/95");
      }
    },api,state);
    controller.setAggressive("1".equals(secure.get("aggressive","0")));
    exec=Executors.newSingleThreadScheduledExecutor();exec.scheduleAtFixedRate(()->{try{controller.manage();controller.scan(false);}catch(Exception e){android.util.Log.e("C.P.D SUPER WIZARD AI","worker",e);}},2,20,TimeUnit.SECONDS);
  }
  private Notification notification(String text){return new Notification.Builder(this,"cpd_worker").setContentTitle("C.P.D SUPER WIZARD AI").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_manage).setOngoing(true).build();}
  private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);n.createNotificationChannel(new NotificationChannel("cpd_worker","C.P.D Background Monitor",NotificationManager.IMPORTANCE_LOW));}}
  @Override public void onDestroy(){running=false;if(exec!=null)exec.shutdownNow();if(signalScheduler!=null)signalScheduler.cancel();super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
