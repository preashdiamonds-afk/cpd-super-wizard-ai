# C.P.D SUPER WIZARD AI — V2 MULTI-ENGINE MOBILE COMMAND CENTER

## Identity
Launch greeting: **Welcome, Captain Preash Diamond.**

## Mobile sections
- **Home** — account/connection status, pair watchlist, intelligence overview and bot description.
- **Auto** — Normal Auto and a separate Aggressive mode.
- **Manual** — Normal Auto signal mirror with Entry/SL/TP, confidence, reasons and Telegram copy.
- **CPD Scanner** — upload a chart screenshot, select a pair and run M5/M15/H1/H4 confirmation.

## Normal vs Aggressive
Normal Auto is the source for the Manual Signal Center. Aggressive signals are isolated and are never copied into the Normal Manual feed.

## CPD Scanner
A screenshot is accepted as visual context. The scanner then uses available market candles for M5, M15, H1 and H4 confirmation. It returns BUY, SELL or WAIT with Entry, Stop Loss, Take Profit and reasons when a validated setup exists. It does not invent hidden timeframes from a single screenshot.

## Multi-engine intelligence
The decision layer separates evidence into auditable engines:
1. Higher-timeframe trend
2. Market structure / BOS
3. Liquidity sweep
4. Displacement
5. Momentum
6. Pattern confirmation
7. Support/resistance
8. Risk/quality gates

The confidence number is a confluence score, **not a probability of profit**.

## MT5 / Exness execution
The Android app is the command center. Actual automated MT5 order execution requires an MT5-side Expert Advisor/bridge running in an MT5 terminal. The project includes `mt5/CPD_SUPER_WIZARD_AI_BRIDGE.mq5` as the broker-side starter. This is the honest architecture because MQL5 Expert Advisors execute automated trading in the MT5 terminal; the normal Android MT5 client does not run custom EAs.

The bridge itself does not require a paid trading API subscription. A terminal/host is still required for automated MT5 execution. The app can run as a signal/scanner application without that bridge.

## Safety
Use demo testing, backtesting and out-of-sample validation before live trading. No strategy can guarantee profits.
