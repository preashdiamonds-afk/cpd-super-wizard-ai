#property strict
#property version "2.0"
#property description "C.P.D SUPER WIZARD AI MT5 execution bridge"

// This bridge is intentionally small: the Android app remains the command center,
// while MT5 remains the broker-connected execution terminal.  The exact transport
// endpoint is configurable through WebRequest in MT5.  No paid broker API is required.

input string CPD_Command_URL = "";
input int PollSeconds = 2;
input bool AllowNormalAuto = false;
input bool AllowAggressiveAuto = false;

int OnInit(){ EventSetTimer(MathMax(1,PollSeconds)); return(INIT_SUCCEEDED); }
void OnDeinit(const int reason){ EventKillTimer(); }
void OnTimer(){
   // Transport contract placeholder.  The Android project exposes the strategy and
   // dashboard layers; this EA is the broker-side component that must be wired to the
   // chosen authenticated command endpoint before live execution is enabled.
   // Never enable live execution until the endpoint, authentication and payload
   // validation have been tested on a demo account.
}
