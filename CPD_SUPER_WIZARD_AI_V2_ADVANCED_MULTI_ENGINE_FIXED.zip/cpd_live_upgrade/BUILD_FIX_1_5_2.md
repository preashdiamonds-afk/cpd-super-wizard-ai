# Build Fix 1.5.2

Fixed `EnsembleIntelligence.java` compilation failure.

The decision method was writing directly to the `Result.engines` field before a
`Result` object existed. It now collects engine messages in a local `engineLog`,
then copies them into the returned `Result`.

No trading logic or workflow behavior was intentionally changed by this fix.
