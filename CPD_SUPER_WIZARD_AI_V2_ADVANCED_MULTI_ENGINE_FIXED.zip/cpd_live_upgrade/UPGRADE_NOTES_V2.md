# C.P.D SUPER WIZARD AI — V2 Upgrade

## What changed
- Replaced the old cloud/manual-only screen with a mobile-first command-center UI.
- Added dedicated Home, Auto, Manual, and CPD Scanner sections.
- Added Normal Auto and separate Aggressive Auto controls.
- Manual Signal Center is explicitly Normal-only.
- Added Telegram-ready copy of Normal signals.
- Added dedicated currency-pair watchlist.
- Added CPD Scanner multi-timeframe analysis: M5/M15/H1/H4.
- Added a multi-engine decision layer for auditable confluence.
- Added screenshot upload as visual context; price levels are calculated from live candle data rather than invented from pixels.
- Added an MT5 bridge starter under `mt5/`.

## Important execution architecture
An Android app cannot run an MQL5 Expert Advisor inside the Android MT5 client. MetaTrader's automated trading functions are provided by Expert Advisors in the MT5 terminal. Therefore this project does not fake a direct Android-to-Exness trading API. For real automatic execution, an MT5 terminal with the CPD bridge/EA must remain online.

## No paid API claim
The bridge itself does not require a paid trading API subscription. Broker execution still occurs through the connected MT5 terminal. The app can operate as an analysis/signal dashboard without a broker bridge.

## Scanner behavior
When a chart screenshot is uploaded, it is retained as visual context. The scanner then requests M5, M15, H1 and H4 candle data and runs the multi-engine analysis. A screenshot alone cannot reveal candles that are not visible in the image, so the app does not pretend otherwise.

## Testing
Demo-test the strategy and execution bridge before enabling live trading. The confidence score is a confluence score, not a win probability.
