package com.pepestone.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Public market-data client for the manual-execution scanner. No broker login or secret is used.
 * Data is sourced from Yahoo Finance chart endpoints and may differ slightly from Exness quotes.
 */
public class PublicMarketDataClient implements BrokerApiClient {
  private static final String HOST="https://query1.finance.yahoo.com/v8/finance/chart/";
  private String ticker(String symbol){
    if(symbol==null)return "";
    return symbol.toUpperCase(Locale.US).equals("XAUUSD")?"GC=F":symbol.toUpperCase(Locale.US)+"=X";
  }
  private JSONObject get(String symbol,String interval,String range)throws Exception{
    String u=HOST+URLEncoder.encode(ticker(symbol),"UTF-8")+"?interval="+interval+"&range="+range+"&events=history&includePrePost=false";
    HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(9000); c.setReadTimeout(12000); c.setRequestProperty("User-Agent","Mozilla/5.0");
    int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder b=new StringBuilder();
    if(is!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line);}
    if(code<200||code>=300)throw new IOException("Market data HTTP "+code); return new JSONObject(b.toString());
  }
  private JSONArray raw(String symbol,String interval,String range)throws Exception{
    JSONObject x=get(symbol,interval,range).getJSONObject("chart").getJSONArray("result").getJSONObject(0);
    JSONArray ts=x.optJSONArray("timestamp"); JSONObject q=x.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
    JSONArray o=q.optJSONArray("open"),h=q.optJSONArray("high"),l=q.optJSONArray("low"),cl=q.optJSONArray("close"),v=q.optJSONArray("volume"); JSONArray out=new JSONArray();
    if(ts==null)return out; for(int i=0;i<ts.length();i++){if(o==null||h==null||l==null||cl==null||o.isNull(i)||h.isNull(i)||l.isNull(i)||cl.isNull(i))continue; JSONObject c=new JSONObject(); c.put("time",ts.getLong(i));c.put("open",o.getDouble(i));c.put("high",h.getDouble(i));c.put("low",l.getDouble(i));c.put("close",cl.getDouble(i));c.put("tickVolume",v!=null&&!v.isNull(i)?v.getLong(i):0);out.put(c);} return out;
  }
  private JSONArray tail(JSONArray a,int limit){int n=a.length(),start=Math.max(0,n-limit);JSONArray out=new JSONArray();for(int i=start;i<n;i++)out.put(a.opt(i));return out;}
  private JSONArray aggregate4h(JSONArray oneH){JSONArray out=new JSONArray(); JSONObject cur=null; long bucket=0; for(int i=0;i<oneH.length();i++){JSONObject x=oneH.optJSONObject(i);if(x==null)continue;long t=x.optLong("time");long b=(t/(4*3600))*4*3600;if(cur==null||b!=bucket){cur=new JSONObject();bucket=b;try{cur.put("time",b);cur.put("open",x.getDouble("open"));cur.put("high",x.getDouble("high"));cur.put("low",x.getDouble("low"));cur.put("close",x.getDouble("close"));cur.put("tickVolume",x.optLong("tickVolume"));out.put(cur);}catch(Exception ignored){}}else{try{cur.put("high",Math.max(cur.getDouble("high"),x.getDouble("high")));cur.put("low",Math.min(cur.getDouble("low"),x.getDouble("low")));cur.put("close",x.getDouble("close"));cur.put("tickVolume",cur.optLong("tickVolume")+x.optLong("tickVolume"));}catch(Exception ignored){}}}return out;}
  @Override public JSONArray candles(String symbol,String tf,int limit)throws Exception{
    JSONArray a; if("4h".equalsIgnoreCase(tf)) a=aggregate4h(raw(symbol,"1h","1y")); else if("1h".equalsIgnoreCase(tf)) a=raw(symbol,"1h","1y"); else if("15m".equalsIgnoreCase(tf)) a=raw(symbol,"15m","60d"); else a=raw(symbol,"5m","5d"); return tail(a,limit);
  }
  @Override public JSONObject tick(String symbol)throws Exception{
    JSONObject root=get(symbol,"5m","1d").getJSONObject("chart").getJSONArray("result").getJSONObject(0); double px=root.optJSONObject("meta")!=null?root.getJSONObject("meta").optDouble("regularMarketPrice",0):0; if(px<=0){JSONArray c=candles(symbol,"5m",2);px=c.length()>0?c.getJSONObject(c.length()-1).optDouble("close",0):0;} JSONObject x=new JSONObject();x.put("bid",px);x.put("ask",px);x.put("brokerTime",new Date().toString());return x;
  }
  @Override public JSONObject price(String symbol)throws Exception{return tick(symbol);}
  @Override public JSONObject spec(String symbol)throws Exception{JSONObject x=new JSONObject();x.put("point",0.00001);x.put("tickSize",0.00001);x.put("digits",symbol.contains("JPY")?3:5);return x;}
  @Override public JSONObject accountInfo(){return new JSONObject();}
  @Override public JSONArray positions(){return new JSONArray();}
  @Override public JSONObject trade(JSONObject trade)throws Exception{throw new IOException("Automatic order execution is disabled in C.P.D Manual Mode.");}
}
