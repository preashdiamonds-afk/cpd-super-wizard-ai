package com.pepestone.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

/** Local signal journal for weekly performance tracking. */
public class SignalStore {
  private final SharedPreferences p;
  public SignalStore(Context c){p=c.getSharedPreferences("cpd_signal_store",Context.MODE_PRIVATE);}
  public void record(String id,String symbol,String side,double confidence,long time){
    p.edit().putString(id, symbol+"|"+side+"|"+confidence+"|"+time+"|OPEN").apply();
  }
  public void outcome(String id,String result){
    String v=p.getString(id,""); if(v.isEmpty())return;
    String[] a=v.split("\\|",-1); if(a.length<5)return; a[4]=result;
    p.edit().putString(id,String.join("|",a)).apply();
  }
  public int[] weekStats(){
    long now=System.currentTimeMillis(),week=7L*24*60*60*1000; int signals=0,wins=0,losses=0;
    for(String k:p.getAll().keySet()){
      String v=p.getString(k,""); if(v==null)continue;String[] a=v.split("\\|",-1);if(a.length<5)continue;
      try{long t=Long.parseLong(a[3]);if(now-t<=week&&now>=t){signals++;if("TP1".equals(a[4])||"TP2".equals(a[4])||"TP3".equals(a[4])||"TP4".equals(a[4]))wins++;if("SL".equals(a[4]))losses++;}}catch(Exception ignored){}
    }
    return new int[]{signals,wins,losses};
  }
  public double winRate(){int[] s=weekStats();return s[0]==0?0:s[1]*100.0/s[0];}
}
