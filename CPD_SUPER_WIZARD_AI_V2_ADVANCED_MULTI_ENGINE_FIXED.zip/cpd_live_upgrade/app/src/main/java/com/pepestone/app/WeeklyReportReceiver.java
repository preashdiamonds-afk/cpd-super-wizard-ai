package com.pepestone.app;

import android.content.*;

public class WeeklyReportReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i){
    SignalStore store=new SignalStore(c);int[] s=store.weekStats();new NotificationHelper(c).notifyWeekly(s[0],s[1],s[2],store.winRate());WeeklyReportScheduler.schedule(c);
  }
}
