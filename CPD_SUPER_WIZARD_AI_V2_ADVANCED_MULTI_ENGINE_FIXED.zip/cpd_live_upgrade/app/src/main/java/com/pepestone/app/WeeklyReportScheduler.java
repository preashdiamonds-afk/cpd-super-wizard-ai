package com.pepestone.app;

import android.app.*;import android.content.*;import android.os.Build;import java.util.*;

/** Schedules a lightweight local Sunday evening weekly signal report. */
public class WeeklyReportScheduler {
  private static final int REQUEST=7315;
  public static void schedule(Context c){
    Calendar n=Calendar.getInstance(), next=Calendar.getInstance();
    next.set(Calendar.DAY_OF_WEEK,Calendar.SUNDAY);next.set(Calendar.HOUR_OF_DAY,20);next.set(Calendar.MINUTE,0);next.set(Calendar.SECOND,0);next.set(Calendar.MILLISECOND,0);
    if(!next.after(n))next.add(Calendar.DAY_OF_YEAR,7);
    Intent i=new Intent(c,WeeklyReportReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,REQUEST,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),pi);
  }
}
