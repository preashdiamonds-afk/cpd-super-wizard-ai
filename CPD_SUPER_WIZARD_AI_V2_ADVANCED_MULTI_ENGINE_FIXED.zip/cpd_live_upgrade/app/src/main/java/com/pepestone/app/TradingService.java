package com.pepestone.app;

import android.app.*;import android.content.*;import android.os.IBinder;import java.util.*;import org.json.*;

/** Cloud-status service. It keeps signal history visible when the phone reconnects; it never places orders. */
public class TradingService extends Service {
  private java.util.concurrent.ScheduledExecutorService exec; private ScannerStateStore state; private NotificationHelper notifications; private volatile boolean running; private String lastPublished=""; private String lastIncoming="";
  @Override public void onCreate(){super.onCreate();state=new ScannerStateStore(this);notifications=new NotificationHelper(this);createChannel();state.status("C.P.D CLOUD SCANNER • connecting…");startForeground(7001,notification("C.P.D cloud scanner • manual execution only"));}
  @Override public int onStartCommand(Intent intent,int flags,int startId){startWorker();return START_STICKY;}
  private void startWorker(){if(running)return;running=true;exec=java.util.concurrent.Executors.newSingleThreadScheduledExecutor();exec.scheduleAtFixedRate(this::poll,1,60,java.util.concurrent.TimeUnit.SECONDS);}
  private void poll(){new CloudSignalClient().fetch(new CloudSignalClient.Callback(){
    public void ok(JSONObject j){
      StrategyEngine.Signal s=CloudSignalClient.signal(j); String status=CloudSignalClient.activeStatus(j); state.status(j.optString("status", "C.P.D CLOUD SCANNER • ONLINE"));
      if(s!=null){
        String key=s.symbol+"|"+s.dir+"|"+String.format(Locale.US,"%.5f",s.entry);
        state.pendingIfNeeded(s,key,status);
        if("INCOMING".equals(status)){
          if(!key.equals(lastIncoming)){lastIncoming=key;notifications.notifyIncoming(s);}
          try{long p=java.time.Instant.parse(j.getJSONObject("active").optString("publish_at")).toEpochMilli(); if(System.currentTimeMillis()>=p){state.published(s); if(!key.equals(lastPublished)){lastPublished=key;notifications.notifySignal(s);}}}catch(Exception ignored){}
        } else if("PUBLISHED".equals(status)&&!key.equals(lastPublished)){lastPublished=key;notifications.notifySignal(s);}
      }
    }
    public void error(String e){state.status("C.P.D CLOUD SCANNER • OFFLINE / waiting for internet");}
  });}
  private Notification notification(String text){return new Notification.Builder(this,"cpd_worker").setContentTitle("C.P.D SUPER WIZARD AI").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_search).setOngoing(true).build();}
  private void createChannel(){if(android.os.Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);n.createNotificationChannel(new NotificationChannel("cpd_worker","C.P.D Cloud Scanner",NotificationManager.IMPORTANCE_LOW));}}
  @Override public void onDestroy(){running=false;if(exec!=null)exec.shutdownNow();super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
