package com.pepestone.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Public TradingView screener endpoint used for cross-checking live FX quotes. */
public class TradingViewClient {
  private String tvTicker(String s){return "OANDA:"+s.toUpperCase(Locale.US);}
  public JSONObject quote(String symbol) throws Exception {
    String u="https://scanner.tradingview.com/forex/scan";
    JSONObject payload=new JSONObject();
    JSONArray tickers=new JSONArray(); tickers.put(tvTicker(symbol));
    JSONObject syms=new JSONObject(); JSONObject query=new JSONObject(); query.put("types",new JSONArray().put("forex")); syms.put("tickers",tickers); syms.put("query",query);
    payload.put("symbols",syms); payload.put("columns",new JSONArray().put("name").put("close").put("change").put("open").put("high").put("low").put("bid").put("ask")); payload.put("range",new JSONArray().put(0).put(1)); payload.put("options",new JSONObject().put("lang","en"));
    HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("User-Agent","Mozilla/5.0");
    try(OutputStream os=c.getOutputStream()){os.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
    int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder b=new StringBuilder();
    if(is!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line);}
    if(code<200||code>=300)throw new IOException("TradingView HTTP "+code);
    JSONObject root=new JSONObject(b.toString()); JSONArray data=root.optJSONArray("data"); if(data==null||data.length()==0)throw new IOException("TradingView returned no quote");
    JSONArray d=data.getJSONObject(0).getJSONArray("d"); JSONObject out=new JSONObject(); out.put("name",d.optString(0)); out.put("close",d.optDouble(1)); out.put("change",d.optDouble(2)); out.put("open",d.optDouble(3)); out.put("high",d.optDouble(4)); out.put("low",d.optDouble(5)); out.put("bid",d.optDouble(6)); out.put("ask",d.optDouble(7)); return out;
  }
}
