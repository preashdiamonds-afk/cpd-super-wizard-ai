package com.pepestone.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Cross-market context. Uses public endpoints/pages; no broker credentials. */
public class MarketContextClient {
  public static class Context {
    public double vix=0;
    public boolean vixAvailable=false;
    public boolean investingHighImpact=false;
    public boolean forexFactoryHighImpact=false;
    public boolean investingAvailable=false;
    public boolean forexFactoryAvailable=false;
    public boolean marketWatchAvailable=false;
    public String note="";
  }

  private String getText(String url) throws Exception {
    HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
    c.setRequestMethod("GET"); c.setConnectTimeout(8000); c.setReadTimeout(10000);
    c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) C.P.D SUPER WIZARD AI");
    int code=c.getResponseCode(); InputStream is=code>=200&&code<400?c.getInputStream():c.getErrorStream();
    StringBuilder b=new StringBuilder();
    if(is!=null) try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line).append('\n');}
    if(code<200||code>=400) throw new IOException("HTTP "+code);
    return b.toString();
  }

  private double yahooVix() throws Exception {
    String u="https://query1.finance.yahoo.com/v8/finance/chart/%5EVIX?interval=5m&range=1d";
    String t=getText(u); JSONObject root=new JSONObject(t).getJSONObject("chart").getJSONArray("result").getJSONObject(0);
    JSONObject meta=root.optJSONObject("meta"); double p=meta==null?0:meta.optDouble("regularMarketPrice",0);
    if(p<=0){JSONArray q=root.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).optJSONArray("close"); if(q!=null)for(int i=q.length()-1;i>=0;i--)if(!q.isNull(i)){p=q.optDouble(i,0);break;}}
    return p;
  }

  private boolean highImpact(String html){
    if(html==null)return false;
    String s=html.toLowerCase(Locale.US);
    return s.contains("high impact") || s.contains("high volatility expected") || s.contains("interest rate") || s.contains("nonfarm") || s.contains("cpi");
  }

  public Context load(String symbol){
    Context c=new Context(); StringBuilder n=new StringBuilder();
    try{c.vix=yahooVix();c.vixAvailable=c.vix>0;n.append("VIX=").append(String.format(Locale.US,"%.2f",c.vix));}catch(Exception e){n.append("VIX unavailable");}
    try{String x=getText("https://www.investing.com/economic-calendar");c.investingHighImpact=highImpact(x);c.investingAvailable=true;}catch(Exception ignored){}
    try{String x=getText("https://www.forexfactory.com/calendar");c.forexFactoryHighImpact=highImpact(x);c.forexFactoryAvailable=true;}catch(Exception ignored){}
    try{getText("https://www.marketwatch.com/investing/index/vix");c.marketWatchAvailable=true;}catch(Exception ignored){}
    c.note=n.toString(); return c;
  }
}
