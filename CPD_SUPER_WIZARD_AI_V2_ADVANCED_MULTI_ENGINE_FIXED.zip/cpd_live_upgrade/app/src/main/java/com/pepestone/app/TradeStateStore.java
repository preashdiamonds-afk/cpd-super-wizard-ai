package com.pepestone.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Small persistent state store used by the optional future bridge worker. */
public class TradeStateStore {
  private final SharedPreferences p;
  public TradeStateStore(Context c){p=c.getSharedPreferences("cpd_trade_state",Context.MODE_PRIVATE);}
  public long getLong(String k,long d){return p.getLong(k,d);} public void setLong(String k,long v){p.edit().putLong(k,v).apply();}
  public int getInt(String k,int d){return p.getInt(k,d);} public void setInt(String k,int v){p.edit().putInt(k,v).apply();}
  public double getDouble(String k,double d){return p.getFloat(k,(float)d);} public void setDouble(String k,double v){p.edit().putFloat(k,(float)v).apply();}
  public boolean getBool(String k,boolean d){return p.getBoolean(k,d);} public void setBool(String k,boolean v){p.edit().putBoolean(k,v).apply();}
  public void clearPosition(String id){p.edit().remove("r:"+id).remove("p:"+id+":1").remove("p:"+id+":2").remove("p:"+id+":3").remove("p:"+id+":4").remove("s:"+id+":1").remove("s:"+id+":2").remove("s:"+id+":3").remove("s:"+id+":4").apply();}
}
