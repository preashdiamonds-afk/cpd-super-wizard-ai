package com.pepestone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

/** C.P.D SUPER WIZARD AI — upgraded mobile command center. */
public class MainActivity extends Activity {
  private final String[] PAIRS={"EURUSD","GBPUSD","USDJPY","GBPJPY","AUDUSD","USDCAD","USDCHF","AUDJPY","AUDCAD","AUDCHF","XAUUSD"};
  private LinearLayout root,content; private TextView title,status,signal,scannerResult,visualInfo,accountInfo,engineInfo;
  private Spinner pairSpinner; private Button normalBtn,aggressiveBtn,copyBtn,scanBtn,uploadBtn;
  private Bitmap uploadedChart; private StrategyEngine.Signal lastNormalSignal; private ScheduledExecutorService worker;
  private final PublicMarketDataClient market=new PublicMarketDataClient();
  private boolean normalOn=false, aggressiveOn=false;
  private final ExecutorService io=Executors.newSingleThreadExecutor();

  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(android.graphics.Color.rgb(6,8,12));getWindow().setNavigationBarColor(android.graphics.Color.rgb(6,8,12));
    build(); welcome(); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001); }

  private int gold(){return android.graphics.Color.rgb(244,194,76);} private int bg(){return android.graphics.Color.rgb(6,8,12);} private int card(){return android.graphics.Color.rgb(17,21,29);} private int white(){return android.graphics.Color.rgb(242,246,252);} private int muted(){return android.graphics.Color.rgb(154,164,178);} private int green(){return android.graphics.Color.rgb(71,211,133);} private int red(){return android.graphics.Color.rgb(255,102,112);}
  private TextView tv(String text,float size,int color){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,2,0,2);return v;}
  private GradientDrawable gd(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);g.setStroke(1,android.graphics.Color.rgb(47,54,65));return g;}
  private LinearLayout cardLayout(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,16,18,16);c.setBackground(gd(card(),22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,10,0,0);c.setLayoutParams(p);return c;}
  private Button btn(String text){Button b=new Button(this);b.setText(text);b.setTextColor(bg());b.setTextSize(12);b.setAllCaps(false);b.setTypeface(null,1);b.setBackground(gd(gold(),18));b.setPadding(10,0,10,0);return b;}

  private void build(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg());setContentView(root);
    LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.VERTICAL);top.setPadding(20,18,20,12);top.setBackgroundColor(android.graphics.Color.rgb(10,13,19));
    title=tv("✦ C.P.D SUPER WIZARD AI ✦",22,gold());title.setTypeface(null,1);top.addView(title);status=tv("READY • MULTI-ENGINE COMMAND CENTER",12,green());status.setPadding(0,5,0,0);top.addView(status);root.addView(top,new LinearLayout.LayoutParams(-1,-2));
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(14,4,14,90);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=new LinearLayout(this);nav.setPadding(8,8,8,8);nav.setBackgroundColor(android.graphics.Color.rgb(12,15,21));String[] tabs={"HOME","AUTO","MANUAL","CPD SCANNER"};for(String t:tabs){Button b=btn(t);b.setTextColor(white());b.setBackground(gd(android.graphics.Color.rgb(24,29,38),20));b.setOnClickListener(v->showTab(t));nav.addView(b,new LinearLayout.LayoutParams(0,52,1));}root.addView(nav,new LinearLayout.LayoutParams(-1,68));showTab("HOME");
  }

  private void welcome(){new Handler().postDelayed(()->{Toast.makeText(this,"Welcome, Captain Preash Diamond",Toast.LENGTH_LONG).show();},350);}
  private void showTab(String tab){content.removeAllViews(); if("AUTO".equals(tab))autoTab();else if("MANUAL".equals(tab))manualTab();else if("CPD SCANNER".equals(tab))scannerTab();else homeTab();}

  private void homeTab(){
    LinearLayout c=cardLayout();c.addView(tv("WELCOME, CAPTAIN PREASH DIAMOND",20,gold()));c.addView(tv("Your C.P.D intelligence command center is ready.",13,muted()));content.addView(c);
    LinearLayout a=cardLayout();a.addView(tv("LIVE ACCOUNT",15,gold()));accountInfo=tv("MT5 CONNECTION: READY FOR BRIDGE\nBalance —\nEquity —\nOpen positions —",14,white());accountInfo.setPadding(0,10,0,0);a.addView(accountInfo);Button setup=btn("BROKER / MT5 CONNECTION");setup.setOnClickListener(v->Toast.makeText(this,"MT5 automation uses an MT5-side Expert Advisor bridge. No paid trading API is required for the bridge itself.",Toast.LENGTH_LONG).show());a.addView(setup,new LinearLayout.LayoutParams(-1,48));content.addView(a);
    LinearLayout p=cardLayout();p.addView(tv("C.P.D ANALYSIS PAIRS",15,gold()));p.addView(tv("Dedicated watchlist • Normal and Scanner engines use these pairs.",12,muted()));for(String x:PAIRS){TextView t=tv("• "+x,13,white());p.addView(t);}content.addView(p);
    LinearLayout e=cardLayout();e.addView(tv("MULTI-ENGINE INTELLIGENCE",15,gold()));engineInfo=tv("Market Structure • Pattern • Support/Resistance • Liquidity • Momentum • Multi-Timeframe • Risk",13,white());engineInfo.setPadding(0,9,0,0);e.addView(engineInfo);content.addView(e);
    LinearLayout about=cardLayout();about.addView(tv("ABOUT C.P.D SUPER WIZARD AI",15,gold()));about.addView(tv("A mobile trading command system combining Normal Auto analysis, a separate Aggressive engine, a Normal-only Manual Signal Center, Telegram-ready signal copying, dedicated pair intelligence, and CPD Scanner multi-timeframe chart analysis. Signals are evidence-based confluence, not guaranteed profit.",13,white()));content.addView(about);
  }

  private void autoTab(){
    LinearLayout c=cardLayout();c.addView(tv("AUTO TRADING",19,gold()));c.addView(tv("Normal and Aggressive are deliberately separated.",12,muted()));
    pairSpinner=new Spinner(this);pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS));c.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));
    normalBtn=btn("NORMAL AUTO • OFF");normalBtn.setOnClickListener(v->{normalOn=!normalOn;normalBtn.setText(normalOn?"NORMAL AUTO • ON":"NORMAL AUTO • OFF");status.setText(normalOn?"NORMAL AUTO • SCANNING":"READY • NORMAL AUTO OFF");if(normalOn)scanNormal();});c.addView(normalBtn,new LinearLayout.LayoutParams(-1,52));
    aggressiveBtn=btn("AGGRESSIVE AUTO • OFF");aggressiveBtn.setOnClickListener(v->{aggressiveOn=!aggressiveOn;aggressiveBtn.setText(aggressiveOn?"AGGRESSIVE AUTO • ON":"AGGRESSIVE AUTO • OFF");Toast.makeText(this,"Aggressive signals never enter the Normal Manual Signal Center.",Toast.LENGTH_SHORT).show();});LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,52);ap.setMargins(0,8,0,0);c.addView(aggressiveBtn,ap);content.addView(c);
    LinearLayout q=cardLayout();q.addView(tv("NORMAL AUTO ENGINE",15,gold()));q.addView(tv("M5 + M15 + H1 + H4 confirmation • true/false pattern • strong/weak S/R • breakout/fakeout • risk gate • WAIT when evidence conflicts.",13,white()));content.addView(q);
    LinearLayout warning=cardLayout();warning.addView(tv("EXECUTION ARCHITECTURE",15,gold()));warning.addView(tv("The mobile app is the command center. Real MT5 order execution is performed by an MT5-side EA/bridge, because MetaTrader's automated trading functions run in the desktop MT5 terminal. This project does not pretend a normal Android MT5 login is a broker trading API.",12,muted()));content.addView(warning);
  }

  private void manualTab(){
    LinearLayout c=cardLayout();c.addView(tv("MANUAL • NORMAL SIGNAL CENTER",19,gold()));c.addView(tv("Only NORMAL AUTO signals appear here. Aggressive mode is isolated.",12,muted()));signal=tv(lastNormalSignal==null?"No Normal Auto signal yet.":format(lastNormalSignal),14,white());signal.setPadding(0,12,0,12);c.addView(signal);copyBtn=btn("📋 COPY NORMAL SIGNAL FOR TELEGRAM");copyBtn.setOnClickListener(v->copySignal());c.addView(copyBtn,new LinearLayout.LayoutParams(-1,52));content.addView(c);
    LinearLayout live=cardLayout();live.addView(tv("LIVE POSITION MIRROR",15,gold()));live.addView(tv("When the same MT5 account has a Normal Auto position, the Manual dashboard is designed to show the real pair, direction, entry, SL, TP, status and trade reason. It must mirror the actual account state—not create a second trade.",13,white()));content.addView(live);
  }

  private void scannerTab(){
    LinearLayout c=cardLayout();c.addView(tv("CPD SCANNER",21,gold()));c.addView(tv("Upload a chart, choose its pair, then run a multi-timeframe confirmation scan.",12,muted()));
    pairSpinner=new Spinner(this);pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS));c.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));
    LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);uploadBtn=btn("UPLOAD CHART");scanBtn=btn("SCAN NOW");row.addView(uploadBtn,new LinearLayout.LayoutParams(0,52,1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,52,1);sp.setMargins(8,0,0,0);row.addView(scanBtn,sp);c.addView(row);
    visualInfo=tv("No screenshot attached.",12,muted());visualInfo.setPadding(0,10,0,0);c.addView(visualInfo);content.addView(c);
    LinearLayout r=cardLayout();r.addView(tv("SCAN RESULT",16,gold()));scannerResult=tv("Select a pair and run CPD Scanner.",14,white());scannerResult.setPadding(0,10,0,0);r.addView(scannerResult);content.addView(r);
    uploadBtn.setOnClickListener(v->pickImage());scanBtn.setOnClickListener(v->runScanner());
  }

  private void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,9001);}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=9001||result!=RESULT_OK||data==null||data.getData()==null)return;try{Uri u=data.getData();uploadedChart=MediaStore.Images.Media.getBitmap(getContentResolver(),u);visualInfo.setText(ChartVisualContext.describe(uploadedChart));}catch(Exception e){visualInfo.setText("Could not read chart screenshot: "+e.getMessage());}}
  private String selected(){return pairSpinner==null?"EURUSD":String.valueOf(pairSpinner.getSelectedItem());}
  private void runScanner(){final String sym=selected();scannerResult.setText("CPD Scanner is checking M5 • M15 • H1 • H4 for "+sym+"…");io.execute(()->{CPDScannerEngine.ScanResult r=CPDScannerEngine.scan(sym,market,uploadedChart!=null);runOnUiThread(()->scannerResult.setText(scannerText(r)));});}
  private String scannerText(CPDScannerEngine.ScanResult r){return "PAIR: "+r.symbol+"\n\nM5   → "+r.timeframes[3]+"\nM15  → "+r.timeframes[2]+"\nH1   → "+r.timeframes[1]+"\nH4   → "+r.timeframes[0]+"\n\nDIRECTION: "+r.direction+"\nENTRY: "+r.entry+"\nSTOP LOSS: "+r.sl+"\nTAKE PROFIT: "+r.tp+"\nCONFIDENCE: "+String.format(Locale.US,"%.0f%%",r.confidence)+"\n\nREASON\n"+r.reason;}

  private void scanNormal(){final String sym=selected();io.execute(()->{try{List<StrategyEngine.Candle> h4=list(market.candles(sym,"4h",250)),h1=list(market.candles(sym,"1h",250)),m15=list(market.candles(sym,"15m",160)),m5=list(market.candles(sym,"5m",160));org.json.JSONObject p=market.price(sym);StrategyEngine.Signal s=new StrategyEngine().evaluate(sym,h4,h1,m15,m5,p.optDouble("bid"),p.optDouble("ask"),false);if(s.valid){lastNormalSignal=s;runOnUiThread(()->{status.setText("NORMAL AUTO • SIGNAL READY • "+sym);Toast.makeText(this,"Normal signal generated. Open MANUAL to copy it.",Toast.LENGTH_LONG).show();});}else runOnUiThread(()->status.setText("NORMAL AUTO • WAIT • NO QUALIFIED "+sym+" SETUP"));}catch(Exception e){runOnUiThread(()->status.setText("NORMAL AUTO • DATA ERROR"));}});}
  private List<StrategyEngine.Candle> list(org.json.JSONArray a){List<StrategyEngine.Candle> r=new ArrayList<>();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null)r.add(new StrategyEngine.Candle(a.optJSONObject(i)));return r;}
  private String format(StrategyEngine.Signal s){return "C.P.D SUPER WIZARD AI\nNORMAL AUTO SIGNAL\n\n"+s.symbol+" • "+(s.dir>0?"BUY":"SELL")+"\n\nENTRY  "+fmt(s.entry)+"\nSTOP LOSS  "+fmt(s.sl)+"\nTP1  "+fmt(s.tp1)+"\nTP2  "+fmt(s.tp2)+"\nTP3  "+fmt(s.tp3)+"\nFINAL TP  "+fmt(s.tp)+"\n\nCONFIDENCE  "+String.format(Locale.US,"%.0f/95",s.confidence)+"\nPATTERN: "+s.pattern+" ["+s.patternQuality+"]\nS/R: "+s.sr+" ["+s.srQuality+"]\nBREAKOUT: "+s.breakout+"\n\nREASON\n"+s.reason;}
  private String fmt(double x){return String.format(Locale.US,"%.5f",x);}
  private void copySignal(){if(lastNormalSignal==null){Toast.makeText(this,"No Normal Auto signal to copy.",Toast.LENGTH_SHORT).show();return;}((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("CPD Normal Signal",format(lastNormalSignal)));Toast.makeText(this,"Normal signal copied for Telegram.",Toast.LENGTH_SHORT).show();}
  @Override protected void onDestroy(){io.shutdownNow();if(worker!=null)worker.shutdownNow();super.onDestroy();}
}
