package com.pepestone.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Placeholder for future broker settings; no credentials are required by manual mode. */
public class SecureStore {
  private final SharedPreferences p;
  public SecureStore(Context c){p=c.getSharedPreferences("cpd_settings",Context.MODE_PRIVATE);}
  public String get(String k,String d){return p.getString(k,d);}
  public void put(String k,String v){p.edit().putString(k,v).apply();}
}
