package com.pepestone.app;

import java.util.*;

/**
 * Multi-engine decision layer. These are deterministic analysis engines, not claims of
 * magical AI accuracy. Each engine contributes evidence that can be audited.
 */
public final class EnsembleIntelligence {
  public static class Result {
    public int direction;
    public double agreement;
    public String summary;
    public final List<String> engines = new ArrayList<>();
    Result(int d,double a,String s){direction=d;agreement=a;summary=s;}
  }

  public static Result assess(List<StrategyEngine.Candle> h4,List<StrategyEngine.Candle> h1,
                              List<StrategyEngine.Candle> m15,List<StrategyEngine.Candle> m5,
                              StrategyEngine.Signal base){
    if(base==null || !base.valid) return new Result(0,0,"No validated setup.");
    int d=base.dir, votes=0, total=7;
    List<String> engineLog = new ArrayList<>();
    double a15=StrategyEngine.atr(m15,14), a4=StrategyEngine.atr(h4,14);
    if(h4.size()>205 && h1.size()>205){
      double h4e=StrategyEngine.ema(h4,50), h4s=StrategyEngine.ema(h4,200);
      double h1e=StrategyEngine.ema(h1,50), h1s=StrategyEngine.ema(h1,200);
      int v=(h4.get(h4.size()-2).c>h4e&&h4e>h4s&&h1.get(h1.size()-2).c>h1e&&h1e>h1s)?1:
        (h4.get(h4.size()-2).c<h4e&&h4e<h4s&&h1.get(h1.size()-2).c<h1e&&h1e<h1s?-1:0);
      if(v==d){votes++;engineLog.add("HTF TREND ✓");}else engineLog.add("HTF TREND ✕");
    }
    int st=StrategyEngine.structure(m15,d,a15);
    if(st>=2){votes++;engineLog.add("MARKET STRUCTURE ✓");}else engineLog.add("MARKET STRUCTURE ✕");
    boolean liq=d>0?StrategyEngine.bullSweep(m15,a15):StrategyEngine.bearSweep(m15,a15);
    if(liq){votes++;engineLog.add("LIQUIDITY SWEEP ✓");}else engineLog.add("LIQUIDITY SWEEP ✕");
    if(StrategyEngine.disp(m15,d,a15)){votes++;engineLog.add("DISPLACEMENT ✓");}else engineLog.add("DISPLACEMENT ✕");
    if(StrategyEngine.momentum(m15,d)){votes++;engineLog.add("MOMENTUM ✓");}else engineLog.add("MOMENTUM ✕");
    if(base.pattern!=null && !"NONE".equals(base.pattern) && base.patternQuality!=null && base.patternQuality.contains("TRUE")){votes++;engineLog.add("PATTERN ✓");}else engineLog.add("PATTERN —");
    if(base.sr!=null && base.sr.contains("STRONG")){votes++;engineLog.add("S/R ✓");}else engineLog.add("S/R —");
    double agreement=100.0*votes/total;
    Result result = new Result(d,agreement,""+votes+"/"+total+" independent confirmation engines agree with the validated direction.");
    result.engines.addAll(engineLog);
    return result;
  }
}
