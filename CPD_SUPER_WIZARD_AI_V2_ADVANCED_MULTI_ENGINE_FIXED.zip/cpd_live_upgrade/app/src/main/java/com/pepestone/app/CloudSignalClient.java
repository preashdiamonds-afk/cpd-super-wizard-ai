package com.pepestone.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Read-only cloud signal state. It never sends broker credentials or places trades. */
public class CloudSignalClient {
  public static final String URL="https://raw.githubusercontent.com/preashdiamonds-afk/cpd-super-wizard-ai/main/cloud/signals.json";
  public interface Callback { void ok(JSONObject data); void error(String message); }
  public void fetch(Callback cb){
    new Thread(()->{
      HttpURLConnection c=null;
      try{
        c=(HttpURLConnection)new URL(URL+"?t="+System.currentTimeMillis()).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(8000); c.setReadTimeout(10000);
        c.setRequestProperty("Cache-Control","no-cache"); c.setRequestProperty("User-Agent","CPD-SUPER-WIZARD-AI");
        int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        StringBuilder b=new StringBuilder(); if(is!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line);}
        if(code<200||code>=300)throw new IOException("Cloud HTTP "+code);
        JSONObject j=new JSONObject(b.toString()); cb.ok(j);
      }catch(Exception e){cb.error(e.getMessage()==null?"Cloud unavailable":e.getMessage());}
      finally{if(c!=null)c.disconnect();}
    }).start();
  }
  public static StrategyEngine.Signal signal(JSONObject j){
    try{
      if(j==null||j.isNull("active"))return null; JSONObject a=j.getJSONObject("active");
      StrategyEngine.Signal s=new StrategyEngine.Signal(a.optString("symbol")); s.valid=true;
      s.tp1=a.optDouble("tp1"); s.tp2=a.optDouble("tp2"); s.tp3=a.optDouble("tp3"); s.tp4=a.optDouble("tp4");
      s.pattern=a.optString("pattern","NONE"); s.patternQuality=a.optString("pattern_quality",a.optString("patternQuality","NONE")); s.sr=a.optString("sr","NONE"); s.srQuality=a.optString("sr_quality",a.optString("srQuality","NONE")); s.breakout=a.optString("breakout","NONE");
      s.dir="BUY".equalsIgnoreCase(a.optString("direction"))?1:-1; s.entry=a.optDouble("entry"); s.sl=a.optDouble("sl"); s.tp=a.optDouble("final");
      s.confidence=a.optDouble("confidence"); s.reason=a.optString("reason"); return s;
    }catch(Exception e){return null;}
  }
  public static String activeStatus(JSONObject j){try{JSONObject a=j.optJSONObject("active");return a==null?"NO ACTIVE SIGNAL":a.optString("status","PUBLISHED");}catch(Exception e){return "NO ACTIVE SIGNAL";}}
}
