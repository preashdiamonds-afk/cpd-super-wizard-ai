package com.pepestone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.Locale;

/** Beautiful phone notifications for C.P.D signal stages and milestones. */
public class NotificationHelper {
  public static final String CHANNEL_ID="cpd_signals";
  private final Context ctx;
  public NotificationHelper(Context c){ctx=c.getApplicationContext();createChannel();}
  private void createChannel(){
    if(Build.VERSION.SDK_INT>=26){
      NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
      NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"C.P.D Signal Center",NotificationManager.IMPORTANCE_HIGH);
      ch.setDescription("C.P.D SUPER WIZARD AI signal incoming, published and TP/SL notifications");
      nm.createNotificationChannel(ch);
    }
  }
  private void post(String title,String body){
    if(Build.VERSION.SDK_INT>=33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
    Intent i=new Intent(ctx,MainActivity.class);i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi=PendingIntent.getActivity(ctx,(int)(System.currentTimeMillis()%100000),i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
    Notification n=new Notification.Builder(ctx,CHANNEL_ID).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setPriority(Notification.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build();
    ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),n);
  }
  public void show(String title,String body){post(title,body);}
  public void notifyIncoming(StrategyEngine.Signal s){
    String side=s.dir>0?"BUY":"SELL";
    post("✦ C.P.D SIGNAL INCOMING ✦",side+" setup detected on "+s.symbol+". Confirmation is pending. Signal will be published in 2 minutes.");
  }
  public void notifySignal(StrategyEngine.Signal s){
    String side=s.dir>0?"BUY":"SELL";
    String body=String.format(Locale.US,"%s %s • Confidence %.0f/95\nEntry %.5f • SL %.5f • TP1 %.5f (0.80R) • TP2 %.5f (1.60R)",s.symbol,side,s.confidence,s.entry,s.sl,s.dir>0?s.entry+0.8*Math.abs(s.entry-s.sl):s.entry-0.8*Math.abs(s.entry-s.sl),s.dir>0?s.entry+1.6*Math.abs(s.entry-s.sl):s.entry-1.6*Math.abs(s.entry-s.sl));
    post("C.P.D SUPER WIZARD AI — SIGNAL PUBLISHED",body+"\n"+s.reason);
  }
  public void notifyMilestone(String symbol,String milestone,String instruction){post("C.P.D TRADE UPDATE • "+milestone,symbol+" reached "+milestone+". "+instruction);}
  public void notifyWeekly(int signals,int wins,int losses,double rate){post("C.P.D WEEKLY SIGNAL REPORT",String.format(Locale.US,"Signals %d • Wins %d • Losses %d • Win rate %.1f%%",signals,wins,losses,rate));}
}
