package com.pepestone.app;

import org.json.*;

/** Common broker API contract used by the strategy engine. */
public interface BrokerApiClient {
  JSONObject accountInfo() throws Exception;
  JSONArray positions() throws Exception;
  JSONArray candles(String symbol,String tf,int limit) throws Exception;
  JSONObject tick(String symbol) throws Exception;
  JSONObject price(String symbol) throws Exception;
  JSONObject spec(String symbol) throws Exception;
  JSONObject trade(JSONObject trade) throws Exception;
}
