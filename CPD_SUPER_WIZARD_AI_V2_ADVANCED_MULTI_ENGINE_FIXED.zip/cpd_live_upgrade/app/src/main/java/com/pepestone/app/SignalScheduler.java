package com.pepestone.app;

import android.os.Handler;
import android.os.Looper;

/** Two-stage signal flow: incoming warning first, published signal two minutes later. */
public class SignalScheduler {
  private final Handler h=new Handler(Looper.getMainLooper());
  private Runnable pending;
  public void cancel(){if(pending!=null)h.removeCallbacks(pending);pending=null;}
  public void schedule(long delayMs,Runnable incoming,Runnable publish){
    cancel();
    if(incoming!=null)incoming.run();
    pending=()->{pending=null;if(publish!=null)publish.run();};
    h.postDelayed(pending,Math.max(1000,delayMs));
  }
}
