package com.pepestone.app;

import android.graphics.Bitmap;

/** Lightweight visual-input validator. It deliberately does not invent price levels from pixels. */
public final class ChartVisualContext {
  public static String describe(Bitmap b){
    if(b==null) return "No screenshot attached.";
    int w=b.getWidth(),h=b.getHeight();
    if(w<200||h<120) return "Screenshot received, but the image is too small for reliable chart context.";
    long sum=0; int step=Math.max(1,Math.min(w,h)/40),n=0;
    for(int y=0;y<h;y+=step)for(int x=0;x<w;x+=step){int p=b.getPixel(x,y);sum+=(p>>16)&255;sum+=(p>>8)&255;sum+=p&255;n+=3;}
    int avg=n==0?0:(int)(sum/n);
    return "Chart screenshot received • "+w+"×"+h+" • visual context validated (avg luminance "+avg+"). Live M5/M15/H1/H4 data is used for the trading decision when available.";
  }
}
