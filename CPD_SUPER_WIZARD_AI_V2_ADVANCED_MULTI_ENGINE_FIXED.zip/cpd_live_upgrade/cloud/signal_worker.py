import json, math, os
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen

API_KEY = os.environ.get('TWELVE_DATA_API_KEY','').strip()
SYMBOLS = ['EUR/USD','GBP/USD','USD/JPY','XAU/USD']
OUT = os.path.join(os.path.dirname(__file__), 'signals.json')

if not API_KEY:
    raise SystemExit('TWELVE_DATA_API_KEY secret is required')

def get_json(url):
    req=Request(url, headers={'User-Agent':'CPD-SUPER-WIZARD-AI/1.8'})
    with urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode('utf-8'))

def candles(symbol, interval, size):
    q=urlencode({'symbol':symbol,'interval':interval,'outputsize':size,'apikey':API_KEY,'format':'JSON','timezone':'UTC'})
    d=get_json('https://api.twelvedata.com/time_series?'+q)
    if d.get('status') == 'error': raise RuntimeError(d.get('message','Twelve Data error'))
    rows=[]
    for x in reversed(d.get('values',[])):
        rows.append({'t':x['datetime'],'o':float(x['open']),'h':float(x['high']),'l':float(x['low']),'c':float(x['close'])})
    return rows

def aggregate(rows, minutes):
    out=[]; cur=None; bucket=None
    for x in rows:
        try: ts=int(datetime.fromisoformat(x['t'].replace('Z','+00:00')).timestamp())
        except Exception: continue
        b=(ts//(minutes*60))*(minutes*60)
        if bucket != b:
            if cur: out.append(cur)
            bucket=b; cur={'t':datetime.fromtimestamp(b,timezone.utc).isoformat(),'o':x['o'],'h':x['h'],'l':x['l'],'c':x['c']}
        else:
            cur['h']=max(cur['h'],x['h']); cur['l']=min(cur['l'],x['l']); cur['c']=x['c']
    if cur: out.append(cur)
    return out

def ema(vals,n):
    if len(vals)<n:return None
    k=2/(n+1); e=sum(vals[:n])/n
    for v in vals[n:]:e=v*k+e*(1-k)
    return e

def atr(rows,n=14):
    if len(rows)<n+1:return None
    trs=[]
    for i in range(1,len(rows)):
        x,p=rows[i],rows[i-1]
        trs.append(max(x['h']-x['l'],abs(x['h']-p['c']),abs(x['l']-p['c'])))
    return sum(trs[-n:])/n

def rsi(rows,n=14):
    if len(rows)<n+1:return 50
    g=l=0.0
    for i in range(len(rows)-n,len(rows)):
        d=rows[i]['c']-rows[i-1]['c']
        if d>0:g+=d
        else:l-=d
    if l==0:return 100
    return 100-100/(1+g/l)

def pivot_high(rows,i):
    return i>=2 and i+2<len(rows) and rows[i]['h']>=rows[i-1]['h'] and rows[i]['h']>=rows[i+1]['h'] and rows[i]['h']>=rows[i-2]['h'] and rows[i]['h']>=rows[i+2]['h']

def pivot_low(rows,i):
    return i>=2 and i+2<len(rows) and rows[i]['l']<=rows[i-1]['l'] and rows[i]['l']<=rows[i+1]['l'] and rows[i]['l']<=rows[i-2]['l'] and rows[i]['l']<=rows[i+2]['l']

def pivots(rows,kind,start,end):
    out=[]
    for i in range(max(2,start),min(len(rows)-3,end)+1):
        if kind=='H' and pivot_high(rows,i):out.append((i,rows[i]['h']))
        if kind=='L' and pivot_low(rows,i):out.append((i,rows[i]['l']))
    return out

def detect_pattern(r,a):
    if len(r)<40 or a<=0:return (0,'NONE','NONE')
    n=len(r); i=n-2; x=r[i]; q=r[i-1]
    body=abs(x['c']-x['o']); lw=min(x['o'],x['c'])-x['l']; uw=x['h']-max(x['o'],x['c'])
    if q['c']<q['o'] and x['c']>x['o'] and x['o']<=q['c'] and x['c']>=q['o']:return (1,'Bullish Engulfing','TRUE')
    if q['c']>q['o'] and x['c']<x['o'] and x['o']>=q['c'] and x['c']<=q['o']:return (-1,'Bearish Engulfing','TRUE')
    if lw>=max(2*body,.25*a) and uw<=max(.8*body,.05*a) and x['c']>x['o']:return (1,'Hammer','TRUE')
    if uw>=max(2*body,.25*a) and lw<=max(.8*body,.05*a) and x['c']<x['o']:return (-1,'Shooting Star','TRUE')
    hs=pivots(r,'H',max(3,n-55),n-3); ls=pivots(r,'L',max(3,n-55),n-3); tol=.45*a
    if len(hs)>=2:
        p1,p2=hs[-2],hs[-1]; valley=min((z['l'] for z in r[p1[0]+1:p2[0]]),default=1e99)
        if p2[0]-p1[0]>=4 and abs(p1[1]-p2[1])<=tol and x['c']<valley-.05*a:return (-1,'Double Top','TRUE')
    if len(ls)>=2:
        p1,p2=ls[-2],ls[-1]; peak=max((z['h'] for z in r[p1[0]+1:p2[0]]),default=-1e99)
        if p2[0]-p1[0]>=4 and abs(p1[1]-p2[1])<=tol and x['c']>peak+.05*a:return (1,'Double Bottom','TRUE')
    if len(hs)>=3:
        a1,head,a2=hs[-3],hs[-2],hs[-1]
        n1=min((z['l'] for z in r[a1[0]+1:head[0]]),default=0); n2=min((z['l'] for z in r[head[0]+1:a2[0]]),default=0)
        if abs(a1[1]-a2[1])<=.55*a and head[1]>max(a1[1],a2[1])+.35*a and x['c']<(n1+n2)/2-.05*a:return (-1,'Head & Shoulders','TRUE')
    if len(ls)>=3:
        a1,head,a2=ls[-3],ls[-2],ls[-1]
        n1=max((z['h'] for z in r[a1[0]+1:head[0]]),default=0); n2=max((z['h'] for z in r[head[0]+1:a2[0]]),default=0)
        if abs(a1[1]-a2[1])<=.55*a and head[1]<min(a1[1],a2[1])-.35*a and x['c']>(n1+n2)/2+.05*a:return (1,'Inverse Head & Shoulders','TRUE')
    hi=max(z['h'] for z in r[max(2,n-10):n-2]); lo=min(z['l'] for z in r[max(2,n-10):n-2])
    if hi-lo<=2.2*a and x['c']>hi+.05*a and x['c']>x['o']:return (1,'Bullish Consolidation Breakout','TRUE')
    if hi-lo<=2.2*a and x['c']<lo-.05*a and x['c']<x['o']:return (-1,'Bearish Consolidation Breakout','TRUE')
    return (0,'NONE','NONE')

def sr_info(r,d,a):
    if len(r)<50:return (0,'NO_CLEAR_LEVEL','NONE')
    n=len(r); px=r[-2]['c']; ps=pivots(r,'L' if d>0 else 'H',max(3,n-75),n-3)
    if not ps:return (0,'NO_CLEAR_LEVEL','NONE')
    best=min(ps,key=lambda p:abs(p[1]-px));
    if abs(best[1]-px)>1.25*a:return (0,'NO_CLEAR_LEVEL','NONE')
    touches=[p for p in ps if abs(p[1]-best[1])<=.45*a]
    reaction=max((abs(r[min(n-2,p[0]+2)]['c']-best[1]) for p in touches),default=0)
    strong=len(touches)>=2 and reaction>=.60*a
    return (2 if strong else 1, 'Support' if d>0 else 'Resistance', 'STRONG' if strong else 'WEAK')

def structure(r,d,a):
    n=len(r); hs=pivots(r,'H',n-18,n-3); ls=pivots(r,'L',n-18,n-3)
    if len(hs)<2 or len(ls)<2:return 0
    lh,ph=hs[-1][1],hs[-2][1]; ll,pl=ls[-1][1],ls[-2][1]; c=r[-2]['c']
    sequp=lh>ph+.10*a and ll>pl+.10*a; seqdn=lh<ph-.10*a and ll<pl-.10*a
    return 2 if d>0 and sequp and c>lh+.10*a else -2 if d<0 and seqdn and c<ll-.10*a else 0

def sweep(r,d,a):
    x=r[-2]; prior_l=min(z['l'] for z in r[-16:-2]); prior_h=max(z['h'] for z in r[-16:-2])
    if d>0:return x['l']<prior_l-.05*a and x['c']>prior_l and (x['c']>x['o'] or abs(x['c']-x['o'])>=.35*a)
    return x['h']>prior_h+.05*a and x['c']<prior_h and (x['c']<x['o'] or abs(x['c']-x['o'])>=.35*a)

def displacement(r,d,a):
    x=r[-2]; body=abs(x['c']-x['o']); rng=max(x['h']-x['l'],1e-12); loc=(x['c']-x['l'])/rng if d>0 else (x['h']-x['c'])/rng
    return (x['c']>x['o'] if d>0 else x['c']<x['o']) and body>=.8*a and loc>=.65

def trigger(r,d,a):
    prev,live=r[-2],r[-1]; px=live['c']; buffer=.02*a
    return px>prev['h']+buffer if d>0 else px<prev['l']-buffer

def breakout_quality(r,d,a):
    x=r[-2]; hi=max(z['h'] for z in r[-18:-2]); lo=min(z['l'] for z in r[-18:-2])
    if d>0:
        if x['h']>hi+.05*a and x['c']>hi+.02*a:return 'TRUE BREAKOUT'
        if x['l']<lo-.05*a and x['c']>lo:return 'FALSE BREAKOUT / BULLISH SWEEP'
    else:
        if x['l']<lo-.05*a and x['c']<lo-.02*a:return 'TRUE BREAKOUT'
        if x['h']>hi+.05*a and x['c']<hi:return 'FALSE BREAKOUT / BEARISH SWEEP'
    return 'NO CONFIRMED BREAKOUT'

def score_symbol(symbol):
    h1=candles(symbol,'1h',500); m5=candles(symbol,'5min',500); m15=aggregate(m5,15); h4=aggregate(h1,240)
    if len(h4)<210 or len(h1)<210 or len(m15)<80 or len(m5)<60:return {'symbol':symbol,'valid':False,'status':'insufficient data'}
    ch1=[x['c'] for x in h1]; ch4=[x['c'] for x in h4]; e50h1=ema(ch1,50); e200h1=ema(ch1,200); e50h4=ema(ch4,50); e200h4=ema(ch4,200)
    d=1 if ch1[-2]>e50h1 and e50h1>e200h1 and ch4[-2]>e50h4 and e50h4>e200h4 else -1 if ch1[-2]<e50h1 and e50h1<e200h1 and ch4[-2]<e50h4 and e50h4<e200h4 else 0
    last=m5[-1]['c']; a15=atr(m15,14) or 0; a5=atr(m5,14) or 0
    if d==0 or a15<=0 or a5<=0:return {'symbol':symbol,'valid':False,'status':'no aligned HTF trend','price':last}
    st=structure(m15,d,a15); liq=sweep(m15,d,a15); dis=displacement(m15,d,a15); trig=trigger(m5,d,a5); mom=(ema([x['c'] for x in m15],50)>ema([x['c'] for x in m15],200) and rsi(m15)>50) if d>0 else (ema([x['c'] for x in m15],50)<ema([x['c'] for x in m15],200) and rsi(m15)<50)
    pd,pname,pq=detect_pattern(m15,a15); srscore,sname,sq=sr_info(m15,d,a15); bq=breakout_quality(m15,d,a15)
    if st!=2 or not liq or not dis or not trig:return {'symbol':symbol,'valid':False,'status':'no confirmed setup','score':0,'price':last}
    score=20+20+15+15+(5 if mom else 0)+(10 if pd==d else 0)+(10 if srscore>0 else 0)
    if score<85 or (pd!=d and srscore<2):return {'symbol':symbol,'valid':False,'status':'quality gate rejected','score':score,'price':last}
    entry=last
    swing=m5[-2]['l'] if d>0 else m5[-2]['h']
    for z in m5[max(0,len(m5)-10):len(m5)-2]: swing=min(swing,z['l']) if d>0 else max(swing,z['h'])
    sl=swing-0.20*a15 if d>0 else swing+0.20*a15
    risk=abs(entry-sl)
    if risk<=0 or risk>3.5*a15:return {'symbol':symbol,'valid':False,'status':'SL/risk geometry rejected','score':score,'price':last}
    ema50m=ema([x['c'] for x in m15],50)
    if ema50m is None or abs(m15[-2]['c']-ema50m)>2.5*a15:return {'symbol':symbol,'valid':False,'status':'extension rejected','score':score,'price':last}
    tp1=entry+(0.8*risk if d>0 else -0.8*risk); tp2=entry+(1.6*risk if d>0 else -1.6*risk); tp3=entry+(2.6*risk if d>0 else -2.6*risk); tp4=entry+(4*risk if d>0 else -4*risk); final=entry+(6*risk if d>0 else -6*risk)
    reason=f'HTF ALIGNMENT 20/20 • STRUCTURE 20/20 • LIQUIDITY SWEEP 15/15 • DISPLACEMENT 15/15 • M15 MOMENTUM {5 if mom else 0}/5 • PATTERN {10 if pd==d else 0}/10'+(f' {pname} [TRUE]' if pd==d else '')+f' • S/R {10 if srscore>0 else 0}/10 {sname} [{sq}] • BREAKOUT {bq}'
    return {'symbol':symbol,'valid':True,'direction':'BUY' if d>0 else 'SELL','entry':entry,'sl':sl,'tp1':tp1,'tp2':tp2,'tp3':tp3,'tp4':tp4,'final':final,'confidence':round(min(95,score),1),'reason':reason,'pattern':pname,'pattern_quality':pq,'sr':sname,'sr_quality':sq,'breakout':bq,'detected_at':datetime.now(timezone.utc).isoformat(),'status':'CONFIRMED'}

def load():
    try:return json.loads(open(OUT).read())
    except Exception:return {'updated_at':None,'scanner':'cloud','active':None,'history':[]}

def advance_publication(data):
    a=data.get('active')
    if a and a.get('status')=='INCOMING':
        try:
            if datetime.now(timezone.utc).timestamp()>=datetime.fromisoformat(a['publish_at'].replace('Z','+00:00')).timestamp():
                a['status']='PUBLISHED';a['published_at']=datetime.now(timezone.utc).isoformat()
        except Exception:pass

def mark_outcome(data,prices):
    a=data.get('active')
    if not a or a.get('status')!='PUBLISHED':return
    px=prices.get(a['symbol'])
    if px is None:return
    d=a['direction']; old=a.get('status','PUBLISHED'); status=old
    if d=='BUY':
        if px<=a['sl']: status='SL'
        elif px>=a['final']: status='TP4/FINAL'
        elif px>=a['tp4']: status='TP4'
        elif px>=a['tp3']: status='TP3'
        elif px>=a['tp2']: status='TP2'
        elif px>=a['tp1']: status='TP1'
    else:
        if px>=a['sl']: status='SL'
        elif px<=a['final']: status='TP4/FINAL'
        elif px<=a['tp4']: status='TP4'
        elif px<=a['tp3']: status='TP3'
        elif px<=a['tp2']: status='TP2'
        elif px<=a['tp1']: status='TP1'
    rank={'PUBLISHED':0,'TP1':1,'TP2':2,'TP3':3,'TP4':4,'TP4/FINAL':5,'SL':6}
    # A milestone never moves backwards. SL is terminal only if it occurs before the final target.
    if status not in ('SL',) and rank.get(status,0)<rank.get(old,0):status=old
    if status!=old:
        a['status']=status;a['last_price']=px;a['updated_at']=datetime.now(timezone.utc).isoformat()
        if status in ('SL','TP4/FINAL'):
            data.setdefault('history',[]).insert(0,a.copy());data['history']=data['history'][:50];data['active']=None

def main():
    data=load();data['updated_at']=datetime.now(timezone.utc).isoformat();data['scanner']='C.P.D CLOUD SCANNER';data['market_data']='Twelve Data';data['schedule']='quality scan'
    prices={};candidates=[]
    for sym in SYMBOLS:
        try:
            r=score_symbol(sym)
            if r.get('price'):prices[sym]=r['price']
            candidates.append(r)
        except Exception as e:candidates.append({'symbol':sym,'valid':False,'status':'data error: '+str(e)[:120]})
    advance_publication(data);mark_outcome(data,prices)
    confirmed=[x for x in candidates if x.get('valid')];confirmed.sort(key=lambda x:x.get('confidence',0),reverse=True)
    if confirmed and data.get('active') is None:
        best=confirmed[0];best['status']='INCOMING';best['detected_at']=datetime.now(timezone.utc).isoformat();best['publish_at']=datetime.fromtimestamp(datetime.now(timezone.utc).timestamp()+120,timezone.utc).isoformat();data['active']=best
    if data.get('active'):data['status']='SIGNAL '+data['active'].get('status','INCOMING')+' • '+data['active'].get('symbol','')+' '+data['active'].get('direction','')+' • '+str(data['active'].get('confidence',''))+'/95'
    else:data['status']='SCANNING • no confirmed C.P.D setup'
    data['candidates']=[{'symbol':x.get('symbol'),'valid':x.get('valid',False),'status':x.get('status'),'score':x.get('score'),'price':x.get('price'),'pattern':x.get('pattern'),'sr':x.get('sr'),'sr_quality':x.get('sr_quality'),'breakout':x.get('breakout')} for x in candidates]
    with open(OUT,'w') as f:json.dump(data,f,indent=2)

if __name__=='__main__':main()
