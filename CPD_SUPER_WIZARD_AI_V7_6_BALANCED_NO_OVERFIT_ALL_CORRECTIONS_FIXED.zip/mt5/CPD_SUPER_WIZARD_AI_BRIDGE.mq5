#property strict
#property version "7.6"
#property description "C.P.D SUPER WIZARD AI — authenticated MT5 bridge with strict DEMO/REAL account-mode verification"

#include <Trade/Trade.mqh>
CTrade trade;

input string CPD_Bridge_URL="";       // Example: https://cpd-mt5-bridge.onrender.com
input string CPD_Bridge_Token="";     // Must match bridge secret
input int PollSeconds=2;
input bool AllowDemoAuto=true;
input bool AllowNormalAuto=true;
input bool AllowAggressiveAuto=true;
input bool AllowLiveAuto=true;
input bool LiveTradingLocked=false;
input long MagicNumber=550035;

string Base(){string b=CPD_Bridge_URL; while(StringLen(b)>0 && StringSubstr(b,StringLen(b)-1,1)=="/") b=StringSubstr(b,0,StringLen(b)-1); return b;}
bool IsReal(){return (ENUM_ACCOUNT_TRADE_MODE)AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_REAL;}
bool DemoOnly(){return !IsReal() && AllowDemoAuto;}

string UrlEncode(string s){ string o=""; for(int i=0;i<StringLen(s);i++){ ushort c=StringGetCharacter(s,i); if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='.'||c=='-'||c=='_') o+=CharToString((uchar)c); else if(c==' ') o+="%20"; else o+=StringFormat("%%%02X",c); } return o; }

string JsonEscape(string s){StringReplace(s,"\\","\\\\");StringReplace(s,"\"","\\\"");return s;}

bool Post(string path,string body,string &out){
   if(StringLen(Base())<8 || StringLen(CPD_Bridge_Token)<8) return false;
   string headers="Content-Type: application/json\r\nAuthorization: Bearer "+CPD_Bridge_Token+"\r\n";
   uchar data[],result[]; string rh;
   StringToCharArray(body,data,0,WHOLE_ARRAY,CP_UTF8); ArrayResize(data,ArraySize(data)-1);
   int code=WebRequest("POST",Base()+path,headers,8000,data,ArraySize(data),result,rh);
   out=CharArrayToString(result,0,-1,CP_UTF8); return code>=200 && code<300;
}

bool Get(string path,string &out){
   if(StringLen(Base())<8 || StringLen(CPD_Bridge_Token)<8) return false;
   uchar data[],result[]; string rh;
   string headers="Authorization: Bearer "+CPD_Bridge_Token+"\r\n";
   int code=WebRequest("GET",Base()+path,headers,8000,data,result,rh);
   out=CharArrayToString(result,0,-1,CP_UTF8); return code>=200 && code<300;
}

string AccountJson(){
   string mode=IsReal()?"REAL":"DEMO";
   return StringFormat("{\"login\":%I64d,\"server\":\"%s\",\"mode\":\"%s\",\"balance\":%.2f,\"equity\":%.2f,\"currency\":\"%s\"}",
      AccountInfoInteger(ACCOUNT_LOGIN),JsonEscape(AccountInfoString(ACCOUNT_SERVER)),mode,AccountInfoDouble(ACCOUNT_BALANCE),AccountInfoDouble(ACCOUNT_EQUITY),JsonEscape(AccountInfoString(ACCOUNT_CURRENCY)),AccountInfoDouble(ACCOUNT_MARGIN_LEVEL));
}

string PositionsJson(){
   string s="["; bool first=true;
   for(int i=0;i<PositionsTotal();i++){
      ulong ticket=PositionGetTicket(i); if(ticket==0) continue; if(!PositionSelectByTicket(ticket)) continue;
      if(!first)s+=","; first=false;
      s+=StringFormat("{\"ticket\":%I64u,\"symbol\":\"%s\",\"type\":\"%s\",\"volume\":%.2f,\"entry\":%.8f,\"sl\":%.8f,\"tp\":%.8f,\"profit\":%.2f}",ticket,
         JsonEscape(PositionGetString(POSITION_SYMBOL)),PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY?"BUY":"SELL",PositionGetDouble(POSITION_VOLUME),PositionGetDouble(POSITION_PRICE_OPEN),PositionGetDouble(POSITION_SL),PositionGetDouble(POSITION_TP),PositionGetDouble(POSITION_PROFIT));
   }
   return s+"]";
}

string PeriodStats(datetime from){
   int wins=0,losses=0,closed=0; double net=0.0;
   if(!HistorySelect(from,TimeCurrent())) return StringFormat("{\"closed\":0,\"wins\":0,\"losses\":0,\"winRate\":0,\"net\":0}");
   int total=HistoryDealsTotal();
   for(int i=0;i<total;i++){
      ulong ticket=HistoryDealGetTicket(i); if(ticket==0) continue;
      long entry=HistoryDealGetInteger(ticket,DEAL_ENTRY); if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY) continue;
      double p=HistoryDealGetDouble(ticket,DEAL_PROFIT)+HistoryDealGetDouble(ticket,DEAL_SWAP)+HistoryDealGetDouble(ticket,DEAL_COMMISSION);
      closed++; net+=p; if(p>0.0000001) wins++; else if(p< -0.0000001) losses++;
   }
   double wr=closed>0?(100.0*wins/closed):0.0;
   return StringFormat("{\"closed\":%d,\"wins\":%d,\"losses\":%d,\"winRate\":%.2f,\"net\":%.2f}",closed,wins,losses,wr,net);
}

string StatsJson(){
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   datetime week=TimeCurrent()-7*24*60*60;
   datetime month=TimeCurrent()-30*24*60*60;
   return StringFormat("{\"weekly\":%s,\"monthly\":%s}",PeriodStats(week),PeriodStats(month));
}

void Heartbeat(){
   if(StringLen(CPD_Bridge_URL)<8 || StringLen(CPD_Bridge_Token)<8) return;
   string acc=AccountJson();
   // Attach rolling 7-day and 30-day closed-deal performance to the account snapshot.
   int pos=StringLen(acc)-1; if(pos>=0 && StringSubstr(acc,pos,1)=="}") acc=StringSubstr(acc,0,pos)+",\"stats\":"+StatsJson()+"}";
   string body=StringFormat("{\"login\":%I64d,\"server\":\"%s\",\"account\":%s,\"positions\":%s}",AccountInfoInteger(ACCOUNT_LOGIN),JsonEscape(AccountInfoString(ACCOUNT_SERVER)),acc,PositionsJson());
   string out; Post("/mt5/heartbeat",body,out);
}

void Report(string id,string status,ulong ticket,double price,string msg){
   string body=StringFormat("{\"id\":\"%s\",\"login\":%I64d,\"server\":\"%s\",\"status\":\"%s\",\"ticket\":%I64u,\"price\":%.8f,\"message\":\"%s\"}",JsonEscape(id),AccountInfoInteger(ACCOUNT_LOGIN),JsonEscape(AccountInfoString(ACCOUNT_SERVER)),JsonEscape(status),ticket,price,JsonEscape(msg));
   string out; Post("/mt5/report",body,out);
}

bool TradeRetcodeSuccess(ulong code, string action){
   if(code==TRADE_RETCODE_DONE) return true;
   if(code==TRADE_RETCODE_DONE_PARTIAL && (action=="OPEN" || action=="CLOSE")) return true;
   return false;
}

void ExecuteLine(string line){
   string f[]; int n=StringSplit(line,'|',f); if(n<8) return;
   string id=f[0],action=f[1],mode=f[2],direction=f[3],symbol=f[4]; double volume=StringToDouble(f[5]),sl=StringToDouble(f[6]),tp=StringToDouble(f[7]); ulong ticket=(n>=9?(ulong)StringToInteger(f[8]):0);
   if(IsReal() && (!AllowLiveAuto || LiveTradingLocked)){Print("CPD SAFETY: REAL account — LIVE EXECUTION DISABLED.");Report(id,"REJECTED_LIVE_LOCK",0,0,"Live execution is disabled in EA inputs");return;}
   if(!IsReal() && !DemoOnly()){Report(id,"REJECTED_DEMO_DISABLED",0,0,"Demo execution disabled");return;}
   if(mode=="NORMAL" && !AllowNormalAuto){Report(id,"REJECTED_NORMAL_DISABLED",0,0,"Normal Auto disabled");return;}
   if(mode=="AGGRESSIVE" && !AllowAggressiveAuto){Report(id,"REJECTED_AGGRESSIVE_DISABLED",0,0,"Aggressive Auto disabled");return;}
   trade.SetExpertMagicNumber(MagicNumber); trade.SetDeviationInPoints(30);
   bool ok=false;
   if(action=="OPEN"){
      if(volume<=0) volume=0.01;
      if(!SymbolSelect(symbol,true)){Report(id,"REJECTED",0,0,"Symbol is not available in MT5");return;}
      if(direction=="SELL") ok=trade.Sell(volume,symbol,0,sl,tp,mode=="AGGRESSIVE"?"CPD AGGRESSIVE":"CPD NORMAL");
      else ok=trade.Buy(volume,symbol,0,sl,tp,mode=="AGGRESSIVE"?"CPD AGGRESSIVE":"CPD NORMAL");
      ulong rc=trade.ResultRetcode();
      if(ok && TradeRetcodeSuccess(rc,"OPEN")) Report(id,"FILLED",trade.ResultOrder(),trade.ResultPrice(),trade.ResultRetcodeDescription());
      else Report(id,"REJECTED",trade.ResultOrder(),trade.ResultPrice(),StringFormat("%s (retcode=%I64u)",trade.ResultRetcodeDescription(),rc));
   } else if(action=="MODIFY"){
      if(ticket==0 || !PositionSelectByTicket(ticket)){Report(id,"REJECTED",ticket,0,"Position ticket not found");return;}
      ok=trade.PositionModify(ticket,sl,tp);
      ulong rc=trade.ResultRetcode();
      if(ok && TradeRetcodeSuccess(rc,"MODIFY")) Report(id,"MODIFIED",ticket,PositionGetDouble(POSITION_PRICE_OPEN),trade.ResultRetcodeDescription());
      else Report(id,"REJECTED",ticket,0,StringFormat("%s (retcode=%I64u)",trade.ResultRetcodeDescription(),rc));
   } else if(action=="CLOSE"){
      if(ticket==0 || !PositionSelectByTicket(ticket)){Report(id,"REJECTED",ticket,0,"Position ticket not found");return;}
      ok=trade.PositionClose(ticket);
      ulong rc=trade.ResultRetcode();
      if(ok && TradeRetcodeSuccess(rc,"CLOSE")) Report(id,"CLOSED",ticket,trade.ResultPrice(),trade.ResultRetcodeDescription());
      else Report(id,"REJECTED",ticket,0,StringFormat("%s (retcode=%I64u)",trade.ResultRetcodeDescription(),rc));
   }
}

void Poll(){
   if(StringLen(CPD_Bridge_URL)<8 || StringLen(CPD_Bridge_Token)<8) return;
   string url=StringFormat("/mt5/poll?login=%I64d&server=%s",AccountInfoInteger(ACCOUNT_LOGIN),UrlEncode(AccountInfoString(ACCOUNT_SERVER)));
   string out; if(!Get(url,out)) return;
   string lines[]; int n=StringSplit(out,'\n',lines); for(int i=0;i<n;i++){string x=lines[i];StringTrimLeft(x);StringTrimRight(x);if(StringLen(x)>0)ExecuteLine(x);}
}

int OnInit(){
   EventSetTimer(MathMax(1,PollSeconds));
   trade.SetExpertMagicNumber(MagicNumber);
   if(IsReal()) Print("C.P.D: REAL ACCOUNT detected — live execution available only when AllowLiveAuto=true and LiveTradingLocked=false."); else Print("C.P.D: DEMO ACCOUNT detected — bridge execution enabled.");
   return INIT_SUCCEEDED;
}
void OnDeinit(const int reason){EventKillTimer();}
void OnTimer(){Heartbeat();Poll();}
