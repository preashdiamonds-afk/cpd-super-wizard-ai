package com.pepestone.app;

import android.os.*;
import java.util.*;

/** Automatically scans public market data using the mobile V7.6 strategy. It only emits signals; it never places orders. */
public class AutoSignalScanner {
  public interface Listener { void status(String text); void signal(StrategyEngine.Signal s); }
  private final PublicMarketDataClient data=new PublicMarketDataClient(); private final TradingViewClient tradingView=new TradingViewClient(); private final MarketContextClient contextClient=new MarketContextClient(); private final StrategyEngine engine=new StrategyEngine(); private final Listener listener;
  private final String[] symbols={"EURUSD","GBPUSD","USDJPY","AUDJPY","AUDCAD","AUDCHF","USDCAD","USDCHF","NZDUSD"};
  private final HashMap<String,Cache> cache=new HashMap<>(); private int cursor=0; private String lastKey=""; private long lastSignal=0;
  private static class Cache{long at;List<StrategyEngine.Candle> v;}
  public AutoSignalScanner(Listener l){listener=l;}
  private List<StrategyEngine.Candle> get(String s,String tf,long ttl)throws Exception{String k=s+tf;Cache c=cache.get(k);long now=System.currentTimeMillis();if(c!=null&&now-c.at<ttl)return c.v;org.json.JSONArray a=data.candles(s,tf,250);ArrayList<StrategyEngine.Candle> r=new ArrayList<>();for(int i=0;i<a.length();i++)r.add(new StrategyEngine.Candle(a.getJSONObject(i)));if(r.size()<60)throw new Exception("not enough "+tf+" candles");c=new Cache();c.at=now;c.v=r;cache.put(k,c);return r;}
  public void scanNext(){String sym=symbols[cursor++%symbols.length];new Thread(()->scan(sym)).start();}
  private void scan(String sym){try{listener.status("SCANNING "+sym+" • LIVE DATA: connecting…");List<StrategyEngine.Candle> h4=get(sym,"4h",3600000L*2);List<StrategyEngine.Candle> h1=get(sym,"1h",3600000L*0+1800000L);List<StrategyEngine.Candle> m15=get(sym,"15m",300000L);List<StrategyEngine.Candle> m5=get(sym,"5m",45000L);org.json.JSONObject p=data.price(sym);double bid=p.optDouble("bid"),ask=p.optDouble("ask"); boolean tv=false; double tvPrice=0; try{org.json.JSONObject tq=tradingView.quote(sym); tv=tq.optDouble("close",0)>0; tvPrice=tq.optDouble("close",0); if(tv){bid=tq.optDouble("bid",bid)>0?tq.optDouble("bid",bid):bid; ask=tq.optDouble("ask",ask)>0?tq.optDouble("ask",ask):ask;}}catch(Exception ignored){} MarketContextClient.Context ctx=contextClient.load(sym); StrategyEngine.Signal s=engine.evaluate(sym,h4,h1,m15,m5,bid,ask,false,ctx,tv,tvPrice); double mid=(bid>0&&ask>0)?(bid+ask)/2.0:(bid>0?bid:ask); String feed="Yahoo"+(tv?" + TradingView":""); String context=(ctx.vixAvailable?"VIX "+String.format(Locale.US,"%.2f",ctx.vix):"VIX n/a"); listener.status(sym+" • LIVE DATA OK • "+feed+" • price "+String.format(Locale.US,"%.5f",mid)+" • "+context); if(s.valid){String k=s.symbol+"|"+s.dir+"|"+String.format(Locale.US,"%.5f",s.entry);long now=System.currentTimeMillis();if(!k.equals(lastKey)||now-lastSignal>900000L){lastKey=k;lastSignal=now;listener.signal(s);}else listener.status(sym+" • setup already alerted");}else listener.status(sym+" • LIVE DATA OK • no confirmed C.P.D setup");}catch(Exception e){listener.status(sym+" • LIVE DATA ERROR: "+e.getMessage());}}
  public String[] getSymbols(){return symbols.clone();}
}
