# C.P.D SUPER WIZARD AI V7.6 — Scanner Corrections

This build is the V7.6 BALANCED / NO-OVERFIT release, preserving the existing chart/scanner architecture.

## Corrections
1. Single-chart scans stay strictly on the uploaded timeframe and now use stronger internal evidence:
   - trend + momentum
   - true/false pattern
   - strong/weak support or resistance
   - breakout quality
   - risk-distance gate
2. Chart symbol OCR is now used to prevent analyzing the wrong market. If uploaded charts show conflicting symbols, the upload is rejected.
3. Duplicate timeframe uploads are rejected instead of silently overwriting a chart.
4. Build workflow is V7.6-specific and uses the V7.6 master source ZIP.
5. App / MT5 bridge version metadata updated to V7.6.
6. Aggressive mode now has a persistent 5% high-water equity lock:
   - the reference is the highest equity reached during the aggressive session, not starting balance;
   - reaching a 5% drawdown from that peak locks aggressive entries and attempts to close the active aggressive position;
   - aggressive mode is capped at one simultaneous position.

## Important
This is still a trading system, not a guarantee of profitable trades. Test on DEMO first and verify broker symbol specifications, spreads, minimum volume, and SL/TP distance rules before enabling live execution.

## V7.6 Settings Update — Aggressive Mode + Daily Targets

- Aggressive Auto now has a persistent **Allow Aggressive Auto** setting in Settings.
- Aggressive Auto cannot be started from the AUTO screen when it is disabled in Settings.
- Daily Profit Target is configurable from Settings and saved locally with the existing C.P.D preferences.
- When enabled and the configured profit target is reached from the day's starting equity, new Auto entries are blocked for the rest of the local trading day.
- Existing open positions are not forcibly closed by the daily target setting.
- A target of 0 disables the daily profit target.
- DEMO/LIVE account verification and existing risk gates remain mandatory.
