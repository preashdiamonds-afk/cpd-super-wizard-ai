package com.pepestone.app;

import android.app.*;import android.content.*;import android.os.IBinder;import java.util.*;

/** Manual execution service: scans automatically, alerts, but NEVER places broker orders. */
public class TradingService extends Service {
  private java.util.concurrent.ScheduledExecutorService exec; private AutoSignalScanner scanner; private NotificationHelper notifications; private SignalScheduler scheduler; private volatile boolean running;
  @Override public void onCreate(){super.onCreate();notifications=new NotificationHelper(this);scheduler=new SignalScheduler();createChannel();startForeground(7001,notification("C.P.D scanner active • manual execution only"));}
  @Override public int onStartCommand(Intent intent,int flags,int startId){startWorker();return START_STICKY;}
  private void startWorker(){if(running)return;running=true;scanner=new AutoSignalScanner(new AutoSignalScanner.Listener(){public void status(String t){android.util.Log.i("CPD_SCAN",t);}public void signal(StrategyEngine.Signal s){scheduler.schedule(120000,()->notifications.notifyIncoming(s),()->notifications.notifySignal(s));android.util.Log.i("CPD_SCAN","SIGNAL "+s.symbol+" "+(s.dir>0?"BUY":"SELL")+" "+s.confidence+"/95");}});exec=java.util.concurrent.Executors.newSingleThreadScheduledExecutor();exec.scheduleAtFixedRate(()->scanner.scanNext(),2,20,java.util.concurrent.TimeUnit.SECONDS);}
  private Notification notification(String text){return new Notification.Builder(this,"cpd_worker").setContentTitle("C.P.D SUPER WIZARD AI").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_search).setOngoing(true).build();}
  private void createChannel(){if(android.os.Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);n.createNotificationChannel(new NotificationChannel("cpd_worker","C.P.D Market Scanner",NotificationManager.IMPORTANCE_LOW));}}
  @Override public void onDestroy(){running=false;if(exec!=null)exec.shutdownNow();if(scheduler!=null)scheduler.cancel();super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
