# C.P.D SUPER WIZARD AI — Manual Signal Vision Edition

V10.35 SMART AGGRESSIVE mobile-first manual trading app.

## New signal features
- Beautiful **C.P.D SIGNAL INCOMING** confirmation stage.
- Two-minute warning before a manual signal is published.
- **AI SETUP VISION** chart showing entry, SL, TP1, TP2, TP3 and final 6R levels.
- One-tap **COPY SIGNAL + REASON + CONFIDENCE**.
- Signal reason and confidence/confluence score shown under every published signal.
- TP1 / TP2 / SL trade-update buttons with notifications and suggested protective-SL action.
- Weekly manual signal journal with signals, wins, losses and win rate.
- Automatic mode remains visible but **LOCKED**. It cannot place orders.

## Important
The setup drawing is an illustrative AI-style visualization, not a broker screenshot. Live market prices/signals still require a supported market-data/MT5 bridge. No Exness password or API secret is required for the manual-only workflow.


## v1.6 — Automatic signal scanning / manual execution
- The phone scans a watchlist automatically using the V10.35 strategy engine.
- Manual Mode means **manual trade execution**, not manual signal creation.
- A valid setup triggers **C.P.D SIGNAL INCOMING**, then the final signal 2 minutes later.
- Automatic order execution remains disabled. The user places the trade manually in Exness MT5.
- This build uses public Yahoo Finance chart data and is not an authenticated Exness price feed; prices may differ from Exness.
- The scanner runs as an Android foreground service so the user can see that market monitoring is active. Android documents foreground services for noticeable ongoing work and requires a persistent notification.


## Live multi-source signal scanning
The manual-execution scanner now cross-checks live FX quotes with the public TradingView forex scanner, uses a public market-data feed for OHLC candles, and checks Investing.com and Forex Factory economic-calendar pages plus VIX context. TradingView is used as a quote/market confirmation source; the app never places an order. High-impact calendar context can block a normal-mode signal rather than manufacture one.
