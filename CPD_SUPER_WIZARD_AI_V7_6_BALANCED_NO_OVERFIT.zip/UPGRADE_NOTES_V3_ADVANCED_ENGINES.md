# C.P.D SUPER WIZARD AI — Advanced Engines Upgrade

## Included
- Non-blocking Advanced Trade Intelligence Engine: structure, pattern, S/R, momentum, liquidity, breakout, MTF and volatility evidence.
- Chart-validity gate in C.P.D Scanner. An attached non-chart image returns INVALID IMAGE instead of using the selected pair as if it came from the image.
- Scanner explicitly separates chart validation, live market data and final decision.
- Existing Adaptive Market-Regime Engine remains active.
- Existing Normal Auto, Aggressive Auto and C.P.D Academy remain in the project.

## Filtering philosophy
Advanced evidence is primarily scoring/context, not eight independent hard gates. The goal is more intelligence without starving the system of trades.

## Important limitation
The Android scanner does not claim to OCR a symbol from arbitrary pixels. When a screenshot is attached, the app first checks whether it looks like a usable chart; the selected market remains the market being analyzed. A non-chart image is rejected rather than assigned EURUSD.
