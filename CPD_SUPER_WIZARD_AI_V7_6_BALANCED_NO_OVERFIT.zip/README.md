# C.P.D SUPER WIZARD AI — V7.2

## WELCOME, CAPTAIN PREASH DIAMOND

C.P.D SUPER WIZARD AI is a mobile trading command center designed around MT5/Exness execution through a dedicated C.P.D bridge and MT5 Expert Advisor.

### Included features
- C.P.D Lessons / Academy
- CPD Scanner with BUY / SELL / WAIT decisions
- Normal Auto
- Separate Aggressive Auto
- Manual / Signal Center
- Copy Signal
- Market watch and multi-timeframe analysis
- Market Structure, Pattern, Support/Resistance, Liquidity, Momentum and Risk engines
- MT5 / Exness bridge architecture
- Demo and real-account mode detection from MT5
- MT5 order operations: OPEN, MODIFY SL/TP and CLOSE
- Position/account synchronization

### Real-account architecture
The Android app does not pretend that the Android MT5 mobile app can host an MQL5 Expert Advisor. The execution path is:

C.P.D Android app → authenticated C.P.D Bridge → MT5 terminal + C.P.D EA → Exness MT5 account

For real execution, an MT5 terminal must be running the C.P.D EA and must be connected to the intended Exness account. The EA reads the actual MT5 account mode and the bridge validates the account before accepting commands.

### Build
The project contains `settings.gradle`, root `build.gradle`, `app/build.gradle`, and a GitHub Actions workflow. The cloud workflow extracts the project ZIP, installs/uses Android SDK components, configures Gradle 8.9, builds the debug APK, and uploads the APK as an artifact.

### Security
Never commit Exness passwords, API secrets, or private trading credentials. Bridge authentication uses a secret token supplied at runtime. Test on demo before enabling real-money execution.

### Important
A working APK alone does not prove that real trading is connected. The MT5 EA, bridge, terminal and Exness account must all report a valid connection before an order can be executed.
