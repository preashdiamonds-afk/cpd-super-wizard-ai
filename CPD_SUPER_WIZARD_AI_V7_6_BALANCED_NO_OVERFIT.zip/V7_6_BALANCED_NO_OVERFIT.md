# C.P.D SUPER WIZARD AI V7.6 — Balanced / Reduced-Overfitting Scanner

V7.5 was audited for excessive filtering. V7.6 keeps the safety and market-structure concepts but removes unnecessary hard gates that could reduce valid trade frequency.

## Normal-mode changes
- Normal score threshold: 65 instead of 70.
- Structure can be developing (score 1) instead of requiring the strongest structure state.
- M5 execution trigger remains required.
- At least 2 independent evidence sources are required from liquidity sweep, displacement, momentum, pattern, or S/R.
- Liquidity sweep and displacement no longer both have to occur on every trade.
- Regime classification is contextual instead of stacking additional hard filters.
- VIX is contextual rather than an extra S/R gate.
- High-impact news protection remains for normal mode.
- Existing ATR/SL/extension checks remain.

## Single-chart mode
- Threshold reduced from 70 to 65.
- A single chart still needs at least 2 positive evidence sources.
- It never secretly uses another timeframe.

## Goal
This is intentionally a normal, generalizable confluence model—not a hyper-specific backtest-fitted strategy. It should allow more legitimate setups while still rejecting weak/no-evidence signals.

Test on demo and measure trade count, win rate, expectancy, drawdown, and performance across multiple symbols and periods before live use.
