package com.pepestone.app;

import java.util.*;

/**
 * C.P.D adaptive market-regime classifier.
 *
 * This engine does not predict the future. It classifies the current market
 * environment from the supplied candles and external risk context so the
 * strategy layer can choose a safer strategy profile.
 */
public final class MarketRegimeEngine {
  public enum Regime {
    TRENDING,
    RANGING,
    BREAKOUT,
    REVERSAL,
    HIGH_VOLATILITY,
    LOW_VOLATILITY,
    NEWS,
    ABNORMAL,
    UNKNOWN
  }

  public static final class Result {
    public Regime regime=Regime.UNKNOWN;
    public Regime secondaryVolatility=Regime.UNKNOWN;
    public int direction=0;
    public double trendStrength=0;
    public double compression=0;
    public double volatilityRatio=1.0;
    public boolean liquiditySweep=false;
    public boolean displacement=false;
    public boolean breakout=false;
    public boolean reversal=false;
    public boolean newsRisk=false;
    public boolean abnormal=false;
    public String strategyProfile="DEFENSIVE";
    public String reason="Insufficient market data.";

    public String label(){
      String base=regime.name().replace('_',' ');
      if(secondaryVolatility==Regime.HIGH_VOLATILITY && regime!=Regime.HIGH_VOLATILITY && regime!=Regime.NEWS) base+=" • HIGH VOL";
      if(secondaryVolatility==Regime.LOW_VOLATILITY && regime!=Regime.LOW_VOLATILITY) base+=" • LOW VOL";
      return base;
    }
  }

  private MarketRegimeEngine(){}

  public static Result classify(List<StrategyEngine.Candle> h4,
                                List<StrategyEngine.Candle> h1,
                                List<StrategyEngine.Candle> m15,
                                List<StrategyEngine.Candle> m5,
                                MarketContextClient.Context ctx){
    Result out=new Result();
    if(h4==null||h1==null||m15==null||m5==null||h1.size()<60||m15.size()<40||m5.size()<30) return out;

    double a15=StrategyEngine.atr(m15,14);
    double a5=StrategyEngine.atr(m5,14);
    if(a15<=0||a5<=0) return out;

    double longAtr=averageAtr(m15,14,60);
    out.volatilityRatio=longAtr>0?a15/longAtr:1.0;
    out.secondaryVolatility=out.volatilityRatio>=1.55?Regime.HIGH_VOLATILITY:
        out.volatilityRatio<=0.65?Regime.LOW_VOLATILITY:Regime.UNKNOWN;

    int h1Trend=trendDirection(h1);
    int h4Trend=trendDirection(h4);
    int m15Trend=trendDirection(m15);
    out.direction=h1Trend!=0&&h1Trend==h4Trend?h1Trend:(m15Trend!=0?m15Trend:0);

    double atrNorm=Math.max(a15,1e-12);
    double ema20=StrategyEngine.ema(m15,20), ema50=StrategyEngine.ema(m15,50);
    double px=m15.get(m15.size()-2).c;
    out.trendStrength=Math.min(1.0,Math.abs(ema20-ema50)/atrNorm);

    double hi=-1e99,lo=1e99;
    int from=Math.max(0,m15.size()-22),to=m15.size()-2;
    for(int i=from;i<to;i++){hi=Math.max(hi,m15.get(i).h);lo=Math.min(lo,m15.get(i).l);}
    double range=hi-lo;
    out.compression=range>0?Math.min(1.0,(a15*8.0)/range):0;

    out.liquiditySweep=out.direction>0?StrategyEngine.bullSweep(m15,a15):out.direction<0?StrategyEngine.bearSweep(m15,a15):
        (StrategyEngine.bullSweep(m15,a15)||StrategyEngine.bearSweep(m15,a15));
    out.displacement=out.direction!=0&&StrategyEngine.disp(m15,out.direction,a15);

    StrategyEngine.Candle last=m15.get(m15.size()-2);
    boolean upBreak=last.c>hi+0.05*a15;
    boolean dnBreak=last.c<lo-0.05*a15;
    out.breakout=upBreak||dnBreak;
    out.reversal=out.liquiditySweep && out.displacement && reversalShape(m15,a15);

    out.newsRisk=ctx!=null&&(ctx.investingHighImpact||ctx.forexFactoryHighImpact);
    boolean extremeVol=out.volatilityRatio>=2.20 || out.volatilityRatio<=0.40;
    boolean dataConflict=(h4Trend!=0&&h1Trend!=0&&m15Trend!=0&&h4Trend!=m15Trend&&h1Trend!=m15Trend);
    out.abnormal=extremeVol || dataConflict || a5>2.5*a15;

    if(out.newsRisk){
      out.regime=Regime.NEWS; out.strategyProfile="NEWS_DEFENSIVE";
      out.reason="High-impact calendar context detected; normal strategy is defensive.";
    } else if(out.abnormal){
      out.regime=Regime.ABNORMAL; out.strategyProfile="ABNORMAL_DEFENSIVE";
      out.reason="Volatility or timeframe structure is abnormal/conflicting; reduce exposure and demand stronger confirmation.";
    } else if(out.breakout){
      out.regime=Regime.BREAKOUT; out.strategyProfile="BREAKOUT_CONFIRMATION";
      out.reason="Price has displaced beyond the recent M15 range; require breakout confirmation/retest logic.";
    } else if(out.reversal){
      out.regime=Regime.REVERSAL; out.strategyProfile="REVERSAL_CONFIRMATION";
      out.reason="Liquidity sweep plus displacement suggests a possible reversal; require pattern/level confirmation.";
    } else if(out.secondaryVolatility==Regime.HIGH_VOLATILITY){
      out.regime=Regime.HIGH_VOLATILITY; out.strategyProfile="HIGH_VOLATILITY_ADAPTIVE";
      out.reason="Volatility is materially above its recent M15 baseline; widen validation and reduce risk.";
    } else if(out.secondaryVolatility==Regime.LOW_VOLATILITY){
      out.regime=Regime.LOW_VOLATILITY; out.strategyProfile="LOW_VOLATILITY_ADAPTIVE";
      out.reason="Volatility is compressed; avoid chasing small moves and wait for meaningful displacement.";
    } else if(out.trendStrength>=0.55 && out.direction!=0 && (h4Trend==out.direction || h1Trend==out.direction)){
      out.regime=Regime.TRENDING; out.strategyProfile="TREND_FOLLOW";
      out.reason="Higher-timeframe direction and M15 EMA structure support a directional market.";
    } else {
      out.regime=Regime.RANGING; out.strategyProfile="RANGE_REVERSAL";
      out.reason="Directional trend strength is weak; treat the market as a range and demand strong levels/patterns.";
    }
    return out;
  }

  private static int trendDirection(List<StrategyEngine.Candle> r){
    if(r==null||r.size()<55)return 0;
    int slow=r.size()>=205?200:50;
    double e20=StrategyEngine.ema(r,20),e50=StrategyEngine.ema(r,50),es=StrategyEngine.ema(r,slow);
    double c=r.get(r.size()-2).c;
    if(c>e20&&e20>e50&&e50>=es)return 1;
    if(c<e20&&e20<e50&&e50<=es)return -1;
    return 0;
  }

  private static double averageAtr(List<StrategyEngine.Candle> r,int period,int windows){
    if(r==null||r.size()<period+2)return 0;
    int end=r.size()-2, start=Math.max(period,end-windows+1), count=0; double sum=0;
    for(int i=start;i<=end;i++){
      double tr=0; StrategyEngine.Candle x=r.get(i),q=r.get(i-1);
      tr=Math.max(x.h-x.l,Math.max(Math.abs(x.h-q.c),Math.abs(x.l-q.c)));
      sum+=tr; count++;
    }
    return count>0?sum/count:0;
  }

  private static boolean reversalShape(List<StrategyEngine.Candle> r,double a){
    if(r.size()<4)return false;
    StrategyEngine.Candle x=r.get(r.size()-2),q=r.get(r.size()-3);
    double xb=Math.abs(x.c-x.o), qb=Math.abs(q.c-q.o);
    return xb>=0.45*a || (q.c<q.o&&x.c>x.o&&xb>=0.25*a) || (q.c>q.o&&x.c<x.o&&xb>=0.25*a) || qb>=0.8*a;
  }
}
