package com.pepestone.app;

import android.content.Context;
import org.json.*;
import java.text.*;import java.util.*;

/**
 * Shared trading engine used by the screen and the Android foreground service.
 * Shared trading controller for connected execution. Broker execution is allowed only after the bridge verifies the selected DEMO/REAL account mode and the configured risk gates pass.
 */
public class TradingController {
  public interface Logger { void log(String s); void signal(StrategyEngine.Signal s); default void milestone(String symbol,String milestone,String instruction){} }
  public static final String[] SYMBOLS={"EURUSD","XAUUSD","AUDJPY","AUDCAD","AUDCHF"};
  private final Context ctx; private final Logger out; private final BrokerApiClient api; private final TradeStateStore state; private final StrategyEngine engine=new StrategyEngine();
  private boolean aggressive; private boolean emergency;
  private static final int MAX_TRADES_NORMAL=5; private static final double MAX_DAILY_NORMAL=10.0, MAX_DAILY_AGG=5.0;
  private static final double MAX_SPREAD_POINTS=35.0, MAX_SPREAD_ATR=0.20, MIN_ATR_PCT=0.003, MAX_ATR_PCT=2.0;
  private static final int COOLDOWN_MIN=15;

  public TradingController(Context c,Logger l,BrokerApiClient a,TradeStateStore s){ctx=c.getApplicationContext();out=l;api=a;state=s;}
  public void setAggressive(boolean v){if(v&&!aggressive){state.setBool("aggPeakLock",false);state.setDouble("aggPeakEq",0);}aggressive=v;} public void setEmergency(boolean v){emergency=v;}
  private String dayKey(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
  private void ensureDay(double equity){String d=dayKey();if(!d.equals(state.getLong("day",0)+"")){state.setLong("day",Long.parseLong(d));state.setDouble("dayEq",equity);state.setInt("dayTrades",0);state.setBool("dayLock",false);}}
  private boolean riskLocked(double equity){
    ensureDay(equity);
    if(state.getBool("dayLock",false))return true;
    double start=state.getDouble("dayEq",equity);
    double dd=start>0?Math.max(0,(start-equity)/start*100):0;
    double max=aggressive?MAX_DAILY_AGG:MAX_DAILY_NORMAL;
    if(dd>=max){state.setBool("dayLock",true);out.log("RISK LOCK: daily equity drawdown "+String.format(Locale.US,"%.2f",dd)+"% reached");return true;}
    // Aggressive mode uses the highest equity reached as its reference, not starting capital.
    if(aggressive){
      double peak=state.getDouble("aggPeakEq",equity);
      if(peak<=0)peak=equity;
      if(equity>peak){peak=equity;state.setDouble("aggPeakEq",peak);}
      boolean locked=state.getBool("aggPeakLock",false);
      if(!locked && peak>0 && equity<=peak*0.95){
        state.setBool("aggPeakLock",true);
        out.log("AGGRESSIVE 5% HIGH-WATER LOCK: equity fell "+String.format(Locale.US,"%.2f",100.0*(peak-equity)/peak)+"% from peak "+String.format(Locale.US,"%.2f",peak));
        // Aggressive mode is capped at one position, so closing the currently open position
        // here is safe only because aggressive entries are blocked while other positions exist.
        try{
          JSONArray ps=api.positions();
          for(int i=0;i<ps.length();i++){
            JSONObject pos=ps.getJSONObject(i);
            JSONObject cmd=new JSONObject();
            cmd.put("action","CLOSE");cmd.put("ticket",pos.optLong("ticket",0));
            boolean real="REAL".equalsIgnoreCase(api.accountInfo().optString("mode",""));cmd.put("selected_mode",real?"LIVE":"DEMO");cmd.put("live_enabled",real);
            if(pos.optLong("ticket",0)>0)api.trade(cmd);
          }
        }catch(Exception ignored){}
        return true;
      }
      if(locked)return true;
    }else{
      // Starting a fresh aggressive session gets a fresh high-water mark.
      if(state.getBool("aggPeakLock",false)){state.setBool("aggPeakLock",false);state.setDouble("aggPeakEq",equity);}
    }
    if(!aggressive&&state.getInt("dayTrades",0)>=MAX_TRADES_NORMAL)return true;
    return false;
  }

  /** Connected execution: signals are sent only after account/risk gates pass. */
  public void scan(boolean allowTrade){if(emergency)return;try{JSONObject ai=api.accountInfo();double eq=ai.optDouble("equity",ai.optDouble("balance",0));if(eq<=0||riskLocked(eq)){out.log("Entry blocked by daily risk/trade limit");return;}
    if(aggressive && eq-state.getDouble("dayEq",eq)>=100.0){out.log("AGGRESSIVE daily target reached — entries locked");return;}JSONArray open=api.positions();if(open.length()>=(aggressive?1:3)){out.log(aggressive?"AGGRESSIVE: existing position is already active — no second position allowed":"Entry blocked: simultaneous-position cap");return;}for(String sym:SYMBOLS){try{if(hasPosition(open,sym)){out.log(sym+": existing position — skip");continue;}if(!quality(sym)){continue;}List<StrategyEngine.Candle> h4=load(sym,"4h"),h1=load(sym,"1h"),m15=load(sym,"15m"),m5=load(sym,"5m");JSONObject price=api.price(sym);double bid=price.optDouble("bid"),ask=price.optDouble("ask");if(bid<=0||ask<=0)continue;StrategyEngine.Signal s=engine.evaluate(sym,h4,h1,m15,m5,bid,ask,aggressive);if(s.valid){out.signal(s);if(allowTrade&&!emergency)place(s,ai,price); } else if(allowTrade) out.log(sym+": no valid setup");}catch(Exception e){out.log(sym+": scan error "+e.getMessage());}}}catch(Exception e){out.log("Scan/account error: "+e.getMessage());}}
  private boolean hasPosition(JSONArray ps,String sym)throws Exception{for(int i=0;i<ps.length();i++)if(sym.equalsIgnoreCase(ps.getJSONObject(i).optString("symbol")))return true;return false;}
  private boolean quality(String sym)throws Exception{
    JSONObject p=api.price(sym); double bid=p.optDouble("bid"),ask=p.optDouble("ask"); if(bid<=0||ask<=0)return false;
    JSONObject sp=api.spec(sym); double point=sp.optDouble("point",sp.optDouble("tickSize",0)); if(point<=0)return false;
    double spread=(ask-bid)/point; if(spread>MAX_SPREAD_POINTS)return false;
    if(!sessionOK(p.optString("brokerTime","")))return false;
    List<StrategyEngine.Candle> m5=load(sym,"5m"); double a=StrategyEngine.atr(m5,14),px=m5.get(m5.size()-2).c; if(a<=0||px<=0)return false;
    double atrPct=a/px*100.0; if(atrPct<MIN_ATR_PCT||atrPct>MAX_ATR_PCT)return false; if((ask-bid)>MAX_SPREAD_ATR*a)return false;
    long last=state.getLong("entry:"+sym,0); if(last>0&&System.currentTimeMillis()-last<COOLDOWN_MIN*60000L)return false; return true;
  }
  private boolean sessionOK(String brokerTime){try{if(brokerTime==null||brokerTime.length()<13)return true;String x=brokerTime.replace('T',' ');int h=Integer.parseInt(x.substring(11,13));Date d=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.US).parse(x);int dow=d.getDay();if(dow==5&&h>=18)return false;return (h>=8&&h<12)||(h>=13&&h<20);}catch(Exception e){return true;}}
  private List<StrategyEngine.Candle> load(String sym,String tf)throws Exception{JSONArray a=api.candles(sym,tf,250);ArrayList<StrategyEngine.Candle> r=new ArrayList<>();for(int i=a.length()-1;i>=0;i--)r.add(new StrategyEngine.Candle(a.getJSONObject(i)));return r;}

  private double volumeForRisk(String sym,double entry,double sl,double equity,JSONObject price,JSONObject spec)throws Exception{
    double riskPct=aggressive?StrategyEngine.AGG_RISK:StrategyEngine.NORMAL_RISK;riskPct=Math.min(riskPct,StrategyEngine.MAX_TRADE_RISK);double riskMoney=equity*riskPct/100.0;double tickSize=spec.optDouble("tickSize",0),tickValue=price.optDouble("lossTickValue",0);double min=spec.optDouble("minVolume",0.01),max=spec.optDouble("maxVolume",100),step=spec.optDouble("volumeStep",min);if(tickSize<=0||tickValue<=0||riskMoney<=0||step<=0)return 0;double loss1=Math.abs(entry-sl)/tickSize*tickValue;if(loss1<=0)return 0;double raw=riskMoney/loss1;if(raw<min)return 0;double v=Math.min(max,Math.floor(raw/step)*step);if(v<min)return 0;return roundVolume(v,step);}
  private double roundVolume(double v,double step){int d=0;double x=step;while(x<1&&d<8){x*=10;d++;}return Double.parseDouble(String.format(Locale.US,"%."+d+"f",v));}
  private void place(StrategyEngine.Signal s,JSONObject ai,JSONObject price)throws Exception{
    JSONObject spec=api.spec(s.symbol);
    double volume=volumeForRisk(s.symbol,s.entry,s.sl,ai.optDouble("equity",ai.optDouble("balance",0)),price,spec);
    if(volume<=0){out.log(s.symbol+": risk sizing unavailable — trade not sent");return;}
    JSONObject t=new JSONObject();
    t.put("action","OPEN"); t.put("mode",aggressive?"AGGRESSIVE":"NORMAL");
    t.put("direction",s.dir>0?"BUY":"SELL"); t.put("symbol",s.symbol); t.put("volume",volume); t.put("sl",s.sl); t.put("tp",s.tp);
    boolean real="REAL".equalsIgnoreCase(ai.optString("mode",""));
    t.put("selected_mode",real?"LIVE":"DEMO"); t.put("live_enabled",real);
    JSONObject r=api.trade(t); state.setLong("entry:"+s.symbol,System.currentTimeMillis()); state.setInt("dayTrades",state.getInt("dayTrades",0)+1);
    out.log(s.symbol+": MT5 command "+r.optString("status","QUEUED")+" • "+volume+" lots");
  }
  private double roundPrice(double v,int d){double p=Math.pow(10,d);return Math.round(v*p)/p;}

  /** Synchronize/validate live positions. SL/TP changes are sent by higher-level approved commands. */
  public void manage(){
    try{
      JSONObject ai=api.accountInfo(); double eq=ai.optDouble("equity",ai.optDouble("balance",0));
      if(eq<=0 || riskLocked(eq)){out.log("RISK LOCK active — no new management commands issued");return;}
      JSONArray open=api.positions();
      out.log("MT5 position sync: "+open.length()+" open position(s)");
    }catch(Exception e){out.log("Position sync error: "+e.getMessage());}
  }

}
