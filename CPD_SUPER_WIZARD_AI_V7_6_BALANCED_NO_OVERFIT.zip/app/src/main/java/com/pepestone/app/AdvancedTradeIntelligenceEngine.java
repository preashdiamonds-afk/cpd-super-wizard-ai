package com.pepestone.app;

import java.util.*;

/** Non-blocking advanced evidence layer. It enriches decisions without turning every engine into a hard filter. */
public final class AdvancedTradeIntelligenceEngine {
  public static final class Evidence {
    public int structure, pattern, sr, momentum, liquidity, breakout, mtf, volatility;
    public int quality;
    public String summary;
    public final List<String> engines=new ArrayList<>();
  }
  private AdvancedTradeIntelligenceEngine(){}
  public static Evidence analyze(List<StrategyEngine.Candle> h4,List<StrategyEngine.Candle> h1,List<StrategyEngine.Candle> m15,List<StrategyEngine.Candle> m5,StrategyEngine.Signal s){
    Evidence e=new Evidence();
    if(s==null){e.summary="No trade signal supplied.";return e;}
    e.structure=s.confidence>=70?2:1; e.pattern=!"NONE".equalsIgnoreCase(s.pattern)?2:1;
    e.sr=!"NONE".equalsIgnoreCase(s.sr)?2:1; e.momentum=momentum(m15,s.dir)?2:1;
    e.liquidity=s.reason.contains("LIQUIDITY SWEEP 15/15")?2:1;
    e.breakout=s.breakout.contains("TRUE")?2:1; e.mtf=mtf(h4,h1,m15,m5,s.dir);
    double a=StrategyEngine.atr(m15,14), base=averageAtr(m15,14,50);
    double vr=base>0?a/base:1; e.volatility=vr>1.5?1:vr<0.65?1:2;
    int[] v={e.structure,e.pattern,e.sr,e.momentum,e.liquidity,e.breakout,e.mtf,e.volatility}; int sum=0;for(int x:v)sum+=x;
    e.quality=(int)Math.round(sum*100.0/(v.length*2));
    e.engines.add("Structure "+label(e.structure)); e.engines.add("Pattern "+label(e.pattern));
    e.engines.add("S/R "+label(e.sr)); e.engines.add("Momentum "+label(e.momentum));
    e.engines.add("Liquidity "+label(e.liquidity)); e.engines.add("Breakout "+label(e.breakout));
    e.engines.add("MTF "+label(e.mtf)); e.engines.add("Volatility "+label(e.volatility));
    e.summary="Advanced evidence quality "+e.quality+"/100 • non-blocking intelligence layer";
    return e;
  }
  private static String label(int x){return x>=2?"STRONG":"SUPPORTING";}
  private static boolean momentum(List<StrategyEngine.Candle> r,int d){if(r==null||r.size()<60)return false;double f=StrategyEngine.ema(r,20),s=StrategyEngine.ema(r,50),q=StrategyEngine.rsi(r,14);return d>0?f>s&&q>50:d<0&&f<s&&q<50;}
  private static int mtf(List<StrategyEngine.Candle> h4,List<StrategyEngine.Candle> h1,List<StrategyEngine.Candle> m15,List<StrategyEngine.Candle> m5,int d){int n=0;int[] ds={dir(h4),dir(h1),dir(m15),dir(m5)};for(int x:ds)if(x==d)n++;return n>=3?2:1;}
  private static int dir(List<StrategyEngine.Candle> r){if(r==null||r.size()<55)return 0;double e20=StrategyEngine.ema(r,20),e50=StrategyEngine.ema(r,50),c=r.get(r.size()-2).c;return c>e20&&e20>e50?1:c<e20&&e20<e50?-1:0;}
  private static double averageAtr(List<StrategyEngine.Candle> r,int p,int windows){if(r==null||r.size()<p+2)return 0;int end=r.size()-2,start=Math.max(p,end-windows+1),n=0;double sum=0;for(int i=start;i<=end;i++){StrategyEngine.Candle x=r.get(i),q=r.get(i-1);sum+=Math.max(x.h-x.l,Math.max(Math.abs(x.h-q.c),Math.abs(x.l-q.c)));n++;}return n>0?sum/n:0;}
}
