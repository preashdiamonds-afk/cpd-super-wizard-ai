package com.pepestone.app;

import android.graphics.Bitmap;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Lightweight on-device OCR used only to identify visible chart timeframe/symbol labels. */
public final class ChartOcrDetector {
  public static class Result { public String timeframe="UNKNOWN"; public String symbol="UNVERIFIED"; public String text=""; }
  private ChartOcrDetector() {}
  public static Result detect(Bitmap b){
    Result out=new Result(); if(b==null)return out;
    try{
      InputImage image=InputImage.fromBitmap(b,0);
      TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
      CountDownLatch latch=new CountDownLatch(1);
      recognizer.process(image).addOnSuccessListener(t->{out.text=t.getText()==null?"":t.getText();parse(out);latch.countDown();})
        .addOnFailureListener(e->latch.countDown());
      latch.await(8, TimeUnit.SECONDS); recognizer.close();
    }catch(Exception ignored){}
    return out;
  }
  private static void parse(Result r){
    String s=r.text.toUpperCase(Locale.US).replaceAll("\\s+"," ");
    String[] tfs={"M1","M2","M3","M5","M10","M15","M30","H1","H2","H4","H6","H8","D1","W1","MN1"};
    for(String tf:tfs){if(s.matches(".*(?<![A-Z0-9])"+tf+"(?![A-Z0-9]).*")){r.timeframe=tf;break;}}
    String[] syms={"EURUSD","GBPUSD","USDJPY","GBPJPY","AUDUSD","USDCAD","USDCHF","AUDJPY","AUDCAD","AUDCHF","XAUUSD","GOLD","BTCUSD","US30","NAS100"};
    for(String x:syms){if(s.contains(x)){r.symbol=x.equals("GOLD")?"XAUUSD":x;break;}}
  }
}
