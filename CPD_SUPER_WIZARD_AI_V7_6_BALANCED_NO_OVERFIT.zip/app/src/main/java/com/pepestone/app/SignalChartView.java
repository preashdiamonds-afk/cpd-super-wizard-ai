package com.pepestone.app;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.util.AttributeSet;
import java.util.*;

/**
 * C.P.D AI Setup Vision chart. It is an AI-generated visualization based on
 * the supplied signal levels/market data; it is not a broker screenshot.
 */
public class SignalChartView extends View {
  private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
  private boolean buy = true, has = false;
  private double entry, sl, tp, support, resistance;
  private String symbol = "EURUSD", timeframe = "M15";

  public SignalChartView(Context c){this(c,null);}
  public SignalChartView(Context c, AttributeSet a){ super(c,a); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }

  public void setSignal(StrategyEngine.Signal s){
    if(s==null){has=false;invalidate();return;}
    has=true; buy=s.dir>0; entry=s.entry; sl=s.sl; tp=s.tp; symbol=s.symbol; timeframe="M15";
    double r=Math.abs(entry-sl);
    support=buy?entry-r*0.95:entry+r*0.30;
    resistance=buy?entry+r*1.75:entry-r*1.75;
    invalidate();
  }

  public void setScanResult(CPDScannerEngine.ScanResult r){
    if(r==null || (!"BUY".equals(r.direction) && !"SELL".equals(r.direction))){has=false;invalidate();return;}
    has=true; buy="BUY".equals(r.direction); entry=parse(r.entry); sl=parse(r.sl); tp=parse(r.tp);
    support=r.supportLevel>0?r.supportLevel:(buy?entry-Math.abs(entry-sl):entry+Math.abs(entry-sl)*0.3);
    resistance=r.resistanceLevel>0?r.resistanceLevel:(buy?entry+Math.abs(entry-sl)*1.75:entry-Math.abs(entry-sl)*1.75);
    symbol=(r.symbol==null||r.symbol.trim().isEmpty())?"UNVERIFIED":r.symbol; timeframe="M15"; invalidate();
  }

  public void setManual(String sym, boolean isBuy,double e,double stop){
    has=true; symbol=sym; buy=isBuy; entry=e; sl=stop; double r=Math.abs(e-stop); tp=buy?e+r*2.6:e-r*2.6;
    support=buy?e-r*.95:e+r*.30; resistance=buy?e+r*1.75:e-r*1.75; invalidate();
  }

  public void clear(){has=false;invalidate();}

  public Bitmap exportBitmap(){
    Bitmap b=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);
    Canvas c=new Canvas(b); draw(c); return b;
  }

  @Override protected void onDraw(Canvas c){
    super.onDraw(c); int w=getWidth(),h=getHeight();
    p.setTypeface(Typeface.create("sans",Typeface.NORMAL));
    p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(2,10,24));c.drawRoundRect(0,0,w,h,22,22,p);
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(0,190,255));c.drawRoundRect(1,1,w-1,h-1,22,22,p);
    if(!has){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(145,155,170));p.setTextSize(14);c.drawText("AI SETUP VISION • waiting for validated signal",22,38,p);return;}

    float left=36,right=w-34,top=106,bottom=h-54;
    // Header matching the supplied CPD scanner visual.
    drawHeader(c,w);
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(Color.rgb(22,49,75));
    for(int i=0;i<7;i++){float y=top+(bottom-top)*i/7f;c.drawLine(left,y,right,y,p);}
    for(int i=0;i<10;i++){float x=left+(right-left)*i/10f;c.drawLine(x,top,x,bottom,p);}

    double hi=Math.max(Math.max(Math.max(entry,tp),resistance),support), lo=Math.min(Math.min(Math.min(entry,sl),resistance),support);
    if(!(hi>lo)){hi=entry+1;lo=entry-1;} double pad=(hi-lo)*0.12+1e-9;hi+=pad;lo-=pad;
    Random rnd=new Random((symbol+timeframe+(buy?"B":"S")).hashCode());
    p.setStyle(Paint.Style.FILL);
    for(int i=0;i<42;i++){
      double progress=i/41.0;
      double start=buy?entry-Math.abs(entry-sl)*0.65:entry+Math.abs(entry-sl)*0.65;
      double end=buy?entry+Math.abs(tp-entry)*0.72:entry-Math.abs(tp-entry)*0.72;
      double base=start+(end-start)*progress;
      double noise=(rnd.nextDouble()-.5)*Math.abs(entry-sl)*0.62;
      double o=base+noise, close=base+(rnd.nextDouble()-.5)*Math.abs(entry-sl)*0.42;
      double hh=Math.max(o,close)+rnd.nextDouble()*Math.abs(entry-sl)*0.22;
      double ll=Math.min(o,close)-rnd.nextDouble()*Math.abs(entry-sl)*0.22;
      float x=left+10+(right-left-20)*i/41f; float bw=Math.max(4,(right-left)/115f);
      float yo=map(o,lo,hi,top,bottom),yc=map(close,lo,hi,top,bottom),yh=map(hh,lo,hi,top,bottom),yl=map(ll,lo,hi,top,bottom);
      p.setColor(close>=o?Color.rgb(0,238,143):Color.rgb(255,65,82));p.setStrokeWidth(2);c.drawLine(x,yh,x,yl,p);
      c.drawRect(x-bw/2,Math.min(yo,yc),x+bw/2,Math.max(yo,yc)+1,p);
    }

    line(c,"Resistance",resistance,Color.rgb(255,65,75),left,right,lo,hi,top,bottom,false);
    line(c,"Support",support,Color.rgb(0,210,255),left,right,lo,hi,top,bottom,false);
    line(c,"Entry "+fmt(entry),entry,Color.rgb(0,185,255),left,right,lo,hi,top,bottom,true);
    line(c,"SL  "+fmt(sl),sl,Color.rgb(255,65,75),left,right,lo,hi,top,bottom,true);
    line(c,"TP "+fmt(tp),tp,Color.rgb(0,235,145),left,right,lo,hi,top,bottom,true);

    // Direction arrow, matching the reference visual.
    float ax=right-230, ay=map(entry,lo,hi,top,bottom)-35; float tx=right-135, ty=map(tp,lo,hi,top,bottom)+15;
    p.setColor(Color.rgb(0,245,135));p.setStrokeWidth(7);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);
    c.drawLine(ax,ay,tx,ty,p);float ang=(float)Math.atan2(ty-ay,tx-ax);float len=28;
    c.drawLine(tx,ty,tx-len*(float)Math.cos(ang-.55),ty-len*(float)Math.sin(ang-.55),p);
    c.drawLine(tx,ty,tx-len*(float)Math.cos(ang+.55),ty-len*(float)Math.sin(ang+.55),p);p.setStrokeCap(Paint.Cap.BUTT);

    p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(145,155,170));p.setTextSize(10);c.drawText("AI SETUP VISION • generated from validated CPD analysis",left,h-18,p);
  }

  private void drawHeader(Canvas c,int w){
    p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(22);c.drawText(symbol,58,45,p);
    p.setColor(Color.rgb(190,205,225));p.setTextSize(18);c.drawText(timeframe,225,45,p);
    String[] tabs={"M5","M15","H1","H4"};float x=w-360;
    for(String tab:tabs){boolean active=tab.equals(timeframe);p.setStyle(Paint.Style.FILL);p.setColor(active?Color.rgb(12,102,200):Color.rgb(10,30,54));c.drawRoundRect(x,17,x+92,70,13,13,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(active?3:1);p.setColor(active?Color.rgb(0,210,255):Color.rgb(28,66,102));c.drawRoundRect(x,17,x+92,70,13,13,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextSize(18);c.drawText(tab,x+28,51,p);x+=104;}
    p.setColor(Color.rgb(15,75,112));p.setStrokeWidth(2);c.drawLine(36,82,w-34,82,p);
  }

  private float map(double v,double lo,double hi,float top,float bottom){return (float)(bottom-(v-lo)/(hi-lo)*(bottom-top));}
  private void line(Canvas c,String label,double v,int color,float l,float r,double lo,double hi,float top,float bottom,boolean boxLabel){
    float y=map(v,lo,hi,top,bottom);p.setColor(color);p.setStrokeWidth(boxLabel?3:4);p.setStyle(Paint.Style.STROKE);c.drawLine(l,y,r,y,p);
    p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(boxLabel?15:14);
    if(boxLabel){float tw=p.measureText(label);p.setColor(Color.argb(225,4,13,25));c.drawRoundRect(r-tw-24,y-22,r,y+17,11,11,p);p.setColor(color);c.drawText(label,r-tw-12,y+5,p);}
    else{p.setColor(color);c.drawText(label,l+38,y-9,p);}
  }
  private String fmt(double x){return x>0?String.format(Locale.US,"%.4f",x):"—";}
  private double parse(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
}
