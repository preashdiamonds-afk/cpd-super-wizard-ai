package com.pepestone.app;

import android.content.Context;
import org.json.JSONObject;

/** Small persistent hand-off between the background scanner and the dashboard. */
public class ScannerStateStore {
  private final android.content.SharedPreferences p;
  public ScannerStateStore(Context c){p=c.getApplicationContext().getSharedPreferences("cpd_scanner_state",Context.MODE_PRIVATE);}
  public void status(String text){p.edit().putString("status",text).putLong("statusAt",System.currentTimeMillis()).apply();}
  public String status(){return p.getString("status","Scanner starting…");}
  public long statusAt(){return p.getLong("statusAt",0);}
  public void pending(StrategyEngine.Signal s,long publishAt){
    p.edit().putString("signal",encode(s).toString()).putLong("detectedAt",System.currentTimeMillis()).putLong("publishAt",publishAt).putBoolean("published",false).apply();
  }
  public void published(StrategyEngine.Signal s){
    p.edit().putString("signal",encode(s).toString()).putLong("publishedAt",System.currentTimeMillis()).putBoolean("published",true).apply();
  }
  public void pendingIfNeeded(StrategyEngine.Signal s,String key,String status){ String old=p.getString("cloudKey",""); if(!key.equals(old)){ p.edit().putString("cloudKey",key).putString("signal",encode(s).toString()).putBoolean("published","PUBLISHED".equals(status)).putLong("publishAt",System.currentTimeMillis()+120000L).apply(); } else if("PUBLISHED".equals(status)){ p.edit().putBoolean("published",true).apply(); } }
  public boolean hasSignal(){return p.contains("signal");}
  public boolean isPublished(){return p.getBoolean("published",false);}
  public long publishAt(){return p.getLong("publishAt",0);}
  public StrategyEngine.Signal signal(){
    try{return decode(new JSONObject(p.getString("signal","{}")));}catch(Exception e){return null;}
  }
  public void clear(){p.edit().clear().apply();}
  private JSONObject encode(StrategyEngine.Signal s){
    JSONObject j=new JSONObject();try{j.put("symbol",s.symbol);j.put("dir",s.dir);j.put("confidence",s.confidence);j.put("entry",s.entry);j.put("sl",s.sl);j.put("tp",s.tp);j.put("tp1",s.tp1);j.put("tp2",s.tp2);j.put("tp3",s.tp3);j.put("tp4",s.tp4);j.put("atr",s.atr);j.put("reason",s.reason);j.put("pattern",s.pattern);j.put("patternQuality",s.patternQuality);j.put("sr",s.sr);j.put("srQuality",s.srQuality);j.put("breakout",s.breakout);j.put("tvConfirmed",s.tvConfirmed);j.put("newsRisk",s.newsRisk);j.put("vixRisk",s.vixRisk);j.put("vix",s.vix);j.put("marketRegime",s.marketRegime);j.put("strategyProfile",s.strategyProfile);}catch(Exception ignored){}return j;
  }
  private StrategyEngine.Signal decode(JSONObject j){
    StrategyEngine.Signal s=new StrategyEngine.Signal(j.optString("symbol"));s.valid=true;s.dir=j.optInt("dir");s.confidence=j.optDouble("confidence");s.entry=j.optDouble("entry");s.sl=j.optDouble("sl");s.tp=j.optDouble("tp");s.tp1=j.optDouble("tp1");s.tp2=j.optDouble("tp2");s.tp3=j.optDouble("tp3");s.tp4=j.optDouble("tp4");s.atr=j.optDouble("atr");s.reason=j.optString("reason");s.pattern=j.optString("pattern","NONE");s.patternQuality=j.optString("patternQuality","NONE");s.sr=j.optString("sr","NONE");s.srQuality=j.optString("srQuality","NONE");s.breakout=j.optString("breakout","NONE");s.tvConfirmed=j.optBoolean("tvConfirmed");s.newsRisk=j.optBoolean("newsRisk");s.vixRisk=j.optBoolean("vixRisk");s.vix=j.optDouble("vix");s.marketRegime=j.optString("marketRegime","UNKNOWN");s.strategyProfile=j.optString("strategyProfile","DEFENSIVE");return s;
  }
}
