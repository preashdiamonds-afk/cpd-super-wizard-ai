package com.pepestone.app;

import java.util.*;
import org.json.*;
import android.graphics.Bitmap;

/** Evidence-first scanner. An attached image must pass a chart-validity gate before live analysis is reported. */
public final class CPDScannerEngine {
  public static class ScanResult {
    public String symbol="UNVERIFIED", direction="WAIT", entry="—", sl="—", tp="—", tp1="—", tp2="—", reason="";
    public String trend="NEUTRAL", volatility="UNKNOWN", pattern="NONE", supportResistance="NONE", momentum="UNKNOWN", marketState="WAIT";
    public double confidence=0, atrPercent=0; public String[] timeframes={"WAIT","WAIT","WAIT","WAIT"};
    public boolean screenshotReceived, chartAccepted; public String chartStatus="NO IMAGE";
    public String advancedEvidence="", analysisMode="SINGLE-TIMEFRAME", detectedTimeframe="UNKNOWN", higherBias="NEUTRAL", m15Analysis="N/A", m5Direction="N/A";
    public double supportLevel=0, resistanceLevel=0;
  }

  public static ScanResult scan(String symbol, PublicMarketDataClient data, boolean screenshotReceived){
    return scan(symbol,data,screenshotReceived,null,null);
  }
  public static ScanResult scan(String symbol, PublicMarketDataClient data, boolean screenshotReceived, Bitmap screenshot){
    Map<String,Bitmap> m=new LinkedHashMap<>(); if(screenshot!=null)m.put("UNKNOWN",screenshot); return scan(symbol,data,screenshotReceived,m);
  }
  /** Evidence-first scan. The uploaded timeframe map controls which market timeframes are allowed into the analysis. */
  public static ScanResult scan(String symbol, PublicMarketDataClient data, boolean screenshotReceived, Map<String,Bitmap> charts){
    ScanResult out=new ScanResult(); out.screenshotReceived=screenshotReceived;
    LinkedHashMap<String,Bitmap> byTf=new LinkedHashMap<>();
    if(charts!=null){
      for(Map.Entry<String,Bitmap> e:charts.entrySet()){
        String tf=e.getKey()==null?"UNKNOWN":e.getKey().toUpperCase(Locale.US);
        if(e.getValue()!=null)byTf.put(tf,e.getValue());
      }
    }
    if(screenshotReceived){
      if(byTf.isEmpty()){out.marketState="INVALID IMAGE";out.reason="NO VALID TRADING CHART DETECTED. CPD will not invent a signal.";return out;}
      for(Bitmap b:byTf.values()){
        ChartVisualContext.Report vr=ChartVisualContext.inspect(b);
        if(!vr.likelyChart){out.chartAccepted=false;out.marketState="INVALID IMAGE";out.chartStatus="NO VALID TRADING CHART DETECTED";out.reason="One or more uploaded images did not pass the trading-chart validity gate. CPD stopped instead of inventing missing market evidence.";return out;}
      }
      out.chartAccepted=true;
      out.chartStatus=byTf.size()==1?"SINGLE CHART ACCEPTED":"MULTI-TIMEFRAME CHARTS ACCEPTED • "+byTf.keySet();
    } else { out.chartAccepted=true; out.chartStatus="LIVE MARKET MODE • no screenshot attached"; }

    if(screenshotReceived){
      String detectedSym="UNVERIFIED";
      for(Bitmap b:byTf.values()){ChartOcrDetector.Result o=ChartOcrDetector.detect(b); if(o.symbol!=null&&!o.symbol.equals("UNVERIFIED")){detectedSym=o.symbol;break;}}
      out.symbol=detectedSym;
    } else out.symbol=symbol;

    try{
      if(screenshotReceived && byTf.size()==1){
        String tf=byTf.keySet().iterator().next();
        if("UNKNOWN".equals(tf)){out.marketState="INSUFFICIENT CHART DATA";out.reason="The chart is valid, but its timeframe could not be reliably read. CPD will not assume M5, M15, H1 or H4.";out.detectedTimeframe="UNKNOWN";return out;}
        out.analysisMode="SINGLE-TIMEFRAME"; out.detectedTimeframe=tf;
        return single(symbol,data,out,tf);
      }
      if(screenshotReceived && byTf.size()>1){
        out.analysisMode="MULTI-TIMEFRAME";
        return multi(symbol,data,out,byTf);
      }
      // No screenshot: full live hierarchy remains available for the normal scanner.
      out.analysisMode="LIVE MULTI-TIMEFRAME";
      List<StrategyEngine.Candle> h4=toList(data.candles(symbol,"4h",250)),h1=toList(data.candles(symbol,"1h",250)),m15=toList(data.candles(symbol,"15m",160)),m5=toList(data.candles(symbol,"5m",160));
      return evaluateFour(symbol,data,out,h4,h1,m15,m5,true);
    }catch(Exception ex){out.marketState="DATA ERROR";out.reason="Scanner could not complete safely: "+ex.getMessage();return out;}
  }

  private static ScanResult single(String symbol, PublicMarketDataClient data, ScanResult out, String tf) throws Exception{
    String apiTf=tf.toLowerCase(Locale.US);
    List<StrategyEngine.Candle> c=toList(data.candles(symbol,apiTf,220));
    if(c.size()<60){out.marketState="INSUFFICIENT DATA";out.reason="Insufficient "+tf+" market data. CPD will WAIT rather than use hidden timeframes.";return out;}
    JSONObject px=data.price(symbol); double bid=px.optDouble("bid"),ask=px.optDouble("ask");
    String tr=trend(c); out.trend=tr; out.timeframes[idx(tf)]=tr; out.momentum=momentumText(c);
    double a=StrategyEngine.atr(c,14), last=c.get(c.size()-2).c;
    out.atrPercent=a>0&&last>0?a/last*100:0; out.volatility=out.atrPercent>0.20?"HIGH":out.atrPercent>0.08?"NORMAL":"LOW";
    int n=Math.min(70,c.size()-2); double sup=Double.POSITIVE_INFINITY,res=Double.NEGATIVE_INFINITY;
    for(int i=c.size()-1-n;i<c.size()-1;i++){StrategyEngine.Candle x=c.get(i);sup=Math.min(sup,x.l);res=Math.max(res,x.h);}
    out.supportLevel=sup; out.resistanceLevel=res;

    int dir="BULLISH".equals(tr)?1:"BEARISH".equals(tr)?-1:0;
    if(dir==0){out.marketState="WAIT";out.reason="Single-timeframe "+tf+" structure is neutral. CPD will not force BUY/SELL.";return out;}

    StringBuilder pn=new StringBuilder(),pq=new StringBuilder(),sn=new StringBuilder(),sq=new StringBuilder();
    int pd=StrategyEngine.pattern(c,pn,pq,a);
    int srScore=StrategyEngine.sr(c,dir,sn,sq,a);
    String bq=StrategyEngine.breakoutQuality(c,dir,a);
    out.pattern=pn+" • "+pq;
    out.supportResistance=sn+" • "+sq;

    boolean momentumAligned=(dir>0&&"BULLISH".equals(out.momentum))||(dir<0&&"BEARISH".equals(out.momentum));
    boolean patternAligned=pd==dir;
    boolean strongSR=srScore>=2;
    boolean trueBreakout=bq.contains("TRUE BREAKOUT");
    boolean falseBreakout=bq.contains("FALSE BREAKOUT");
    double entry=dir>0?(ask>0?ask:last):(bid>0?bid:last);
    double stop=dir>0?sup-a*0.20:res+a*0.20;
    double risk=Math.abs(entry-stop);
    if(risk<=0||!Double.isFinite(risk)||risk>3.5*a){
      out.marketState="WAIT";out.reason="Invalid or excessive risk distance on the uploaded "+tf+" timeframe.";return out;
    }

    // A single chart is allowed to produce a signal, but it must still show
    // enough internal evidence. No hidden timeframe is consulted.
    int score=50;
    if(momentumAligned)score+=15;
    if(patternAligned)score+=15;
    if(strongSR)score+=10;
    else if(srScore==1)score+=5;
    if(trueBreakout)score+=5;
    if(falseBreakout)score-=10;
    if((dir>0&&last<sup)||(dir<0&&last>res))score-=5;
    int positiveEvidence=(momentumAligned?1:0)+(patternAligned?1:0)+(strongSR?1:0)+(srScore==1?1:0)+(trueBreakout?1:0);
    if(score<65 || positiveEvidence<2){
      out.marketState="WAIT — SINGLE-TIMEFRAME BALANCED QUALITY GATE";
      out.confidence=Math.max(0,Math.min(95,score));
      out.reason="SINGLE-TIMEFRAME ONLY • "+tf+" was uploaded. No other timeframe was used. "+
        "Trend="+tr+" • Momentum="+out.momentum+" • Pattern="+out.pattern+" • S/R="+out.supportResistance+
        " • Breakout="+bq+". CPD requires at least two independent positive pieces of evidence before BUY/SELL.";
      return out;
    }

    double t1=dir>0?entry+1.5*risk:entry-1.5*risk;
    double t2=dir>0?entry+2.5*risk:entry-2.5*risk;
    out.direction=dir>0?"BUY":"SELL";out.entry=fmt(entry);out.sl=fmt(stop);out.tp=fmt(t1);out.tp1=fmt(t1);out.tp2=fmt(t2);
    out.marketState="VALIDATED SINGLE-TIMEFRAME";out.confidence=Math.min(95,score);
    out.reason="SINGLE-TIMEFRAME ANALYSIS ONLY • "+tf+" was uploaded. No other timeframe was used for confirmation.\n\n"+
      "Trend: "+tr+" • Momentum: "+out.momentum+" • Pattern: "+out.pattern+" • S/R: "+out.supportResistance+
      " • Breakout: "+bq+"\nEntry/SL/TP are derived from the uploaded timeframe's market context and its corresponding live candle feed.";
    return out;
  }

  private static ScanResult multi(String symbol, PublicMarketDataClient data, ScanResult out, LinkedHashMap<String,Bitmap> byTf) throws Exception{
    // Only timeframes actually uploaded are loaded. Missing charts stay MISSING and are never inferred.
    // Two screenshots claiming the same timeframe are ambiguous; do not silently overwrite one.
    if(byTf.size()>1){
      // The UI normally de-duplicates by OCR key. This guard remains for callers that pass a map directly.
      for(String tf:byTf.keySet()){
        if(!Arrays.asList("H4","H1","M15","M5").contains(tf)){
          out.marketState="WAIT — UNSUPPORTED TIMEFRAME";
          out.reason="Uploaded timeframe "+tf+" is not part of the CPD 4H → 1H → 15M → 5M hierarchy.";
          return out;
        }
      }
    }
    List<StrategyEngine.Candle> h4=byTf.containsKey("H4")?toList(data.candles(symbol,"4h",250)):Collections.emptyList();
    List<StrategyEngine.Candle> h1=byTf.containsKey("H1")?toList(data.candles(symbol,"1h",250)):Collections.emptyList();
    List<StrategyEngine.Candle> m15=byTf.containsKey("M15")?toList(data.candles(symbol,"15m",160)):Collections.emptyList();
    List<StrategyEngine.Candle> m5=byTf.containsKey("M5")?toList(data.candles(symbol,"5m",160)):Collections.emptyList();
    if(h4.size()<30&&byTf.containsKey("H4")||h1.size()<30&&byTf.containsKey("H1")||m15.size()<30&&byTf.containsKey("M15")||m5.size()<30&&byTf.containsKey("M5")){out.marketState="INSUFFICIENT DATA";out.reason="One uploaded timeframe does not have enough corresponding market data. CPD will WAIT instead of borrowing a different timeframe.";return out;}
    out.timeframes[0]=byTf.containsKey("H4")?trend(h4):"NOT UPLOADED";out.timeframes[1]=byTf.containsKey("H1")?trend(h1):"NOT UPLOADED";out.timeframes[2]=byTf.containsKey("M15")?trend(m15):"NOT UPLOADED";out.timeframes[3]=byTf.containsKey("M5")?trend(m5):"NOT UPLOADED";
    int hb=0, hc=0;if(byTf.containsKey("H4")){hb+=dir(out.timeframes[0]);hc++;}if(byTf.containsKey("H1")){hb+=dir(out.timeframes[1]);hc++;}out.higherBias=hb>0&&hb==hc?"BUY":hb<0&&-hb==hc?"SELL":hb==0?"NEUTRAL":"MIXED";
    if(byTf.containsKey("M15"))out.m15Analysis="15M: "+out.timeframes[2]+" • setup/structure confirmation"; else out.m15Analysis="15M: NOT UPLOADED";
    String execTf=byTf.containsKey("M5")?"M5":byTf.containsKey("M15")?"M15":byTf.containsKey("H1")?"H1":"H4";
    out.m5Direction=byTf.containsKey("M5")?out.timeframes[3]:"NOT UPLOADED";
    if(byTf.containsKey("H4")&&byTf.containsKey("H1")&&byTf.containsKey("M15")&&byTf.containsKey("M5")){
      if(!("BUY".equals(out.higherBias)&&"BULLISH".equals(out.timeframes[2])&&"BULLISH".equals(out.timeframes[3])) && !("SELL".equals(out.higherBias)&&"BEARISH".equals(out.timeframes[2])&&"BEARISH".equals(out.timeframes[3]))){
        out.direction="WAIT";out.marketState="WAIT — MULTI-TIMEFRAME CONFLICT";out.confidence=0;out.reason="4H + 1H establish the major bias, 15M must confirm the setup, and 5M is the final execution timeframe. The uploaded charts conflict or lack confirmation, so CPD will not force a trade.";return out;
      }
    }
    // For complete hierarchy, the existing strategy engine is allowed to calculate final levels from all four uploaded timeframes.
    if(h4.size()>=30&&h1.size()>=30&&m15.size()>=30&&m5.size()>=30){
      return evaluateFour(symbol,data,out,h4,h1,m15,m5,true);
    }
    // Partial multi-timeframe set: analyze the lowest uploaded timeframe but explicitly report the missing hierarchy.
    out.analysisMode="PARTIAL MULTI-TIMEFRAME";List<StrategyEngine.Candle> c=execTf.equals("M5")?m5:execTf.equals("M15")?m15:execTf.equals("H1")?h1:h4;return singleFromCandles(symbol,data,out,execTf,c);
  }

  private static ScanResult evaluateFour(String symbol,PublicMarketDataClient data,ScanResult out,List<StrategyEngine.Candle> h4,List<StrategyEngine.Candle> h1,List<StrategyEngine.Candle> m15,List<StrategyEngine.Candle> m5,boolean all)throws Exception{
    JSONObject px=data.price(symbol);double bid=px.optDouble("bid"),ask=px.optDouble("ask");out.timeframes[0]=trend(h4);out.timeframes[1]=trend(h1);out.timeframes[2]=trend(m15);out.timeframes[3]=trend(m5);out.trend=out.timeframes[0]+" / "+out.timeframes[1]+" / "+out.timeframes[2]+" / "+out.timeframes[3];out.higherBias=("BULLISH".equals(out.timeframes[0])&&"BULLISH".equals(out.timeframes[1]))?"BUY":("BEARISH".equals(out.timeframes[0])&&"BEARISH".equals(out.timeframes[1]))?"SELL":"NEUTRAL";out.m15Analysis="15M: "+out.timeframes[2]+" • setup and confirmation";out.m5Direction=out.timeframes[3];
    StrategyEngine.Signal s=new StrategyEngine().evaluate(symbol,h4,h1,m15,m5,bid,ask,false);if(!s.valid){out.direction="WAIT";out.marketState="WAIT";out.reason="4H/1H/15M/5M data is present, but the final strategy validation did not confirm a trade. CPD will WAIT instead of forcing a signal.";return out;}
    AdvancedTradeIntelligenceEngine.Evidence e=AdvancedTradeIntelligenceEngine.analyze(h4,h1,m15,m5,s);EnsembleIntelligence.Result er=EnsembleIntelligence.assess(h4,h1,m15,m5,s);out.direction=s.dir>0?"BUY":"SELL";out.entry=fmt(s.entry);out.sl=fmt(s.sl);out.tp=fmt(s.tp);out.tp1=fmt(s.tp1);out.tp2=fmt(s.tp2);out.marketState="VALIDATED MULTI-TIMEFRAME";out.pattern=s.pattern+" • "+s.patternQuality;out.supportResistance=s.sr+" • "+s.srQuality;out.momentum=out.timeframes[2];double a5=StrategyEngine.atr(m5,14),last=m5.get(m5.size()-2).c;out.atrPercent=a5>0&&last>0?a5/last*100:0;out.volatility=out.atrPercent>0.20?"HIGH":out.atrPercent>0.08?"NORMAL":"LOW";out.confidence=Math.min(100,(s.confidence/95.0)*100.0*0.75+er.agreement*0.25);out.advancedEvidence=e.summary+"\n"+join(e.engines);out.reason="4H + 1H = major trend • 15M = setup confirmation • 5M = final execution.\n\n"+s.reason+"\n\nMULTI-ENGINE: "+er.summary+"\n"+join(er.engines);return out;
  }

  private static ScanResult singleFromCandles(String symbol,PublicMarketDataClient data,ScanResult out,String tf,List<StrategyEngine.Candle> c)throws Exception{
    String tr=trend(c);out.trend=tr;out.timeframes[idx(tf)]=tr;out.momentum=momentumText(c);double a=StrategyEngine.atr(c,14),last=c.get(c.size()-2).c;out.atrPercent=a>0&&last>0?a/last*100:0;out.volatility=out.atrPercent>0.20?"HIGH":out.atrPercent>0.08?"NORMAL":"LOW";int n=Math.min(60,c.size()-2);double sup=Double.POSITIVE_INFINITY,res=Double.NEGATIVE_INFINITY;for(int i=c.size()-1-n;i<c.size()-1;i++){StrategyEngine.Candle x=c.get(i);sup=Math.min(sup,x.l);res=Math.max(res,x.h);}out.supportLevel=sup;out.resistanceLevel=res;out.supportResistance=String.format(Locale.US,"Support %.5f • Resistance %.5f",sup,res);int d=dir(tr);if(d==0){out.direction="WAIT";out.marketState="WAIT";out.reason="The lowest uploaded timeframe is neutral. CPD will not force a trade while higher-timeframe evidence is incomplete.";return out;}JSONObject px=data.price(symbol);double bid=px.optDouble("bid"),ask=px.optDouble("ask");double entry=d>0?(ask>0?ask:last):(bid>0?bid:last),stop=d>0?sup-a*.15:res+a*.15,risk=Math.abs(entry-stop);out.direction=d>0?"BUY":"SELL";out.entry=fmt(entry);out.sl=fmt(stop);out.tp=fmt(d>0?entry+1.5*risk:entry-1.5*risk);out.marketState="PARTIAL MULTI-TIMEFRAME";out.confidence=55;out.reason="Available charts were combined, but the preferred 4H → 1H → 15M → 5M hierarchy is incomplete. CPD uses only the uploaded timeframes and lowers confidence rather than inventing missing confirmation.";return out;
  }

  private static int dir(String s){return "BULLISH".equals(s)?1:"BEARISH".equals(s)?-1:0;}
  private static int idx(String tf){if("H4".equals(tf))return 0;if("H1".equals(tf))return 1;if("M15".equals(tf))return 2;if("M5".equals(tf))return 3;return 0;}
  private static String momentumText(List<StrategyEngine.Candle> c){if(c.size()<55)return"INSUFFICIENT";double e=StrategyEngine.ema(c,20),s=StrategyEngine.ema(c,50),r=StrategyEngine.rsi(c,14);return e>s&&r>50?"BULLISH":e<s&&r<50?"BEARISH":"MIXED";}
  private static double singleConfidence(List<StrategyEngine.Candle> c,int d,int pd){double e=StrategyEngine.ema(c,20),s=StrategyEngine.ema(c,50),r=StrategyEngine.rsi(c,14);double x=50;if((d>0&&e>s&&r>50)||(d<0&&e<s&&r<50))x+=20;if(pd==d)x+=15;if((d>0&&c.get(c.size()-2).c>e)||(d<0&&c.get(c.size()-2).c<e))x+=10;return Math.min(95,x);}
  private static String join(List<String>x){StringBuilder b=new StringBuilder();for(String s:x){if(b.length()>0)b.append(" • ");b.append(s);}return b.toString();}
  private static List<StrategyEngine.Candle> toList(JSONArray a){List<StrategyEngine.Candle>r=new ArrayList<>();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null)r.add(new StrategyEngine.Candle(a.optJSONObject(i)));return r;}
  private static String trend(List<StrategyEngine.Candle>r){if(r==null||r.size()<55)return"INSUFFICIENT";double e=StrategyEngine.ema(r,20),s=StrategyEngine.ema(r,50),c=r.get(r.size()-2).c;return c>e&&e>s?"BULLISH":c<e&&e<s?"BEARISH":"NEUTRAL";}
  private static String fmt(double x){return x>0?String.format(Locale.US,"%.5f",x):"—";}
}
