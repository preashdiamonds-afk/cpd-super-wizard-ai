# Pre-build corrections

This package applies critical corrections before the next build:

1. Scanner no longer labels a user-selected pair as if it was detected from the uploaded image. Screenshot mode reports the symbol as UNVERIFIED unless a future OCR layer verifies it.
2. Chart validity uses a more conservative visual gate so ordinary images are less likely to be accepted as charts, without adding a large stack of trade filters.
3. MT5 passwords are not stored in Android SharedPreferences. The MT5 terminal/EA remains responsible for broker authentication.
4. CPD Bridge refuses to start with the default bridge secret.
5. Bridge execution requires a fresh MT5 heartbeat (10 seconds or less), preventing orders from being accepted against stale account state.
6. Queued bridge commands older than 15 seconds are discarded rather than executed late after a reconnect.
7. The TradingController documentation now matches its actual connected-execution role.

These are safety/correctness corrections, not extra trading filters.
