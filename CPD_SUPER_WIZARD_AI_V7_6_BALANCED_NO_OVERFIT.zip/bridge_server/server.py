import os, json, time, uuid, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

TOKEN=os.environ.get('CPD_BRIDGE_TOKEN','')
if not TOKEN or TOKEN=='CHANGE_ME_CPD_DEMO_TOKEN':
    raise RuntimeError('CPD_BRIDGE_TOKEN must be configured; refusing to start with a default bridge secret.')
PORT=int(os.environ.get('PORT','10000'))
STATE={'accounts':{},'commands':{},'results':{}}
STATE_FILE=os.environ.get('CPD_STATE_FILE','/tmp/cpd_bridge_state.json')
LOCK=threading.RLock()

def load_state():
    global STATE
    try:
        with open(STATE_FILE,'r',encoding='utf-8') as f: STATE=json.load(f)
    except Exception: pass

def save_state():
    try:
        tmp=STATE_FILE+'.tmp'
        with open(tmp,'w',encoding='utf-8') as f: json.dump(STATE,f,separators=(',',':'))
        os.replace(tmp,STATE_FILE)
    except Exception: pass

load_state()

def key(login,server): return f'{login}|{server}'
def auth(h): return h.get('Authorization','') == 'Bearer '+TOKEN

def send(h,code,obj,ctype='application/json'):
    raw=obj if isinstance(obj,bytes) else (obj if isinstance(obj,str) else json.dumps(obj,separators=(',',':')))
    if isinstance(raw,str): raw=raw.encode()
    h.send_response(code); h.send_header('Content-Type',ctype); h.send_header('Access-Control-Allow-Origin','*'); h.send_header('Access-Control-Allow-Headers','Content-Type, Authorization'); h.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS'); h.end_headers(); h.wfile.write(raw)

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_OPTIONS(self): send(self,204,b'')
    def read(self):
        n=int(self.headers.get('Content-Length','0')); return self.rfile.read(n) if n else b''
    def postjson(self):
        try:return json.loads(self.read() or b'{}')
        except:return {}
    def do_GET(self):
        u=urlparse(self.path); p=u.path; q=parse_qs(u.query)
        if p=='/health': return send(self,200,{'ok':True,'service':'CPD MT5 Bridge','version':'7.5','time':int(time.time())})
        if p=='/mt5/poll':
            if not auth(self.headers): return send(self,401,{'error':'unauthorized'})
            k=key(q.get('login',[''])[0],q.get('server',[''])[0])
            with LOCK:
                cmds=STATE['commands'].get(k,[]); STATE['commands'][k]=[]; save_state()
            lines=[]
            now=int(time.time())
            for c in cmds:
                if now-int(c.get('created',now)) > 15:
                    continue
                lines.append('|'.join([c['id'],c['action'],c['mode'],c.get('direction','BUY'),c.get('symbol',''),str(c.get('volume',0)),str(c.get('sl',0)),str(c.get('tp',0)),str(c.get('ticket',0))]))
            return send(self,200,'\n'.join(lines),'text/plain')
        return send(self,404,{'error':'not found'})
    def do_POST(self):
        u=urlparse(self.path); p=u.path
        if p.startswith('/mt5/'):
            if not auth(self.headers): return send(self,401,{'error':'unauthorized'})
            data=self.postjson(); k=key(str(data.get('login','')),str(data.get('server','')))
            if p=='/mt5/heartbeat':
                acc=data.get('account',{}); acc['updated']=int(time.time()); acc['mode']=str(acc.get('mode','')).upper();
                with LOCK:
                    STATE['accounts'][k]={'account':acc,'positions':data.get('positions',[]),'updated':int(time.time())}; save_state()
                return send(self,200,{'ok':True,'mode':acc.get('mode','UNKNOWN')})
            if p=='/mt5/snapshot':
                with LOCK:
                    a=STATE['accounts'].setdefault(k,{}); a.update({x:data.get(x) for x in ('account','positions','ticks','specs') if x in data}); a['updated']=int(time.time()); save_state()
                return send(self,200,{'ok':True})
            if p=='/mt5/report':
                with LOCK:
                    STATE['results'][data.get('id','')]=data; save_state()
                return send(self,200,{'ok':True})
        if not auth(self.headers): return send(self,401,{'error':'unauthorized'})
        data=self.postjson(); login=str(data.get('login','')); server=str(data.get('server','')); k=key(login,server); a=STATE['accounts'].get(k,{})
        if p=='/account':
            acc=a.get('account',a); acc=dict(acc) if isinstance(acc,dict) else {}; acc['bridge_updated']=a.get('updated',0); return send(self,200,acc)
        if p=='/performance':
            acc=a.get('account',{}); return send(self,200,acc.get('stats',{}))
        if p=='/positions': return send(self,200,{'data':a.get('positions',[])})
        if p=='/candles': return send(self,200,{'data':a.get('candles',{}).get(str(data.get('symbol'))+'|'+str(data.get('timeframe')),[])})
        if p=='/tick': return send(self,200,a.get('ticks',{}).get(str(data.get('symbol')),{}))
        if p=='/spec': return send(self,200,a.get('specs',{}).get(str(data.get('symbol')),{}))
        if p=='/trade':
            # The terminal heartbeat is authoritative. The app must explicitly select the same mode.
            actual=str(a.get('account',{}).get('mode',a.get('mode',''))).upper()
            selected=str(data.get('selected_mode','')).upper()
            live_enabled=bool(data.get('live_enabled',False))
            heartbeat_age=int(time.time())-int(a.get('updated',0) or 0)
            if heartbeat_age > 10:
                return send(self,503,{'error':'MT5_HEARTBEAT_STALE','heartbeat_age_seconds':heartbeat_age})
            if selected not in ('DEMO','LIVE') or actual not in ('DEMO','REAL'):
                return send(self,403,{'error':'ACCOUNT_MODE_NOT_VERIFIED','actual_mode':actual,'selected_mode':selected})
            if selected=='DEMO' and actual!='DEMO':
                return send(self,403,{'error':'REAL_ACCOUNT_REJECTED_FOR_DEMO_MODE'})
            if selected=='LIVE' and (actual!='REAL' or not live_enabled):
                return send(self,403,{'error':'LIVE_ACCOUNT_REJECTED_OR_NOT_ENABLED'})
            action=str(data.get('action','OPEN')).upper()
            if action not in ('OPEN','MODIFY','CLOSE'):
                return send(self,400,{'error':'UNSUPPORTED_ACTION'})
            symbol=str(data.get('symbol','')).strip().upper()
            if action=='OPEN' and not symbol:
                return send(self,400,{'error':'SYMBOL_REQUIRED'})
            cmd={'id':uuid.uuid4().hex,'action':action,'mode':str(data.get('mode','NORMAL')).upper(),'direction':str(data.get('direction','BUY')).upper(),'symbol':symbol,'volume':float(data.get('volume',0.01)),'sl':float(data.get('sl',0)),'tp':float(data.get('tp',0)),'ticket':int(data.get('ticket',0)),'created':int(time.time())}
            with LOCK:
                STATE['commands'].setdefault(k,[]).append(cmd); save_state()
            return send(self,202,{'accepted':True,'command_id':cmd['id'],'status':'QUEUED','account_mode':actual})
        return send(self,404,{'error':'not found'})

ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
