# C.P.D SUPER WIZARD AI V7.6 — Scanner Corrections

This build is based on V7.4 CHART SCANNER SINGLE/MULTI.

## Corrections
1. Single-chart scans stay strictly on the uploaded timeframe and now use stronger internal evidence:
   - trend + momentum
   - true/false pattern
   - strong/weak support or resistance
   - breakout quality
   - risk-distance gate
2. Chart symbol OCR is now used to prevent analyzing the wrong market. If uploaded charts show conflicting symbols, the upload is rejected.
3. Duplicate timeframe uploads are rejected instead of silently overwriting a chart.
4. Build workflow no longer depends on an unrelated V7.2 ZIP. It can build the project directly or extract the current V7.4 ZIP.
5. App / MT5 bridge version metadata updated to V7.6.
6. Aggressive mode now has a persistent 5% high-water equity lock:
   - the reference is the highest equity reached during the aggressive session, not starting balance;
   - reaching a 5% drawdown from that peak locks aggressive entries and attempts to close the active aggressive position;
   - aggressive mode is capped at one simultaneous position.

## Important
This is still a trading system, not a guarantee of profitable trades. Test on DEMO first and verify broker symbol specifications, spreads, minimum volume, and SL/TP distance rules before enabling live execution.
