# C.P.D SUPER WIZARD AI V7.3 Rebuild

## Rebuild scope
- Preserves Normal Auto, Aggressive Auto, Signal Center, CPD Scanner, C.P.D Academy, Performance, MT5/Exness account center, bridge and EA.
- Adds direct bottom navigation for Account and Academy so they are no longer hidden behind Settings.
- Keeps Normal and Aggressive engines visually separated.
- Keeps LIVE execution gated by actual MT5 account mode and the existing bridge safety checks.
- Scanner UI now explicitly labels symbol confirmation and the chart-validity gate.
- Home account dashboard uses the active account mode instead of always saying DEMO.
- Version bumped to 7.3 rebuild command center.

## Important
The app still does not invent a broker connection. Real execution requires a running MT5 terminal/EA and the CPD bridge. Actual Exness execution must be tested with the user's own MT5 terminal before live trading is considered verified.

## V7.4 Chart Scanner Upgrade
- Single-chart mode: only the detected uploaded timeframe is analyzed; CPD does not load other timeframes for confirmation.
- Multi-chart mode: uploaded charts are OCR-checked for visible timeframe labels and organized as 4H → 1H → 15M → 5M.
- 4H + 1H establish higher-timeframe bias; 15M confirms the setup; 5M is the final execution timeframe when all four are present.
- Missing/conflicting timeframes produce WAIT or reduced-confidence partial analysis instead of invented confirmation.
- On-device OCR is used only to read visible timeframe/symbol labels; it does not manufacture prices.
