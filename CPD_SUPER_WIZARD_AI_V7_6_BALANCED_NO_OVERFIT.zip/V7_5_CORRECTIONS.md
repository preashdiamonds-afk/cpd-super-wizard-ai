# Superseded by V7.6

See V7_6_BALANCED_NO_OVERFIT.md for the current scanner logic.
