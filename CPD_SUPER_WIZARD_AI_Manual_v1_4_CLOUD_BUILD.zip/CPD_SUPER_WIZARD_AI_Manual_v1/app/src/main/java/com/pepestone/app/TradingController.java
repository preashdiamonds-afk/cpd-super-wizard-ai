package com.pepestone.app;

import android.content.Context;
import org.json.*;
import java.text.*;import java.util.*;

/**
 * Shared trading engine used by the screen and the Android foreground service.
 * It contains the mobile execution gates, monetary-risk sizing and Normal 2R-6R ladder.
 */
public class TradingController {
  public interface Logger { void log(String s); void signal(StrategyEngine.Signal s); }
  public static final String[] SYMBOLS={"EURUSD","XAUUSD","AUDJPY","AUDCAD","AUDCHF"};
  private final Context ctx; private final Logger out; private final BrokerApiClient api; private final TradeStateStore state; private final StrategyEngine engine=new StrategyEngine();
  private boolean aggressive; private boolean emergency;
  private static final int MAX_TRADES_NORMAL=5; private static final double MAX_DAILY_NORMAL=10.0, MAX_DAILY_AGG=5.0;
  private static final double MAX_SPREAD_POINTS=35.0, MAX_SPREAD_ATR=0.20, MIN_ATR_PCT=0.003, MAX_ATR_PCT=2.0;
  private static final int COOLDOWN_MIN=15;

  public TradingController(Context c,Logger l,BrokerApiClient a,TradeStateStore s){ctx=c.getApplicationContext();out=l;api=a;state=s;}
  public void setAggressive(boolean v){aggressive=v;} public void setEmergency(boolean v){emergency=v;}
  private String dayKey(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
  private void ensureDay(double equity){String d=dayKey();if(!d.equals(state.getLong("day",0)+"")){state.setLong("day",Long.parseLong(d));state.setDouble("dayEq",equity);state.setInt("dayTrades",0);state.setBool("dayLock",false);}}
  private boolean riskLocked(double equity){ensureDay(equity);if(state.getBool("dayLock",false))return true;double start=state.getDouble("dayEq",equity);double dd=start>0?Math.max(0,(start-equity)/start*100):0;double max=aggressive?MAX_DAILY_AGG:MAX_DAILY_NORMAL;if(dd>=max){state.setBool("dayLock",true);out.log("RISK LOCK: daily equity drawdown "+String.format(Locale.US,"%.2f",dd)+"% reached");return true;}if(!aggressive&&state.getInt("dayTrades",0)>=MAX_TRADES_NORMAL)return true;return false;}

  public void scan(boolean allowTrade){if(emergency)return;try{JSONObject ai=api.accountInfo();double eq=ai.optDouble("equity",ai.optDouble("balance",0));if(eq<=0||riskLocked(eq)){out.log("Entry blocked by daily risk/trade limit");return;}
    if(aggressive && eq-state.getDouble("dayEq",eq)>=100.0){out.log("AGGRESSIVE daily target reached — entries locked");return;}JSONArray open=api.positions();if(open.length()>=(aggressive?1:3)){out.log("Entry blocked: simultaneous-position cap");return;}for(String sym:SYMBOLS){try{if(hasPosition(open,sym)){out.log(sym+": existing position — skip");continue;}if(!quality(sym)){continue;}List<StrategyEngine.Candle> h4=load(sym,"4h"),h1=load(sym,"1h"),m15=load(sym,"15m"),m5=load(sym,"5m");JSONObject price=api.price(sym);double bid=price.optDouble("bid"),ask=price.optDouble("ask");if(bid<=0||ask<=0)continue;StrategyEngine.Signal s=engine.evaluate(sym,h4,h1,m15,m5,bid,ask,aggressive);if(s.valid){out.signal(s);if(allowTrade&&!emergency)place(s,ai,price); } else if(allowTrade) out.log(sym+": no valid setup");}catch(Exception e){out.log(sym+": scan error "+e.getMessage());}}}catch(Exception e){out.log("Scan/account error: "+e.getMessage());}}
  private boolean hasPosition(JSONArray ps,String sym)throws Exception{for(int i=0;i<ps.length();i++)if(sym.equalsIgnoreCase(ps.getJSONObject(i).optString("symbol")))return true;return false;}
  private boolean quality(String sym)throws Exception{
    JSONObject p=api.price(sym); double bid=p.optDouble("bid"),ask=p.optDouble("ask"); if(bid<=0||ask<=0)return false;
    JSONObject sp=api.spec(sym); double point=sp.optDouble("point",sp.optDouble("tickSize",0)); if(point<=0)return false;
    double spread=(ask-bid)/point; if(spread>MAX_SPREAD_POINTS)return false;
    if(!sessionOK(p.optString("brokerTime","")))return false;
    List<StrategyEngine.Candle> m5=load(sym,"5m"); double a=StrategyEngine.atr(m5,14),px=m5.get(m5.size()-2).c; if(a<=0||px<=0)return false;
    double atrPct=a/px*100.0; if(atrPct<MIN_ATR_PCT||atrPct>MAX_ATR_PCT)return false; if((ask-bid)>MAX_SPREAD_ATR*a)return false;
    long last=state.getLong("entry:"+sym,0); if(last>0&&System.currentTimeMillis()-last<COOLDOWN_MIN*60000L)return false; return true;
  }
  private boolean sessionOK(String brokerTime){try{if(brokerTime==null||brokerTime.length()<13)return true;String x=brokerTime.replace('T',' ');int h=Integer.parseInt(x.substring(11,13));Date d=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.US).parse(x);int dow=d.getDay();if(dow==5&&h>=18)return false;return (h>=8&&h<12)||(h>=13&&h<20);}catch(Exception e){return true;}}
  private List<StrategyEngine.Candle> load(String sym,String tf)throws Exception{JSONArray a=api.candles(sym,tf,250);ArrayList<StrategyEngine.Candle> r=new ArrayList<>();for(int i=a.length()-1;i>=0;i--)r.add(new StrategyEngine.Candle(a.getJSONObject(i)));return r;}

  private double volumeForRisk(String sym,double entry,double sl,double equity,JSONObject price,JSONObject spec)throws Exception{
    double riskPct=aggressive?StrategyEngine.AGG_RISK:StrategyEngine.NORMAL_RISK;riskPct=Math.min(riskPct,StrategyEngine.MAX_TRADE_RISK);double riskMoney=equity*riskPct/100.0;double tickSize=spec.optDouble("tickSize",0),tickValue=price.optDouble("lossTickValue",0);double min=spec.optDouble("minVolume",0.01),max=spec.optDouble("maxVolume",100),step=spec.optDouble("volumeStep",min);if(tickSize<=0||tickValue<=0||riskMoney<=0||step<=0)return 0;double loss1=Math.abs(entry-sl)/tickSize*tickValue;if(loss1<=0)return 0;double raw=riskMoney/loss1;if(raw<min)return 0;double v=Math.min(max,Math.floor(raw/step)*step);if(v<min)return 0;return roundVolume(v,step);}
  private double roundVolume(double v,double step){int d=0;double x=step;while(x<1&&d<8){x*=10;d++;}return Double.parseDouble(String.format(Locale.US,"%."+d+"f",v));}
  private void place(StrategyEngine.Signal s,JSONObject ai,JSONObject price)throws Exception{
    JSONObject spec=api.spec(s.symbol);double eq=ai.optDouble("equity",ai.optDouble("balance",0));double vol=volumeForRisk(s.symbol,s.entry,s.sl,eq,price,spec);if(vol<=0){out.log(s.symbol+": blocked — minimum lot would exceed risk cap");return;}
    int digits=spec.optInt("digits",price.optInt("digits",5));double minDist=Math.max(spec.optDouble("stopsLevel",0),spec.optDouble("freezeLevel",0))*spec.optDouble("point",spec.optDouble("tickSize",0));if(minDist>0&&Math.abs(s.entry-s.sl)<minDist)s.sl=s.dir>0?s.entry-minDist:s.entry+minDist;
    JSONObject o=new JSONObject();o.put("actionType",s.dir>0?"ORDER_TYPE_BUY":"ORDER_TYPE_SELL");o.put("symbol",s.symbol);o.put("volume",vol);o.put("stopLoss",roundPrice(s.sl,digits));o.put("takeProfit",0.0);o.put("magic",aggressive?26091806:26091805);o.put("clientId","PS"+System.currentTimeMillis());
    JSONObject r=api.trade(o);String rc=r.optString("stringCode","");if(!rc.contains("DONE")&&!rc.contains("PLACED")){out.log("ORDER REJECTED "+s.symbol+" "+rc);return;}state.setInt("dayTrades",state.getInt("dayTrades",0)+1);state.setLong("entry:"+s.symbol,System.currentTimeMillis());out.log("DEMO ORDER "+s.symbol+" "+(s.dir>0?"BUY":"SELL")+" "+vol+" lots, risk "+(aggressive?"0.75":"1.00")+"% → "+rc);
    String id=r.optString("positionId",r.optString("orderId",""));if(!id.isEmpty())state.setDouble("r:"+id,Math.abs(s.entry-s.sl));
  }
  private double roundPrice(double v,int d){double p=Math.pow(10,d);return Math.round(v*p)/p;}

  public void manage(){
    try{
      JSONArray ps=api.positions();
      for(int i=0;i<ps.length();i++){
        JSONObject p=ps.getJSONObject(i); String sym=p.optString("symbol"); long magic=p.optLong("magic",0);
        if(magic!=(aggressive?26091806:26091805)) continue;
        String id=p.optString("id",p.optString("positionId")); if(id.isEmpty()) continue;
        double open=p.optDouble("openPrice"), cur=p.optDouble("currentPrice");
        String type=p.optString("type").toUpperCase(Locale.US); boolean buy=type.contains("BUY") || (!type.contains("SELL") && p.optInt("type",0)==0);
        if(cur<=0){JSONObject pr=api.price(sym);cur=buy?pr.optDouble("bid"):pr.optDouble("ask");}
        double risk=state.getDouble("r:"+id,0);
        if(risk<=0){double sl=p.optDouble("stopLoss");risk=Math.abs(open-sl);if(risk>0)state.setDouble("r:"+id,risk);}
        if(risk<=0)continue;
        double rr=buy?(cur-open)/risk:(open-cur)/risk;
        if(aggressive)continue;
        if(rr>=6){JSONObject c=new JSONObject();c.put("actionType","POSITION_CLOSE_ID");c.put("positionId",id);api.trade(c);out.log(sym+": Normal ladder closed at 6R");state.clearPosition(id);continue;}
        double[] levels={2,3,4,5};
        for(int n=0;n<4;n++){
          if(rr<levels[n])continue;
          String pk="p:"+id+":"+(n+1),sk="s:"+id+":"+(n+1);
          if(!state.getBool(pk,false)){
            double vol=p.optDouble("volume"); JSONObject sp=api.spec(sym); double min=sp.optDouble("minVolume",0.01),step=sp.optDouble("volumeStep",min);
            double part=roundVolume(vol*0.20,step);
            if(part>0&&part<vol&&vol-part>=min){JSONObject q=new JSONObject();q.put("actionType","POSITION_PARTIAL");q.put("positionId",id);q.put("volume",part);api.trade(q);out.log(sym+": TP"+(n+1)+" partial 20%");}
            state.setBool(pk,true);
          }
          double protect=n==0?0:levels[n-1];
          if(!state.getBool(sk,false)){
            double ns=buy?open+protect*risk:open-protect*risk; JSONObject q=new JSONObject();q.put("actionType","POSITION_MODIFY");q.put("positionId",id);q.put("stopLoss",ns);api.trade(q);state.setBool(sk,true);out.log(sym+": protective SL moved to "+protect+"R");
          }
        }
      }
    }catch(Exception e){out.log("Management error: "+e.getMessage());}
  }

}
