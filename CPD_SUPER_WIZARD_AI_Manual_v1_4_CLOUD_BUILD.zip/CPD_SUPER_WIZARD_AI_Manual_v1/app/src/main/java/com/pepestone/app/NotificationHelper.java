package com.pepestone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;

/** Phone notifications for strong setups, including when C.P.D SUPER WIZARD AI is not on screen. */
public class NotificationHelper {
  public static final String CHANNEL_ID="pepestone_signals";
  private final Context ctx;
  public NotificationHelper(Context c){ctx=c.getApplicationContext();createChannel();}
  private void createChannel(){
    if(Build.VERSION.SDK_INT>=26){
      NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
      NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"C.P.D SUPER WIZARD AI Trading Signals",NotificationManager.IMPORTANCE_HIGH);
      ch.setDescription("Strong C.P.D SUPER WIZARD AI setup alerts");
      nm.createNotificationChannel(ch);
    }
  }

  public void show(String title, String body){
    if(Build.VERSION.SDK_INT>=33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
    Intent i=new Intent(ctx,MainActivity.class);
    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi=PendingIntent.getActivity(ctx,(int)(System.currentTimeMillis()%100000),i,
      PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
    Notification n=new Notification.Builder(ctx,CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setContentTitle(title).setContentText(body)
      .setStyle(new Notification.BigTextStyle().bigText(body))
      .setPriority(Notification.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build();
    ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),n);
  }

  public void notifySignal(StrategyEngine.Signal s){
    if(Build.VERSION.SDK_INT>=33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
    String side=s.dir>0?"BUY":"SELL";
    String title="C.P.D SUPER WIZARD AI — "+side+" setup";
    String body=String.format(java.util.Locale.US,"%s %s | Confidence %.0f%% | Entry %.5f | SL %.5f | TP 6R %.5f",
      s.symbol,side,s.confidence,s.entry,s.sl,s.tp);
    Intent i=new Intent(ctx,MainActivity.class);
    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi=PendingIntent.getActivity(ctx,(int)(System.currentTimeMillis()%100000),i,
      PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
    Notification n=new Notification.Builder(ctx,CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setContentTitle(title).setContentText(body)
      .setStyle(new Notification.BigTextStyle().bigText(body+"\n"+s.reason))
      .setPriority(Notification.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build();
    ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),n);
  }
}
