package com.pepestone.app;

import android.app.*;import android.content.*;import android.os.*;import java.util.concurrent.*;

/** Foreground worker. Manual mode scans for strong setups and sends phone notifications; Auto mode may execute only when the approved broker adapter supports trading. */
public class TradingService extends Service {
  private ScheduledExecutorService exec; private ExnessMt5Client api; private TradeStateStore state; private TradingController controller; private volatile boolean running; private NotificationHelper notifications;
  @Override public void onCreate(){super.onCreate();notifications=new NotificationHelper(this);createChannel();startForeground(7001,notification("C.P.D SUPER WIZARD AI monitoring active"));}
  @Override public int onStartCommand(Intent intent,int flags,int startId){startWorker();return START_STICKY;}
  private void startWorker(){
    if(running)return; running=true;
    SecureStore secure=new SecureStore(this); state=new TradeStateStore(this);
    String key=secure.get("exnessAccount","");String base=secure.get("exnessServer","");String bridge=secure.get("bridgeUrl","");String token=secure.get("bridgeToken","");
    if(key.isEmpty()||base.isEmpty()||bridge.isEmpty()){android.util.Log.e("C.P.D SUPER WIZARD AI","Exness MT5 connector not configured");stopSelf();return;}
    api=new ExnessMt5Client();api.configure(key,base,bridge,token);
    controller=new TradingController(this,new TradingController.Logger(){
      public void log(String s){android.util.Log.i("C.P.D SUPER WIZARD AI",s);}
      public void signal(StrategyEngine.Signal s){notifications.notifySignal(s);android.util.Log.i("C.P.D SUPER WIZARD AI","SIGNAL "+s.symbol+" "+s.dir+" "+s.confidence);}
    },api,state);
    controller.setAggressive("1".equals(secure.get("aggressive","0")));
    exec=Executors.newSingleThreadScheduledExecutor();
    exec.scheduleAtFixedRate(()->{try{boolean auto=state.getBool("autoOn",false);controller.manage();controller.scan(auto);}catch(Exception e){android.util.Log.e("C.P.D SUPER WIZARD AI","worker",e);}},2,20,TimeUnit.SECONDS);
  }
  private Notification notification(String text){return new Notification.Builder(this,"pepestone").setContentTitle("C.P.D SUPER WIZARD AI").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_manage).setOngoing(true).build();}
  private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);n.createNotificationChannel(new NotificationChannel("pepestone","C.P.D SUPER WIZARD AI Automation",NotificationManager.IMPORTANCE_LOW));}}
  @Override public void onDestroy(){running=false;if(exec!=null)exec.shutdownNow();super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}