package com.pepestone.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * C.P.D SUPER WIZARD AI — Manual Mobile Trading v1.
 * No broker credentials, API keys, MT5 bridge, or automatic orders.
 * The user prepares and records trades on the phone and can receive local alerts.
 */
public class MainActivity extends Activity {
    EditText symbol, entry, stopLoss, takeProfit, notes;
    Spinner direction;
    TextView signal, activityLog, modeStatus, autoStatus;
    Button savePlan, clearPlan, alertButton, manualModeButton, automaticModeButton;
    LinearLayout welcomeScreen, mainScreen;
    NotificationHelper notifications;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        notifications = new NotificationHelper(this);
        bind();

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4001);
        }

        enterSystem();
        log("Manual mode loaded and active.");
        log("Automatic mode is visible but locked. It cannot place trades in this version.");

        findViewById(R.id.enterSystem).setOnClickListener(v -> {
            welcomeScreen.setVisibility(View.GONE);
            mainScreen.setVisibility(View.VISIBLE);
            log("Trading dashboard opened.");
        });

        savePlan.setOnClickListener(v -> saveTradePlan());
        clearPlan.setOnClickListener(v -> clearForm());
        alertButton.setOnClickListener(v -> sendManualAlert());

        manualModeButton.setOnClickListener(v -> activateManualMode());
        automaticModeButton.setOnClickListener(v -> showAutomaticLocked());
    }

    private void bind() {
        welcomeScreen = findViewById(R.id.welcomeScreen);
        mainScreen = findViewById(R.id.mainScreen);
        symbol = findViewById(R.id.symbol);
        entry = findViewById(R.id.entry);
        stopLoss = findViewById(R.id.stopLoss);
        takeProfit = findViewById(R.id.takeProfit);
        notes = findViewById(R.id.notes);
        direction = findViewById(R.id.direction);
        signal = findViewById(R.id.signal);
        activityLog = findViewById(R.id.activityLog);
        modeStatus = findViewById(R.id.modeStatus);
        autoStatus = findViewById(R.id.autoStatus);
        manualModeButton = findViewById(R.id.manualModeButton);
        automaticModeButton = findViewById(R.id.automaticModeButton);
        savePlan = findViewById(R.id.savePlan);
        clearPlan = findViewById(R.id.clearPlan);
        alertButton = findViewById(R.id.alertButton);
    }

    private void enterSystem() {
        welcomeScreen.setVisibility(View.VISIBLE);
        mainScreen.setVisibility(View.GONE);
        activateManualMode();
    }

    private void activateManualMode() {
        modeStatus.setText("● MANUAL MODE • ACTIVE");
        autoStatus.setText("MANUAL MODE • ACTIVE");
        autoStatus.setTextColor(0xFF7EE787);
        manualModeButton.setText("MANUAL MODE ✓");
        automaticModeButton.setText("AUTOMATIC MODE 🔒");
        log("Manual mode active. Automatic trading remains locked.");
    }

    private void showAutomaticLocked() {
        autoStatus.setText("AUTOMATIC MODE • LOCKED / COMING LATER");
        autoStatus.setTextColor(0xFFFFD166);
        Toast.makeText(this, "Automatic mode is added but locked for now. No trades can be placed automatically.", Toast.LENGTH_LONG).show();
        log("Automatic mode selected, but it is locked and cannot trade yet.");
        activateManualMode();
    }

    private void saveTradePlan() {
        String s = symbol.getText().toString().trim().toUpperCase(Locale.US);
        String e = entry.getText().toString().trim();
        String sl = stopLoss.getText().toString().trim();
        String tp = takeProfit.getText().toString().trim();
        String d = direction.getSelectedItem().toString();
        if (s.isEmpty() || e.isEmpty() || sl.isEmpty() || tp.isEmpty()) {
            toast("Enter symbol, entry, stop loss and take profit.");
            return;
        }
        String text = d + " • " + s + "\nEntry: " + e + "   SL: " + sl + "   TP: " + tp;
        signal.setText(text + (notes.getText().toString().trim().isEmpty() ? "" : "\nNote: " + notes.getText().toString().trim()));
        log("Trade plan saved: " + d + " " + s + " @ " + e + ".");
        toast("Manual trade plan saved on this phone.");
    }

    private void sendManualAlert() {
        String s = symbol.getText().toString().trim().toUpperCase(Locale.US);
        String d = direction.getSelectedItem().toString();
        if (s.isEmpty()) { toast("Enter a symbol first."); return; }
        String message = "C.P.D MANUAL ALERT\n" + d + " " + s + "\nCheck your chart before entering a trade.";
        try { notifications.show("C.P.D Manual Alert", message); } catch (Exception ignored) {}
        log("Local alert sent: " + d + " " + s + ".");
        toast("Manual alert sent.");
    }

    private void clearForm() {
        symbol.setText(""); entry.setText(""); stopLoss.setText(""); takeProfit.setText(""); notes.setText("");
        signal.setText("No trade plan prepared yet.");
        log("Trade plan cleared.");
    }

    private void log(String s) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        activityLog.append("[" + t + "] " + s + "\n");
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
