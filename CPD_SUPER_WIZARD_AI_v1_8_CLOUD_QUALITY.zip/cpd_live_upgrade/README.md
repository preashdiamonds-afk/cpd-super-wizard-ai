# C.P.D SUPER WIZARD AI — V1.8 CLOUD QUALITY EDITION

**Manual execution only.** The app scans and publishes rule-based signals; it never places Exness/MT5 orders.

## What is new
- Diamond + gold luxury mobile interface.
- Spoken welcome: “Welcome Captain Preash. Super Wizard AI is scanning the market for good setups.”
- Cloud signal state stored in `cloud/signals.json`, so signals/history can be viewed after the phone reconnects.
- Cloud scanner designed for phone-off operation using scheduled GitHub Actions.
- Twelve Data FX feed. Free Basic currently lists real-time forex market data and 800 API credits/day.
- Four-symbol quality scan every 15 minutes to stay within the free-tier budget: EUR/USD, GBP/USD, USD/JPY, XAU/USD.
- Quality filter requires HTF alignment, M15 structure/BOS, liquidity sweep/reclaim, displacement, M5 trigger and at least 85/95 confluence before publishing.
- Signal state tracks INCOMING, PUBLISHED, TP1–TP4 and SL/final outcomes.

## Cloud setup
1. Create a free Twelve Data account and obtain an API key.
2. In GitHub repository **Settings → Secrets and variables → Actions**, create `TWELVE_DATA_API_KEY`. Never paste the key into source code or chat.
3. In GitHub **Settings → Actions → General**, allow Actions to have read/write repository contents if the workflow is prevented from committing `cloud/signals.json`.
4. Run **C.P.D Cloud Market Scanner** manually once to test it.
5. The scheduled scan then runs every 15 minutes.

## Important limitations
- A phone cannot execute a scanner while it is powered off. The cloud workflow is what makes phone-off scanning possible.
- GitHub Actions is a scheduled cloud worker, not a broker-grade 24/7 trading server; runs can be delayed or disabled.
- Twelve Data prices can differ from Exness quotes. Always verify the entry, spread and levels in Exness MT5 before copying a signal.
- The 85/95 value is a confluence score, not an 85% probability of winning. No algorithm can guarantee accurate or profitable signals.
- Economic-calendar/news filtering is not claimed as live in this edition; do not represent it as such.
