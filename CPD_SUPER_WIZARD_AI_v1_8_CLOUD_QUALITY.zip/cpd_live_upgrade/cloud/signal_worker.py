import json, math, os, statistics, time
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen

API_KEY = os.environ.get('TWELVE_DATA_API_KEY','').strip()
SYMBOLS = ['EUR/USD','GBP/USD','USD/JPY','XAU/USD']
OUT = os.path.join(os.path.dirname(__file__), 'signals.json')

if not API_KEY:
    raise SystemExit('TWELVE_DATA_API_KEY secret is required')

def get_json(url):
    req=Request(url, headers={'User-Agent':'CPD-SUPER-WIZARD-AI/1.8'})
    with urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode('utf-8'))

def candles(symbol, interval, size):
    q=urlencode({'symbol':symbol,'interval':interval,'outputsize':size,'apikey':API_KEY,'format':'JSON','timezone':'UTC'})
    d=get_json('https://api.twelvedata.com/time_series?'+q)
    if d.get('status') == 'error': raise RuntimeError(d.get('message','Twelve Data error'))
    rows=[]
    for x in reversed(d.get('values',[])):
        rows.append({'t':x['datetime'],'o':float(x['open']),'h':float(x['high']),'l':float(x['low']),'c':float(x['close'])})
    return rows

def aggregate(rows, minutes):
    out=[]; cur=None; bucket=None
    for x in rows:
        try: ts=int(datetime.fromisoformat(x['t'].replace('Z','+00:00')).timestamp())
        except: continue
        b=(ts//(minutes*60))*(minutes*60)
        if bucket != b:
            if cur: out.append(cur)
            bucket=b; cur={'t':datetime.fromtimestamp(b,timezone.utc).isoformat(),'o':x['o'],'h':x['h'],'l':x['l'],'c':x['c']}
        else:
            cur['h']=max(cur['h'],x['h']); cur['l']=min(cur['l'],x['l']); cur['c']=x['c']
    if cur: out.append(cur)
    return out

def ema(vals, n):
    if len(vals)<n: return None
    k=2/(n+1); e=sum(vals[:n])/n
    for v in vals[n:]: e=v*k+e*(1-k)
    return e

def atr(rows,n=14):
    if len(rows)<n+1:return None
    trs=[]
    for i in range(1,len(rows)):
        x,p=rows[i],rows[i-1]
        trs.append(max(x['h']-x['l'],abs(x['h']-p['c']),abs(x['l']-p['c'])))
    return sum(trs[-n:])/n

def score_symbol(symbol):
    h1=candles(symbol,'1h',500)
    m5=candles(symbol,'5min',500)
    m15=aggregate(m5,15); h4=aggregate(h1,240)
    if len(h4)<210 or len(h1)<210 or len(m15)<80 or len(m5)<60:
        return {'symbol':symbol,'valid':False,'status':'insufficient data'}
    close_h1=[x['c'] for x in h1]; close_h4=[x['c'] for x in h4]
    e50h1=ema(close_h1,50); e200h1=ema(close_h1,200); e50h4=ema(close_h4,50); e200h4=ema(close_h4,200)
    last=m5[-1]['c']; a=atr(m15,14) or atr(m5,14) or 0
    if not a or a<=0:return {'symbol':symbol,'valid':False,'status':'no ATR'}
    bullish_htf=e50h1>e200h1 and e50h4>e200h4
    bearish_htf=e50h1<e200h1 and e50h4<e200h4
    recent=m15[-8:]
    highs=[x['h'] for x in m15[-25:-2]]; lows=[x['l'] for x in m15[-25:-2]]
    prior_high=max(highs); prior_low=min(lows)
    x=m15[-2]
    body=abs(x['c']-x['o']); rng=max(x['h']-x['l'],1e-9)
    displacement=body>=0.65*a and body/rng>=0.60
    bull_sweep=x['l']<prior_low and x['c']>prior_low and (x['c']-x['l'])/rng>=0.60
    bear_sweep=x['h']>prior_high and x['c']<prior_high and (x['h']-x['c'])/rng>=0.60
    structure_bull=m15[-1]['c']>max(z['h'] for z in m15[-8:-1])
    structure_bear=m15[-1]['c']<min(z['l'] for z in m15[-8:-1])
    m5prev=m5[-2]; m5last=m5[-1]
    trigger_bull=m5last['c']>m5prev['h']
    trigger_bear=m5last['c']<m5prev['l']
    # Pattern quality
    pprev=m15[-3]
    bull_eng=pprev['c']<pprev['o'] and x['c']>x['o'] and x['c']>=pprev['o'] and x['o']<=pprev['c']
    bear_eng=pprev['c']>pprev['o'] and x['c']<x['o'] and x['o']>=pprev['c'] and x['c']<=pprev['o']
    hammer=(min(x['o'],x['c'])-x['l'])>2*body and (x['h']-max(x['o'],x['c']))<body
    shooting=(x['h']-max(x['o'],x['c']))>2*body and (min(x['o'],x['c'])-x['l'])<body
    pattern_bull=bull_eng or hammer; pattern_bear=bear_eng or shooting
    # S/R proximity and reaction strength
    pivots=[]
    for i in range(3,len(m15)-3):
        z=m15[i]
        if z['h']>=max(q['h'] for q in m15[i-3:i+4]): pivots.append(('R',z['h']))
        if z['l']<=min(q['l'] for q in m15[i-3:i+4]): pivots.append(('S',z['l']))
    def sr_strength(side, price):
        candidates=[v for typ,v in pivots if typ==side and abs(v-price)<=1.5*a]
        if not candidates:return 0
        near=min(abs(v-price) for v in candidates); touches=sum(1 for typ,v in pivots if typ==side and abs(v-price)<=1.5*a)
        return min(10,5+min(5,touches-1)) if near<=0.75*a else 5
    sr_bull=sr_strength('S',last); sr_bear=sr_strength('R',last)
    mom=(m15[-1]['c']-m15[-6]['c'])/a
    score_b=20*(1 if bullish_htf else 0)+20*(1 if structure_bull else 0)+15*(1 if bull_sweep else 0)+15*(1 if displacement and x['c']>x['o'] else 0)+5*(1 if mom>0.5 else 0)+10*(1 if pattern_bull else 0)+sr_bull
    score_s=20*(1 if bearish_htf else 0)+20*(1 if structure_bear else 0)+15*(1 if bear_sweep else 0)+15*(1 if displacement and x['c']<x['o'] else 0)+5*(1 if mom<-0.5 else 0)+10*(1 if pattern_bear else 0)+sr_bear
    # Quality mode: require the four core gates, then 85/95.
    if bullish_htf and structure_bull and bull_sweep and displacement and trigger_bull and score_b>=85:
        direction=1; score=score_b
    elif bearish_htf and structure_bear and bear_sweep and displacement and trigger_bear and score_s>=85:
        direction=-1; score=score_s
    else:
        return {'symbol':symbol,'valid':False,'status':'no confirmed setup','score':max(score_b,score_s),'price':last}
    entry=last
    sl=entry-(1.25*a if direction>0 else -1.25*a)
    r=abs(entry-sl)
    tp1=entry+(2*r if direction>0 else -2*r); tp2=entry+(3*r if direction>0 else -3*r); tp3=entry+(4*r if direction>0 else -4*r); tp4=entry+(5*r if direction>0 else -5*r); final=entry+(6*r if direction>0 else -6*r)
    reason=[]
    reason.append('H4/H1 alignment'); reason.append('M15 structure/BOS'); reason.append('liquidity sweep + reclaim'); reason.append('M15 displacement'); reason.append('M5 trigger')
    if pattern_bull or pattern_bear: reason.append('pattern confirmation')
    reason.append('S/R confluence')
    return {'symbol':symbol,'valid':True,'direction':'BUY' if direction>0 else 'SELL','entry':entry,'sl':sl,'tp1':tp1,'tp2':tp2,'tp3':tp3,'tp4':tp4,'final':final,'confidence':round(score,1),'reason':' • '.join(reason),'detected_at':datetime.now(timezone.utc).isoformat(),'status':'CONFIRMED'}

def load():
    try:return json.loads(open(OUT).read())
    except:return {'updated_at':None,'scanner':'cloud','active':None,'history':[]}

def advance_publication(data):
    a=data.get('active')
    if a and a.get('status')=='INCOMING':
        try:
            if datetime.now(timezone.utc).timestamp() >= datetime.fromisoformat(a['publish_at'].replace('Z','+00:00')).timestamp():
                a['status']='PUBLISHED'
                a['published_at']=datetime.now(timezone.utc).isoformat()
        except Exception: pass

def mark_outcome(data, prices):
    a=data.get('active')
    if not a:return
    px=prices.get(a['symbol'])
    if px is None:return
    d=a['direction']; status=a.get('status','PUBLISHED')
    if d=='BUY':
        if px>=a['final']: status='TP4/FINAL';
        elif px>=a['tp4']: status='TP4';
        elif px>=a['tp3']: status='TP3';
        elif px>=a['tp2']: status='TP2';
        elif px>=a['tp1']: status='TP1';
        elif px<=a['sl']: status='SL';
    else:
        if px<=a['final']: status='TP4/FINAL';
        elif px<=a['tp4']: status='TP4';
        elif px<=a['tp3']: status='TP3';
        elif px<=a['tp2']: status='TP2';
        elif px<=a['tp1']: status='TP1';
        elif px>=a['sl']: status='SL'
    if status!=a.get('status'):
        a['status']=status; a['last_price']=px; a['updated_at']=datetime.now(timezone.utc).isoformat()
        if status in ('SL','TP4/FINAL'):
            data.setdefault('history',[]).insert(0,a.copy()); data['history']=data['history'][:50]; data['active']=None

def main():
    data=load(); data['updated_at']=datetime.now(timezone.utc).isoformat(); data['scanner']='C.P.D CLOUD SCANNER'; data['market_data']='Twelve Data'; data['schedule']='15-minute quality scan'
    prices={}
    candidates=[]
    for sym in SYMBOLS:
        try:
            # Latest 5m close is obtained as part of the same request used for scanning.
            result=score_symbol(sym)
            if result.get('price'): prices[sym]=result['price']
            candidates.append(result)
        except Exception as e:
            candidates.append({'symbol':sym,'valid':False,'status':'data error: '+str(e)[:120]})
    advance_publication(data)
    mark_outcome(data,prices)
    confirmed=[x for x in candidates if x.get('valid')]
    confirmed.sort(key=lambda x:x.get('confidence',0),reverse=True)
    if confirmed:
        best=confirmed[0]
        # Don't replace a still-open signal with a different one unless the current one is finished.
        if data.get('active') is None:
            best['status']='INCOMING'; best['detected_at']=datetime.now(timezone.utc).isoformat(); best['publish_at']=datetime.fromtimestamp(datetime.now(timezone.utc).timestamp()+120,timezone.utc).isoformat(); data['active']=best
            data.setdefault('history',[])
        data['status']='SIGNAL PUBLISHED • '+best['symbol']+' '+best['direction']+' • '+str(best['confidence'])+'/95'
    elif data.get('active') is None:
        data['status']='SCANNING • no confirmed C.P.D setup'
    data['candidates']=[{'symbol':x.get('symbol'),'valid':x.get('valid',False),'status':x.get('status'),'score':x.get('score'),'price':x.get('price')} for x in candidates]
    with open(OUT,'w') as f: json.dump(data,f,indent=2)

if __name__=='__main__': main()
