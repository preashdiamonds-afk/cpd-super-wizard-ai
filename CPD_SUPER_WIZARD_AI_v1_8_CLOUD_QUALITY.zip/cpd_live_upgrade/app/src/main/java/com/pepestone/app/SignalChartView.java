package com.pepestone.app;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.util.AttributeSet;
import java.util.*;

/**
 * AI-style setup visual. Candles are illustrative; the levels are the actual
 * signal levels supplied to the view. This avoids pretending the drawing is a
 * broker screenshot while still giving the user a clear setup picture.
 */
public class SignalChartView extends View {
  private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
  private boolean buy = true, has = false;
  private double entry, sl, tp1, tp2, tp3, tp4;
  private String symbol = "";

  public SignalChartView(Context c){this(c,null);}
  public SignalChartView(Context c, AttributeSet a){ super(c,a); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
  public void setSignal(StrategyEngine.Signal s){
    if(s==null){has=false;invalidate();return;}
    has=true; buy=s.dir>0; entry=s.entry; sl=s.sl;
    double r=Math.abs(s.entry-s.sl); tp1=buy?entry+r*2:entry-r*2; tp2=buy?entry+r*3:entry-r*3; tp3=buy?entry+r*4:entry-r*4; tp4=buy?entry+r*6:entry-r*6;
    symbol=s.symbol; invalidate();
  }
  public void setManual(String sym, boolean isBuy,double e,double stop){
    has=true; symbol=sym; buy=isBuy; entry=e; sl=stop; double r=Math.abs(e-stop);
    tp1=buy?e+r*2:e-r*2; tp2=buy?e+r*3:e-r*3; tp3=buy?e+r*4:e-r*4; tp4=buy?e+r*6:e-r*6; invalidate();
  }
  public void clear(){has=false;invalidate();}
  @Override protected void onDraw(Canvas c){
    super.onDraw(c); int w=getWidth(),h=getHeight();
    p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(11,15,22)); c.drawRoundRect(0,0,w,h,24,24,p);
    if(!has){p.setColor(Color.rgb(145,155,170));p.setTextSize(14);c.drawText("AI SETUP VISION • waiting for signal",18,32,p);return;}
    float left=18,right=w-18,top=42,bottom=h-18;
    p.setColor(Color.rgb(29,37,48));p.setStrokeWidth(1);p.setStyle(Paint.Style.STROKE);
    for(int i=1;i<6;i++){float y=top+(bottom-top)*i/6f;c.drawLine(left,y,right,y,p);}
    for(int i=1;i<9;i++){float x=left+(right-left)*i/9f;c.drawLine(x,top,x,bottom,p);}
    double hi=Math.max(Math.max(entry,sl),tp4), lo=Math.min(Math.min(entry,sl),tp4); double pad=(hi-lo)*0.14+1e-9; hi+=pad;lo-=pad;
    Random rnd=new Random(symbol.hashCode()*31L+(buy?1:2));
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
    for(int i=0;i<28;i++){
      double trend=(buy?1:-1)*(i/27.0)*Math.abs(tp1-entry)*0.65;
      double base=entry-(buy?1:-1)*Math.abs(tp1-entry)*0.30+trend;
      double noise=(rnd.nextDouble()-0.5)*Math.abs(tp1-entry)*0.38;
      double o=base+noise, close=base+(rnd.nextDouble()-0.5)*Math.abs(tp1-entry)*0.28;
      double hh=Math.max(o,close)+rnd.nextDouble()*Math.abs(tp1-entry)*0.15;
      double ll=Math.min(o,close)-rnd.nextDouble()*Math.abs(tp1-entry)*0.15;
      float x=left+18+(right-left-36)*i/27f; float bw=6;
      float yo=map(o,lo,hi,top,bottom), yc=map(close,lo,hi,top,bottom), yh=map(hh,lo,hi,top,bottom), yl=map(ll,lo,hi,top,bottom);
      p.setColor(close>=o?Color.rgb(82,196,130):Color.rgb(238,96,96)); c.drawLine(x,yh,x,yl,p);p.setStyle(Paint.Style.FILL);c.drawRect(x-bw/2,Math.min(yo,yc),x+bw/2,Math.max(yo,yc)+1,p);p.setStyle(Paint.Style.STROKE);
    }
    line(c,"ENTRY",entry,Color.rgb(240,220,75),left,right,lo,hi,top,bottom);
    line(c,"SL",sl,Color.rgb(255,92,92),left,right,lo,hi,top,bottom);
    line(c,"TP1",tp1,Color.rgb(130,230,90),left,right,lo,hi,top,bottom);
    line(c,"TP2",tp2,Color.rgb(110,220,160),left,right,lo,hi,top,bottom);
    line(c,"TP3",tp3,Color.rgb(90,190,255),left,right,lo,hi,top,bottom);
    line(c,"TP4 / 6R",tp4,Color.rgb(190,150,255),left,right,lo,hi,top,bottom);
    p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextSize(13);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(symbol+" • M5/M15 SETUP VISION",18,24,p);
    p.setTypeface(Typeface.DEFAULT);p.setColor(Color.rgb(145,155,170));p.setTextSize(10);c.drawText("ILLUSTRATIVE AI SETUP • levels from signal",18,h-5,p);
  }
  private float map(double v,double lo,double hi,float top,float bottom){return (float)(bottom-(v-lo)/(hi-lo)*(bottom-top));}
  private void line(Canvas c,String label,double v,int color,float l,float r,double lo,double hi,float top,float bottom){
    float y=map(v,lo,hi,top,bottom);p.setColor(color);p.setStrokeWidth(3);p.setStyle(Paint.Style.STROKE);c.drawLine(l,y,r,y,p);
    p.setStyle(Paint.Style.FILL);p.setTextSize(11);p.setTypeface(Typeface.create("sans",Typeface.BOLD));String t=label+"  "+fmt(v);float tw=p.measureText(t);p.setColor(Color.argb(225,15,19,27));c.drawRoundRect(r-tw-14,y-14,r,y+12,12,12,p);p.setColor(color);c.drawText(t,r-tw-7,y+4,p);
  }
  private String fmt(double x){return String.format(Locale.US,"%.5f",x);}
}
