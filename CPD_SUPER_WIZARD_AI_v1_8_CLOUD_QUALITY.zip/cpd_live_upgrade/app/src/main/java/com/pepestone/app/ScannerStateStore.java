package com.pepestone.app;

import android.content.Context;
import org.json.JSONObject;

/** Small persistent hand-off between the background scanner and the dashboard. */
public class ScannerStateStore {
  private final android.content.SharedPreferences p;
  public ScannerStateStore(Context c){p=c.getApplicationContext().getSharedPreferences("cpd_scanner_state",Context.MODE_PRIVATE);}
  public void status(String text){p.edit().putString("status",text).putLong("statusAt",System.currentTimeMillis()).apply();}
  public String status(){return p.getString("status","Scanner starting…");}
  public long statusAt(){return p.getLong("statusAt",0);}
  public void pending(StrategyEngine.Signal s,long publishAt){
    p.edit().putString("signal",encode(s).toString()).putLong("detectedAt",System.currentTimeMillis()).putLong("publishAt",publishAt).putBoolean("published",false).apply();
  }
  public void published(StrategyEngine.Signal s){
    p.edit().putString("signal",encode(s).toString()).putLong("publishedAt",System.currentTimeMillis()).putBoolean("published",true).apply();
  }
  public void pendingIfNeeded(StrategyEngine.Signal s,String key,String status){ String old=p.getString("cloudKey",""); if(!key.equals(old)){ p.edit().putString("cloudKey",key).putString("signal",encode(s).toString()).putBoolean("published","PUBLISHED".equals(status)).putLong("publishAt",System.currentTimeMillis()+120000L).apply(); } else if("PUBLISHED".equals(status)){ p.edit().putBoolean("published",true).apply(); } }
  public boolean hasSignal(){return p.contains("signal");}
  public boolean isPublished(){return p.getBoolean("published",false);}
  public long publishAt(){return p.getLong("publishAt",0);}
  public StrategyEngine.Signal signal(){
    try{return decode(new JSONObject(p.getString("signal","{}")));}catch(Exception e){return null;}
  }
  public void clear(){p.edit().clear().apply();}
  private JSONObject encode(StrategyEngine.Signal s){
    JSONObject j=new JSONObject();try{j.put("symbol",s.symbol);j.put("dir",s.dir);j.put("confidence",s.confidence);j.put("entry",s.entry);j.put("sl",s.sl);j.put("tp",s.tp);j.put("atr",s.atr);j.put("reason",s.reason);j.put("tvConfirmed",s.tvConfirmed);j.put("newsRisk",s.newsRisk);j.put("vixRisk",s.vixRisk);j.put("vix",s.vix);}catch(Exception ignored){}return j;
  }
  private StrategyEngine.Signal decode(JSONObject j){
    StrategyEngine.Signal s=new StrategyEngine.Signal(j.optString("symbol"));s.valid=true;s.dir=j.optInt("dir");s.confidence=j.optDouble("confidence");s.entry=j.optDouble("entry");s.sl=j.optDouble("sl");s.tp=j.optDouble("tp");s.atr=j.optDouble("atr");s.reason=j.optString("reason");s.tvConfirmed=j.optBoolean("tvConfirmed");s.newsRisk=j.optBoolean("newsRisk");s.vixRisk=j.optBoolean("vixRisk");s.vix=j.optDouble("vix");return s;
  }
}
