# C.P.D SUPER WIZARD AI — v1.5.1 build fix

Fixed the Android resource-linking error in `activity_main.xml`: the invalid `android:hintTextColor` attribute was replaced with the valid `android:textColorHint` attribute on all signal-planner EditText fields.

No trading behavior or manual/automatic-mode policy was changed by this build fix. Automatic trading remains locked.
