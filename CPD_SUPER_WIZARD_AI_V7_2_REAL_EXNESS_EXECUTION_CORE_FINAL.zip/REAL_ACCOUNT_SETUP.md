# C.P.D SUPER WIZARD AI — REAL EXNESS MT5 CONNECTION

This build is **live-capable**, but the Android app does not directly log into Exness or run an MT5 Expert Advisor. The execution path is:

`Android C.P.D app → CPD Bridge → MT5 terminal + C.P.D EA → Exness MT5 account`

## What is enabled
- LIVE account mode in the Android app
- Explicit LIVE enable switch
- REAL/DEMO account-mode verification before an order is queued
- MT5 EA live execution when `AllowLiveAuto=true` and `LiveTradingLocked=false`
- Normal Auto order direction, SL and TP passed to MT5
- Real-account heartbeat back to the app
- DEMO commands rejected on REAL accounts and LIVE commands rejected on DEMO accounts

## What you must install/configure
1. Open the **Exness MT5 account** in an MT5 desktop terminal (normally on a Windows PC/VPS).
2. Compile `mt5/CPD_SUPER_WIZARD_AI_BRIDGE.mq5` in MetaEditor.
3. Add the CPD Bridge HTTPS URL to MT5 **Tools → Options → Expert Advisors → Allow WebRequest for listed URL**.
4. Attach the EA to a chart for the same Exness MT5 account.
5. Set `CPD_Bridge_URL` and the same `CPD_Bridge_Token` used by the bridge server.
6. For a real account, confirm these EA inputs: `AllowLiveAuto=true`, `AllowNormalAuto=true`, `AllowAggressiveAuto=true`, `LiveTradingLocked=false`.
7. In the Android app, select **LIVE**, configure the same MT5 login/server and bridge URL/token, then explicitly enable **LIVE TRADING**.
8. The app should show `ACTUAL ACCOUNT: REAL` and `EXECUTION READY`.

## Important
The source cannot honestly guarantee a real trade until the EA has been compiled, attached to a real MT5 terminal, the WebRequest URL is allowed, and the bridge heartbeat reports the real account. A phone-only Android app cannot itself host the MT5 EA.

For 24/7 EA execution, Exness currently advertises a free VPS for eligible clients. The VPS is designed to keep Expert Advisors running even when the user's own computer is off. Eligibility is determined by Exness.
