# C.P.D SUPER WIZARD AI — Real Exness MT5 Build

This package is the connected build. It preserves the V7.1 lessons, scanner, Normal Auto, Aggressive Auto, Signal Center, strategy engine, risk controls and MT5 bridge.

## Real-account architecture

`Android C.P.D app -> HTTPS CPD Bridge -> MT5 desktop terminal/Exness VPS -> C.P.D EA -> Exness REAL MT5 account`

The Android app does not ask for or transmit the Exness trading password. The MT5 terminal is the authority for account mode, balance, equity and positions.

## 1. Deploy the bridge

The `bridge_server/` folder is a dependency-free Python HTTP bridge. Deploy it as a web service and set the environment variable:

`CPD_BRIDGE_TOKEN=<long-random-secret>`

Use HTTPS. The app and EA must use the same secret. Do not commit the secret to GitHub.

## 2. Prepare MT5

On an Exness-supported desktop MT5 terminal or Exness VPS:

1. Put `mt5/CPD_SUPER_WIZARD_AI_BRIDGE.mq5` in `MQL5/Experts`.
2. Compile it in MetaEditor.
3. In MT5, enable **Allow algorithmic trading**.
4. In **Tools -> Options -> Expert Advisors**, add the bridge HTTPS origin to **Allow WebRequest for listed URL**.
5. Attach the EA to a chart.
6. Set `CPD_Bridge_URL` and `CPD_Bridge_Token`.
7. For real execution, set `AllowLiveAuto=true` and `LiveTradingLocked=false`.

## 3. Connect the Android app

In **MT5 Account Center** select LIVE, enter the MT5 login and exact Exness server, then enter the bridge URL/token and enable LIVE execution.

The app must display:

- `ACTUAL ACCOUNT: REAL`
- matching login/server
- current balance/equity
- `EXECUTION READY`

If the bridge reports DEMO while LIVE is selected, the order is rejected. If LIVE is selected but the bridge does not report REAL, the order is rejected.

## 4. Execution commands

The bridge now supports:

- OPEN
- MODIFY (SL/TP)
- CLOSE

Normal and Aggressive remain separate modes. The EA reports execution results and continuously sends account/position heartbeat data.

## 5. Important reality check

An MT5 Expert Advisor runs on desktop MT4/MT5 terminals, not inside the Android MT5 mobile app. Exness documents that EAs are supported on desktop terminals and that its VPS can keep an EA running 24/7 for eligible accounts.

A real trade is considered connected only after the EA is compiled, attached, allowed to make WebRequests, logged into the intended REAL MT5 account, and the bridge receives its REAL heartbeat.
