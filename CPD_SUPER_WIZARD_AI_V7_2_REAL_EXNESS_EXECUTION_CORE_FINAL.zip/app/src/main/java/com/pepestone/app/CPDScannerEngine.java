package com.pepestone.app;

import java.util.*;
import org.json.*;

/** Multi-timeframe CPD Scanner. Screenshot is treated as visual context; live candles provide M5/M15/H1/H4 confirmation. */
public final class CPDScannerEngine {
  public static class ScanResult {
    public String symbol, direction="WAIT", entry="—", sl="—", tp="—", reason="";
    public String trend="MIXED", volatility="UNKNOWN", pattern="NONE", supportResistance="NONE", momentum="UNKNOWN", marketState="WAIT";
    public double confidence=0, atrPercent=0;
    public String[] timeframes={"WAIT","WAIT","WAIT","WAIT"};
    public boolean screenshotReceived;
  }

  public static ScanResult scan(String symbol, PublicMarketDataClient data, boolean screenshotReceived){
    ScanResult out=new ScanResult(); out.symbol=symbol; out.screenshotReceived=screenshotReceived;
    try{
      List<StrategyEngine.Candle> h4=toList(data.candles(symbol,"4h",250));
      List<StrategyEngine.Candle> h1=toList(data.candles(symbol,"1h",250));
      List<StrategyEngine.Candle> m15=toList(data.candles(symbol,"15m",160));
      List<StrategyEngine.Candle> m5=toList(data.candles(symbol,"5m",160));
      org.json.JSONObject px=data.price(symbol); double bid=px.optDouble("bid"),ask=px.optDouble("ask");
      out.timeframes[0]=trend(h4); out.timeframes[1]=trend(h1); out.timeframes[2]=trend(m15); out.timeframes[3]=trend(m5);
      out.trend=out.timeframes[0]+" / "+out.timeframes[1]+" / "+out.timeframes[2]+" / "+out.timeframes[3];
      double a5=StrategyEngine.atr(m5,14), lastPx=m5.get(m5.size()-2).c; out.atrPercent=(a5>0&&lastPx>0)?a5/lastPx*100.0:0;
      out.volatility=out.atrPercent>0.20?"HIGH":out.atrPercent>0.08?"NORMAL":"LOW";
      StrategyEngine engine=new StrategyEngine(); StrategyEngine.Signal s=engine.evaluate(symbol,h4,h1,m15,m5,bid,ask,false);
      if(s.valid){
        EnsembleIntelligence.Result e=EnsembleIntelligence.assess(h4,h1,m15,m5,s);
        out.direction=s.dir>0?"BUY":"SELL"; out.entry=fmt(s.entry); out.sl=fmt(s.sl); out.tp=fmt(s.tp); out.marketState="VALIDATED"; out.pattern=s.pattern+" • "+s.patternQuality; out.supportResistance=s.sr+" • "+s.srQuality; out.momentum=out.timeframes[2];
        out.confidence=Math.min(100,(s.confidence/95.0)*100.0*0.75+e.agreement*0.25);
        out.reason=s.reason+"\n\nMULTI-ENGINE: "+e.summary+"\n"+join(e.engines);
      } else {
        out.marketState="WAIT"; out.reason="No fully validated Normal setup. CPD Scanner recommends WAIT rather than forcing BUY/SELL when the timeframe evidence is incomplete or conflicting.";
      }
    }catch(Exception ex){out.reason="Scanner could not complete: "+ex.getMessage();}
    return out;
  }
  private static String join(List<String> x){StringBuilder b=new StringBuilder();for(String s:x){if(b.length()>0)b.append(" • ");b.append(s);}return b.toString();}
  private static List<StrategyEngine.Candle> toList(JSONArray a){List<StrategyEngine.Candle> r=new ArrayList<>();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null)r.add(new StrategyEngine.Candle(a.optJSONObject(i)));return r;}
  private static String trend(List<StrategyEngine.Candle> r){if(r==null||r.size()<120)return "INSUFFICIENT";int slow=r.size()>=205?200:100;double e=StrategyEngine.ema(r,50),s=StrategyEngine.ema(r,slow),c=r.get(r.size()-2).c;return c>e&&e>s?"BULLISH":c<e&&e<s?"BEARISH":"NEUTRAL";}
  private static String fmt(double x){return x>0?String.format(Locale.US,"%.5f",x):"—";}
}
