# C.P.D SUPER WIZARD AI — V3 Protected Demo / Live-Locked Command Center

## Identity
Launch greeting: **WELCOME, CAPTAIN PREASH DIAMOND**.

## Account modes
- **DEMO — UNLOCKED:** intended for testing the strategy, scanner, bridge and position synchronization.
- **LIVE — LOCKED:** real-money execution is disabled by default. The Android UI shows the lock and the MT5-side bridge independently rejects real-account execution while the lock is active.
- The app does **not** claim that a normal Android MT5 login can run an MQL5 Expert Advisor.

## Mobile sections
- **Home** — protected account mode, MT5 bridge status, watchlist and bot description.
- **Auto** — separate Normal Auto and Aggressive Auto controls.
- **Manual** — Normal Auto signal mirror with Entry/SL/TP, confidence, reasons and Telegram copy.
- **CPD Scanner** — upload a chart screenshot and combine its visual context with available M5/M15/H1/H4 market data.

## Normal vs Aggressive
Normal Auto is the source for the Normal Manual Signal Center. Aggressive signals are isolated and never enter the Normal feed.

## CPD Scanner
The scanner may return BUY, SELL or WAIT. It must not invent hidden timeframes from a screenshot. When live market data is unavailable or evidence conflicts, WAIT is a valid result.

## Multi-engine intelligence
1. Higher-timeframe trend
2. Market structure / BOS
3. Liquidity sweep
4. Displacement
5. Momentum
6. Pattern confirmation
7. Strong/weak support and resistance
8. Breakout/fakeout validation
9. Risk and quality gates

Confidence is a confluence score, **not a probability of profit**.

## MT5 / Exness architecture
Android is the command center. Actual automated MT5 execution requires an MT5-side Expert Advisor/bridge running in an MT5 terminal. The included `mt5/CPD_SUPER_WIZARD_AI_BRIDGE.mq5` is a protected broker-side boundary.

The bridge is deliberately conservative in V3: it detects REAL accounts and refuses execution while `LiveTradingLocked` is true. A production authenticated command transport must be completed and demo-tested before any order execution is enabled.

## Safety
Demo testing, backtesting and out-of-sample validation should come before any live authorization. No strategy can guarantee profits.


## REAL EXNESS MT5 CONNECTION
See `REAL_ACCOUNT_SETUP.md`. The Android app is live-capable through the authenticated CPD Bridge and MT5 Expert Advisor; it does not pretend to connect directly to a broker REST API.
