package com.pepestone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * C.P.D SUPER WIZARD AI — PRO COMMAND CENTER.
 * V4 is a substantial UI/flow rebuild over the protected V3 base.
 * Live trading remains hard locked. Demo is the testing mode.
 */
public class MainActivity extends Activity {
  private final String[] PAIRS={"EURUSD","GBPUSD","USDJPY","GBPJPY","AUDUSD","USDCAD","USDCHF","AUDJPY","AUDCAD","AUDCHF","XAUUSD"};
  private LinearLayout content; private TextView topStatus; private Spinner pairSpinner; private TextView scannerResult,visualInfo,manualSignal,connectionState,accountSummary,positionSummary,performanceSummary;
  private ImageView chartPreview; private EditText scannerInstruction;
  private Bitmap uploadedChart; private StrategyEngine.Signal lastNormalSignal; private SignalChartView vision;
  private final PublicMarketDataClient market=new PublicMarketDataClient();
  private final ExnessMt5Client bridge=new ExnessMt5Client();
  private android.content.SharedPreferences prefs;
  private final Handler bridgeHandler=new Handler(Looper.getMainLooper());
  private final Runnable bridgeRefresh=()->{refreshBridgeStatus();refreshAccountPanels();bridgeHandler.postDelayed(bridgeRefresh,5000);};
  private boolean normalOn=false, aggressiveOn=false;
  private double agBaseLot=0.01, agMultiplier=1.50, agMaxLot=2.55, agAddDistanceAtr=0.50, agLockPct=5.0, agMarginFloor=150.0;
  private int agMaxPositions=20, agCooldownSec=5;
  private String agDirection="FOLLOW_SIGNAL", agProfitBank="0.80R / 1.60R / 2.60R"; private final ExecutorService io=Executors.newSingleThreadExecutor();
  private int gold=Color.rgb(246,196,76), bg=Color.rgb(5,7,11), card=Color.rgb(14,18,25), card2=Color.rgb(20,25,34), white=Color.rgb(242,246,252), muted=Color.rgb(145,157,174), green=Color.rgb(71,214,137), red=Color.rgb(255,99,111), blue=Color.rgb(92,169,255);

  @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("cpd_bridge",MODE_PRIVATE);loadBridgeConfig();loadAggressiveConfig();getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);build();welcome();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);}
  private TextView tv(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setFontFeatureSettings("kern");return v;}
  private GradientDrawable box(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);g.setStroke(1,Color.rgb(42,49,61));return g;}
  private LinearLayout card(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(18,16,18,16);x.setBackground(box(card,24));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,9,0,0);x.setLayoutParams(p);return x;}
  private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(11);b.setTypeface(null,Typeface.BOLD);b.setAllCaps(false);b.setTextColor(primary?bg:white);b.setBackground(box(primary?gold:card2,18));b.setPadding(8,0,8,0);return b;}
  private TextView badge(String s,int c){TextView v=tv(s,11,c);v.setTypeface(null,Typeface.BOLD);v.setPadding(12,7,12,7);v.setBackground(box(Color.rgb(22,28,37),18));return v;}

  private void build(){
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);setContentView(root);
    LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setPadding(18,15,18,10);head.setBackgroundColor(Color.rgb(8,11,16));
    LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView t=tv("C.P.D",25,gold);t.setTypeface(null,Typeface.BOLD);row.addView(t,new LinearLayout.LayoutParams(0,42,1));TextView lock=badge("🔒 LIVE LOCKED",red);row.addView(lock);head.addView(row);
    topStatus=tv("COMMAND CENTER  •  DEMO UNLOCKED",11,green);topStatus.setPadding(2,2,0,0);head.addView(topStatus);root.addView(head,new LinearLayout.LayoutParams(-1,-2));
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(13,4,13,18);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=new LinearLayout(this);nav.setPadding(5,6,5,7);nav.setBackgroundColor(Color.rgb(9,12,17));String[] tabs={"⌂ HOME","◉ AUTO","≡ SIGNAL","◈ SCAN","▥ PERF","⚙ SET"};for(String s:tabs){Button b=button(s,false);b.setTextSize(9);String key=s.substring(2);b.setOnClickListener(v->show(key));nav.addView(b,new LinearLayout.LayoutParams(0,56,1));}root.addView(nav,new LinearLayout.LayoutParams(-1,70));show("HOME");
  }
  private void welcome(){new Handler().postDelayed(()->new AlertDialog.Builder(this).setTitle("WELCOME, CAPTAIN PREASH DIAMOND").setMessage("C.P.D SUPER WIZARD AI is now in protected Demo mode. Normal Auto, Aggressive Auto, Signal Center and CPD Scanner are separate modules. Live trading is locked.").setPositiveButton("ENTER COMMAND CENTER",null).show(),250);}
  private void show(String tab){content.removeAllViews();if(tab.equals("AUTO"))auto();else if(tab.equals("SIGNAL"))signal();else if(tab.equals("SCAN"))scan();else if(tab.equals("PERF"))performance();else if(tab.equals("MT5"))mt5();else if(tab.equals("SET"))settings();else home();}
  private void header(String title,String sub){LinearLayout c=card();c.addView(tv(title,22,gold));TextView x=tv(sub,12,muted);x.setPadding(0,5,0,0);c.addView(x);content.addView(c);}
  private void home(){
    header("WELCOME, CAPTAIN PREASH DIAMOND","PRO COMMAND CENTER  •  MULTI-ENGINE TRADING SYSTEM");
    LinearLayout mode=card();mode.addView(tv("ACCOUNT SAFETY",13,gold));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView d=badge("● DEMO  UNLOCKED",green);TextView l=badge("● LIVE  LOCKED",red);r.addView(d,new LinearLayout.LayoutParams(0,42,1));r.addView(l,new LinearLayout.LayoutParams(0,42,1));mode.addView(r);TextView m=tv("Real-money execution is blocked at the bridge layer. No live order can pass while protection is active.",11,muted);m.setPadding(0,10,0,0);mode.addView(m);content.addView(mode);
    LinearLayout stats=card();stats.addView(tv("SYSTEM SNAPSHOT",13,gold));stats.addView(statRow("NORMAL AUTO",normalOn?"SCANNING":"STANDBY",normalOn?green:muted));stats.addView(statRow("AGGRESSIVE AUTO",aggressiveOn?"ISOLATED / ON":"STANDBY",aggressiveOn?blue:muted));stats.addView(statRow("SIGNAL CENTER",lastNormalSignal==null?"NO ACTIVE SIGNAL":"SIGNAL READY",lastNormalSignal==null?muted:green));stats.addView(statRow("CPD SCANNER","M5 • M15 • H1 • H4",blue));content.addView(stats);
    LinearLayout acct=card(); acct.addView(tv("DEMO ACCOUNT DASHBOARD",13,gold));
    accountSummary=tv("Waiting for MT5 demo connection…",12,white); acct.addView(accountSummary);
    positionSummary=tv("No synchronized positions yet.",11,muted); positionSummary.setPadding(0,10,0,0); acct.addView(positionSummary);
    performanceSummary=tv("Weekly win rate: —\nMonthly win rate: —",11,white); performanceSummary.setPadding(0,10,0,0); acct.addView(performanceSummary);
    content.addView(acct);
    LinearLayout engines=card();engines.addView(tv("INTELLIGENCE STACK",13,gold));String[] es={"01  MARKET STRUCTURE","02  TRUE / FALSE PATTERN","03  STRONG / WEAK SUPPORT & RESISTANCE","04  LIQUIDITY / SWEEP","05  MOMENTUM + DISPLACEMENT","06  BREAKOUT / FAKEOUT","07  MULTI-TIMEFRAME VALIDATION","08  RISK + FINAL DECISION"};for(String e:es){TextView q=tv("◆ "+e,11,white);q.setPadding(0,7,0,7);engines.addView(q);}content.addView(engines);
    LinearLayout about=card();about.addView(tv("WHAT THIS VERSION IS",13,gold));about.addView(tv("A redesigned command-center shell for the C.P.D strategy. The scanner uses live market candles when available and the uploaded chart as visual context. It can return BUY, SELL or WAIT. Execution remains protected until a real authenticated MT5 bridge is configured and demo-tested.",12,white));content.addView(about);
  }
  private TextView statRow(String a,String b,int c){TextView v=tv(a+"                                      "+b,11,c);v.setPadding(0,9,0,3);return v;}
  private void auto(){
    header("AUTO ENGINE","NORMAL and AGGRESSIVE are independent systems");
    LinearLayout p=card();p.addView(tv("MARKET",13,gold));pairSpinner=new Spinner(this);pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS));p.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));content.addView(p);
    LinearLayout n=card();n.addView(tv("NORMAL AUTO",17,gold));n.addView(tv("Primary strategy • feeds Signal Center • Demo path",11,muted));Button nb=button(normalOn?"● NORMAL AUTO ON  •  STOP":"NORMAL AUTO  •  START",!normalOn);nb.setOnClickListener(v->{normalOn=!normalOn;topStatus.setText(normalOn?"NORMAL AUTO  •  SCANNING DEMO PATH":"COMMAND CENTER  •  DEMO UNLOCKED");show("AUTO");if(normalOn)scanNormal();});n.addView(nb,new LinearLayout.LayoutParams(-1,52));n.addView(tv("Validation: HTF bias → structure → pattern → S/R → liquidity → momentum → MTF → risk gate",10,white));content.addView(n);
    LinearLayout a=card();a.addView(tv("AGGRESSIVE AUTO",17,blue));a.addView(tv("Separate engine • never feeds Normal Signal Center",11,muted));Button ab=button(aggressiveOn?"● AGGRESSIVE ON  •  STOP":"AGGRESSIVE AUTO  •  START",false);ab.setOnClickListener(v->{aggressiveOn=!aggressiveOn;Toast.makeText(this,aggressiveOn?"Aggressive engine isolated and enabled for demo testing.":"Aggressive engine stopped.",Toast.LENGTH_SHORT).show();show("AUTO");});a.addView(ab,new LinearLayout.LayoutParams(-1,52));a.addView(tv("Protection design: high-water-mark loss lock and separate risk controls.",10,white));Button as=button("⚙ AGGRESSIVE SETTINGS",true);as.setOnClickListener(v->aggressiveSettingsDialog());a.addView(as,new LinearLayout.LayoutParams(-1,50));content.addView(a);
    LinearLayout lock=card();lock.addView(tv("LIVE EXECUTION",13,red));lock.addView(tv("🔒 HARD LOCKED  •  app + MT5 bridge protection",14,white));Button lb=button("VIEW LIVE LOCK",false);lb.setOnClickListener(v->liveLock());lock.addView(lb,new LinearLayout.LayoutParams(-1,48));content.addView(lock);
  }
  private void signal(){
    header("SIGNAL CENTER","Normal Auto only • mirrors the Normal strategy feed");
    LinearLayout c=card();c.addView(tv("ACTIVE NORMAL SETUP",13,gold));manualSignal=tv(lastNormalSignal==null?"No Normal Auto signal yet. Start Normal Auto from the AUTO tab.":format(lastNormalSignal),12,white);manualSignal.setPadding(0,10,0,10);c.addView(manualSignal);if(lastNormalSignal!=null){vision=new SignalChartView(this);vision.setSignal(lastNormalSignal);c.addView(vision,new LinearLayout.LayoutParams(-1,440));Button cp=button("COPY SIGNAL FOR TELEGRAM",true);cp.setOnClickListener(v->copySignal());c.addView(cp,new LinearLayout.LayoutParams(-1,50));}content.addView(c);
    LinearLayout info=card();info.addView(tv("POSITION SYNC",13,gold));positionSummary=tv("Synchronizing actual MT5 positions…",11,white); info.addView(positionSummary);content.addView(info);
  }
  private void scan(){
    header("CPD SCANNER","TRADEBUDDY-STYLE CHART REVIEW • screenshot + live M5/M15/H1/H4 confirmation");
    LinearLayout input=card();
    input.addView(tv("1 • CHOOSE MARKET",13,gold));
    pairSpinner=new Spinner(this); pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS)); input.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));
    input.addView(tv("2 • ADD CHART SCREENSHOT",13,gold));
    LinearLayout row=new LinearLayout(this); Button up=button("UPLOAD / CAPTURE CHART",true); up.setOnClickListener(v->pick()); Button go=button("ANALYZE CHART",false); go.setOnClickListener(v->runScanner()); row.addView(up,new LinearLayout.LayoutParams(0,52,1)); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,52,1); gp.setMargins(8,0,0,0); row.addView(go,gp); input.addView(row);
    chartPreview=new ImageView(this); chartPreview.setScaleType(ImageView.ScaleType.CENTER_INSIDE); chartPreview.setBackground(box(Color.rgb(9,13,19),18)); chartPreview.setAdjustViewBounds(true); chartPreview.setMinimumHeight(230); if(uploadedChart!=null) chartPreview.setImageBitmap(uploadedChart); input.addView(chartPreview,new LinearLayout.LayoutParams(-1,230));
    visualInfo=tv(uploadedChart==null?"No chart uploaded yet.":ChartVisualContext.describe(uploadedChart),10,muted); visualInfo.setPadding(0,9,0,0); input.addView(visualInfo);
    input.addView(tv("3 • OPTIONAL ANALYSIS INSTRUCTION",13,gold)); scannerInstruction=new EditText(this); scannerInstruction.setHint("Example: Find a confirmed breakout and only return BUY/SELL if M5-M15-H1-H4 agree."); scannerInstruction.setTextColor(white); scannerInstruction.setHintTextColor(muted); scannerInstruction.setMinLines(2); input.addView(scannerInstruction,new LinearLayout.LayoutParams(-1,90)); content.addView(input);
    LinearLayout result=card(); result.addView(tv("CPD SCANNER REPORT",13,gold)); scannerResult=tv("WAITING FOR CHART ANALYSIS\n\nUpload a chart or choose a pair, then tap ANALYZE CHART.\n\nThe scanner can return BUY, SELL or WAIT.",12,white); scannerResult.setPadding(0,12,0,12); result.addView(scannerResult); content.addView(result);
  }
  private void loadBridgeConfig(){bridge.configure(prefs.getString("login",""),prefs.getString("server",""),prefs.getString("url",""),prefs.getString("token",""));}
  private void saveBridgeConfig(String login,String server,String url,String token){prefs.edit().putString("login",login).putString("server",server).putString("url",url).putString("token",token).apply();bridge.configure(login,server,url,token);}
  private void mt5(){
    header("MT5 BRIDGE","REAL Exness/MT5 connection • DEMO execution enabled • LIVE locked");
    LinearLayout c=card();connectionState=tv("● BRIDGE STATUS\nCHECKING…",14,green);c.addView(connectionState);
    Button b=button("CONNECT / CONFIGURE EXNESS DEMO",true);b.setOnClickListener(v->bridgeDialog());c.addView(b,new LinearLayout.LayoutParams(-1,50));
    Button test=button("TEST LIVE CONNECTION",false);test.setOnClickListener(v->refreshBridgeStatus());c.addView(test,new LinearLayout.LayoutParams(-1,50));
    content.addView(c);
    LinearLayout how=card();how.addView(tv("HOW THE REAL CONNECTION WORKS",13,gold));how.addView(tv("C.P.D Android → secure CPD Bridge → MT5 EA → Exness MT5 Demo.\n\nThe app never stores your Exness password. The EA is the only component that talks to the MT5 terminal. The EA independently rejects REAL accounts while Live Lock is active.",11,white));content.addView(how);
    LinearLayout live=card();live.addView(tv("LIVE ACCOUNT",14,red));live.addView(tv("🔒 HARD LOCKED\n\nA REAL MT5 account can be detected, but C.P.D will reject execution. Live unlock is not included in this demo build.",12,white));Button l=button("KEEP LIVE LOCKED",false);l.setOnClickListener(v->liveLock());live.addView(l,new LinearLayout.LayoutParams(-1,50));content.addView(live);refreshBridgeStatus();
  }
  private void loadAggressiveConfig(){
    agBaseLot=prefs.getFloat("agBaseLot",0.01f); agMultiplier=prefs.getFloat("agMultiplier",1.50f); agMaxLot=prefs.getFloat("agMaxLot",2.55f); agAddDistanceAtr=prefs.getFloat("agAddDistanceAtr",0.50f); agLockPct=prefs.getFloat("agLockPct",5.0f); agMarginFloor=prefs.getFloat("agMarginFloor",150.0f); agMaxPositions=prefs.getInt("agMaxPositions",20); agCooldownSec=prefs.getInt("agCooldownSec",5); agDirection=prefs.getString("agDirection","FOLLOW_SIGNAL"); agProfitBank=prefs.getString("agProfitBank","0.80R / 1.60R / 2.60R");
  }
  private void saveAggressiveConfig(){prefs.edit().putFloat("agBaseLot",(float)agBaseLot).putFloat("agMultiplier",(float)agMultiplier).putFloat("agMaxLot",(float)agMaxLot).putFloat("agAddDistanceAtr",(float)agAddDistanceAtr).putFloat("agLockPct",(float)agLockPct).putFloat("agMarginFloor",(float)agMarginFloor).putInt("agMaxPositions",agMaxPositions).putInt("agCooldownSec",agCooldownSec).putString("agDirection",agDirection).putString("agProfitBank",agProfitBank).apply();}
  private EditText numField(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setInputType(2|0x2000);e.setTextColor(white);return e;}
  private void aggressiveSettingsDialog(){
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,0,8,0);
    box.addView(tv("VIDEO-INSPIRED PROFILE",12,gold));box.addView(tv("The uploaded video shows rapid XAUUSD multi-position scaling, increasing lot size and aggressive profit growth. These controls let you define that behavior without hard-coding it.",10,muted));
    EditText base=numField("Base lot",String.valueOf(agBaseLot));EditText mult=numField("Lot multiplier",String.valueOf(agMultiplier));EditText max=numField("Maximum lot",String.valueOf(agMaxLot));EditText maxPos=numField("Maximum open positions",String.valueOf(agMaxPositions));EditText dist=numField("Add-position distance (ATR)",String.valueOf(agAddDistanceAtr));EditText lock=numField("High-water-mark lock %",String.valueOf(agLockPct));EditText margin=numField("Minimum margin level %",String.valueOf(agMarginFloor));EditText cool=numField("Cooldown seconds",String.valueOf(agCooldownSec));
    box.addView(base);box.addView(mult);box.addView(max);box.addView(maxPos);box.addView(dist);box.addView(lock);box.addView(margin);box.addView(cool);
    Spinner dir=new Spinner(this);String[] dirs={"FOLLOW_SIGNAL","LONG_ONLY","SHORT_ONLY","REVERSAL_ONLY"};dir.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,dirs));for(int i=0;i<dirs.length;i++)if(dirs[i].equals(agDirection))dir.setSelection(i);box.addView(dir);
    Spinner bank=new Spinner(this);String[] banks={"0.80R / 1.60R / 2.60R","1R / 2R / 3R","NO STAGED BANKING"};bank.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,banks));for(int i=0;i<banks.length;i++)if(banks[i].equals(agProfitBank))bank.setSelection(i);box.addView(bank);
    new AlertDialog.Builder(this).setTitle("⚙ AGGRESSIVE AUTO SETTINGS").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE SETTINGS",(d,w)->{try{agBaseLot=Double.parseDouble(base.getText().toString());agMultiplier=Double.parseDouble(mult.getText().toString());agMaxLot=Double.parseDouble(max.getText().toString());agMaxPositions=Integer.parseInt(maxPos.getText().toString());agAddDistanceAtr=Double.parseDouble(dist.getText().toString());agLockPct=Double.parseDouble(lock.getText().toString());agMarginFloor=Double.parseDouble(margin.getText().toString());agCooldownSec=Integer.parseInt(cool.getText().toString());agDirection=String.valueOf(dir.getSelectedItem());agProfitBank=String.valueOf(bank.getSelectedItem());if(agBaseLot<=0||agMultiplier<1||agMaxLot<agBaseLot||agMaxPositions<1||agAddDistanceAtr<0||agLockPct<=0||agMarginFloor<0||agCooldownSec<0)throw new IllegalArgumentException();saveAggressiveConfig();Toast.makeText(this,"Aggressive settings saved for DEMO testing.",Toast.LENGTH_LONG).show();}catch(Exception ex){Toast.makeText(this,"Invalid settings. Nothing was changed.",Toast.LENGTH_LONG).show();}}).show();
  }
  private void performance(){
    header("PERFORMANCE DASHBOARD","Actual MT5 demo history • rolling 7-day and 30-day analytics");
    LinearLayout live=card(); live.addView(tv("ACCOUNT / P&L",13,gold)); accountSummary=tv("Synchronizing…",12,white); live.addView(accountSummary); content.addView(live);
    LinearLayout wr=card(); wr.addView(tv("WEEKLY WIN RATE",13,gold)); TextView wv=tv("Loading MT5 history…",18,white); wv.setPadding(0,8,0,8); wr.addView(wv); content.addView(wr);
    LinearLayout mo=card(); mo.addView(tv("MONTHLY WIN RATE",13,blue)); TextView mv=tv("Loading MT5 history…",18,white); mv.setPadding(0,8,0,8); mo.addView(mv); content.addView(mo);
    LinearLayout detail=card(); detail.addView(tv("WHAT IS COUNTED",13,gold)); detail.addView(tv("Win rate is calculated from closed MT5 deals reported by the bridge. Open floating P/L is shown separately from closed net P/L. The dashboard does not invent results when the MT5 history is unavailable.",11,muted)); content.addView(detail);
    io.execute(()->{try{JSONObject a=bridge.accountInfo(),perf=bridge.performance();JSONObject w=perf.optJSONObject("weekly"),m=perf.optJSONObject("monthly");if(w==null)w=new JSONObject();if(m==null)m=new JSONObject();double eq=a.optDouble("equity",0),bal=a.optDouble("balance",0);String ac="Balance "+fmtMoney(bal)+"  •  Equity "+fmtMoney(eq)+"  •  Floating P/L "+fmtMoney(eq-bal);String ws=rate(w)+"\\n"+w.optInt("wins",0)+" wins • "+w.optInt("losses",0)+" losses • "+w.optInt("closed",0)+" closed • Net "+fmtMoney(w.optDouble("net",0));String ms=rate(m)+"\\n"+m.optInt("wins",0)+" wins • "+m.optInt("losses",0)+" losses • "+m.optInt("closed",0)+" closed • Net "+fmtMoney(m.optDouble("net",0));runOnUiThread(()->{accountSummary.setText(ac);wv.setText(ws);mv.setText(ms);});}catch(Exception e){runOnUiThread(()->{accountSummary.setText("MT5 history unavailable\\n"+e.getMessage());wv.setText("—");mv.setText("—");});}});
  }
  private void settings(){
    header("SETTINGS","Configure how C.P.D SUPER WIZARD AI should operate");
    LinearLayout ag=card();ag.addView(tv("AGGRESSIVE AUTO",16,blue));ag.addView(tv("Separate engine • settings are saved on this device • DEMO testing only",11,muted));ag.addView(tv("Base lot: "+agBaseLot+"\nMultiplier: "+agMultiplier+"x\nMax lot: "+agMaxLot+"\nMax positions: "+agMaxPositions+"\nAdd distance: "+agAddDistanceAtr+" ATR\nHigh-water lock: "+agLockPct+"%\nMargin floor: "+agMarginFloor+"%\nDirection: "+agDirection+"\nProfit banking: "+agProfitBank,11,white));Button edit=button("⚙ EDIT AGGRESSIVE MODE",true);edit.setOnClickListener(v->aggressiveSettingsDialog());ag.addView(edit,new LinearLayout.LayoutParams(-1,52));content.addView(ag);
    LinearLayout sig=card();sig.addView(tv("SIGNAL CENTER",15,gold));sig.addView(tv("Normal Auto signals only. Every posted signal includes a COPY SIGNAL button for the full Telegram-ready text.",11,white));content.addView(sig);
    LinearLayout safe=card();safe.addView(tv("SAFETY",15,red));safe.addView(tv("🔒 LIVE TRADING REMAINS LOCKED. Aggressive settings do not unlock real-money execution.",11,white));content.addView(safe);
  }
  private void bridgeDialog(){
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,4,8,0);
    EditText login=new EditText(this);login.setHint("MT5 login number");login.setText(prefs.getString("login",""));box.addView(login);
    EditText server=new EditText(this);server.setHint("Exact Exness MT5 server");server.setText(prefs.getString("server",""));box.addView(server);
    EditText url=new EditText(this);url.setHint("CPD Bridge HTTPS URL");url.setText(prefs.getString("url",""));box.addView(url);
    EditText token=new EditText(this);token.setHint("Bridge secret token");token.setText(prefs.getString("token",""));token.setInputType(0x81);box.addView(token);
    TextView note=tv("The Bridge URL is the public HTTPS address of the CPD MT5 Bridge server. The same token must be entered in the MT5 EA. Use DEMO only for the first test.",10,muted);note.setPadding(0,8,0,0);box.addView(note);
    new AlertDialog.Builder(this).setTitle("CONNECT EXNESS MT5 DEMO").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE & TEST",(d,w)->{
      String l=login.getText().toString().trim(),s=server.getText().toString().trim(),u=url.getText().toString().trim(),t=token.getText().toString().trim();saveBridgeConfig(l,s,u,t);refreshBridgeStatus();
    }).show();
  }
  private void refreshBridgeStatus(){if(connectionState==null)return;if(!bridge.hasBridge()){connectionState.setText("● BRIDGE STATUS\nNOT CONFIGURED\n\nEnter your CPD Bridge URL and token.");return;}io.execute(()->{try{JSONObject h=bridge.health();JSONObject a=bridge.accountInfo();String mode=a.optString("mode","UNKNOWN");runOnUiThread(()->{boolean demo="DEMO".equalsIgnoreCase(mode);refreshAccountPanels();connectionState.setText("● BRIDGE ONLINE\nACCOUNT: "+mode+"\nLOGIN: "+a.optString("login",bridge.getServer())+"\nBALANCE: "+a.optDouble("balance",0)+"\nEQUITY: "+a.optDouble("equity",0)+"\n"+(demo?"DEMO EXECUTION READY":"🔒 LIVE EXECUTION LOCKED"));});}catch(Exception e){runOnUiThread(()->connectionState.setText("● BRIDGE OFFLINE\n"+e.getMessage()));}});}

  private void refreshAccountPanels(){
    if(!bridge.isConfigured()) return;
    io.execute(()->{try{
      JSONObject a=bridge.accountInfo(); JSONObject perf=bridge.performance(); JSONArray ps=bridge.positions();
      String mode=a.optString("mode","UNKNOWN"); double bal=a.optDouble("balance",0),eq=a.optDouble("equity",0),floating=eq-bal;
      String acct="ACCOUNT  "+a.optString("login","")+"  •  "+mode+"\nBALANCE   "+fmtMoney(a.optDouble("balance",0))+"\nEQUITY    "+fmtMoney(a.optDouble("equity",0))+"\nFLOATING P/L  "+fmtMoney(floating)+"\nCURRENCY  "+a.optString("currency","USD");
      StringBuilder pos=new StringBuilder(); pos.append("OPEN POSITIONS  ").append(ps.length()).append("\\n");
      for(int i=0;i<ps.length();i++){JSONObject p=ps.optJSONObject(i); if(p==null)continue; pos.append(p.optString("symbol","")) .append("  ").append(p.optString("type","")) .append("  lot ").append(p.optDouble("volume",0)).append("  P/L ").append(fmtMoney(p.optDouble("profit",0))).append("\\nEntry ").append(fmtPrice(p.optDouble("entry",0))).append("  SL ").append(fmtPrice(p.optDouble("sl",0))).append("  TP ").append(fmtPrice(p.optDouble("tp",0))).append("\\n");}
      JSONObject w=perf.optJSONObject("weekly"),m=perf.optJSONObject("monthly"); String per="WEEKLY  "+rate(w)+"  •  "+w.optInt("wins",0)+"W / "+w.optInt("losses",0)+"L  • Net "+fmtMoney(w.optDouble("net",0))+"\\nMONTHLY "+rate(m)+"  •  "+m.optInt("wins",0)+"W / "+m.optInt("losses",0)+"L  • Net "+fmtMoney(m.optDouble("net",0));
      runOnUiThread(()->{if(accountSummary!=null)accountSummary.setText(acct); if(positionSummary!=null)positionSummary.setText(pos.toString()); if(performanceSummary!=null)performanceSummary.setText(per);});
    }catch(Exception e){runOnUiThread(()->{if(accountSummary!=null)accountSummary.setText("MT5 SYNC ERROR\\n"+e.getMessage());});}});
  }
  private String rate(JSONObject x){if(x==null)return "—";return String.format(Locale.US,"Win rate %.1f%%",x.optDouble("winRate",0));}
  private String fmtMoney(double x){return String.format(Locale.US,"%.2f",x);}
  private String fmtPrice(double x){return x==0?"—":String.format(Locale.US,"%.5f",x);}

  private void liveLock(){new AlertDialog.Builder(this).setTitle("🔒 LIVE TRADING LOCKED").setMessage("Real-money execution is disabled. This is intentional. Demo testing comes first. The app should never silently switch a real MT5 account into an executable state.").setPositiveButton("KEEP LOCKED",null).show();}
  private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,9001);}
  @Override protected void onActivityResult(int r,int code,Intent d){super.onActivityResult(r,code,d);if(r!=9001||code!=RESULT_OK||d==null||d.getData()==null)return;try{Uri u=d.getData();uploadedChart=MediaStore.Images.Media.getBitmap(getContentResolver(),u);if(visualInfo!=null)visualInfo.setText(ChartVisualContext.describe(uploadedChart)); if(chartPreview!=null)chartPreview.setImageBitmap(uploadedChart);}catch(Exception e){if(visualInfo!=null)visualInfo.setText("Could not read chart: "+e.getMessage());}}
  private String selected(){return pairSpinner==null?"EURUSD":String.valueOf(pairSpinner.getSelectedItem());}
  private void runScanner(){final String sym=selected();if(scannerResult!=null)scannerResult.setText("SCANNING "+sym+"\n\nChart Vision → Structure → Pattern → S/R → Liquidity → Momentum → MTF → Risk…");io.execute(()->{CPDScannerEngine.ScanResult r=CPDScannerEngine.scan(sym,market,uploadedChart!=null);runOnUiThread(()->scannerResult.setText(scannerText(r)));});}
  private String scannerText(CPDScannerEngine.ScanResult r){return "PAIR  "+r.symbol+"\n\nVERDICT        "+r.direction+"\nCONFIDENCE     "+String.format(Locale.US,"%.0f%%",r.confidence)+"\nMARKET STATE   "+r.marketState+"\n\nMULTI-TIMEFRAME\nM5   "+r.timeframes[3]+"\nM15  "+r.timeframes[2]+"\nH1   "+r.timeframes[1]+"\nH4   "+r.timeframes[0]+"\n\nTREND          "+r.trend+"\nVOLATILITY     "+r.volatility+"\nPATTERN        "+r.pattern+"\nSUPPORT/RES.   "+r.supportResistance+"\nMOMENTUM       "+r.momentum+"\n\nSETUP\nEntry          "+r.entry+"\nStop Loss      "+r.sl+"\nTake Profit    "+r.tp+"\nATR %          "+String.format(Locale.US,"%.3f",r.atrPercent)+"\n\nANALYSIS\n"+r.reason+"\n\nSCREENSHOT MODE: "+(r.screenshotReceived?"VISUAL CONTEXT ATTACHED":"NO SCREENSHOT")+"\nThe scanner will WAIT when live timeframe evidence conflicts.";}
  private void scanNormal(){final String sym=selected();io.execute(()->{try{List<StrategyEngine.Candle> h4=list(market.candles(sym,"4h",250)),h1=list(market.candles(sym,"1h",250)),m15=list(market.candles(sym,"15m",160)),m5=list(market.candles(sym,"5m",160));org.json.JSONObject p=market.price(sym);StrategyEngine.Signal s=new StrategyEngine().evaluate(sym,h4,h1,m15,m5,p.optDouble("bid"),p.optDouble("ask"),false);if(s.valid){lastNormalSignal=s; boolean canExecute=bridge.isConfigured(); if(canExecute){ try { JSONObject a=bridge.accountInfo(); String mode=a.optString("mode",""); if(!"DEMO".equalsIgnoreCase(mode)) canExecute=false; } catch(Exception ex){canExecute=false;} } if(canExecute){ JSONObject t=new JSONObject(); t.put("mode","NORMAL"); t.put("action","OPEN"); t.put("symbol",s.symbol); t.put("volume",0.01); t.put("sl",s.sl); t.put("tp",s.tp); JSONObject r=bridge.trade(t); final String q=r.optString("status",r.optString("accepted","QUEUED")); runOnUiThread(()->{topStatus.setText("NORMAL AUTO  •  DEMO ORDER QUEUED  •  "+sym);Toast.makeText(this,"Real MT5 demo order queued: "+q,Toast.LENGTH_LONG).show();}); } else runOnUiThread(()->{topStatus.setText("NORMAL AUTO  •  SIGNAL READY  •  "+sym);Toast.makeText(this,"Signal ready. Connect the Demo MT5 Bridge to enable execution.",Toast.LENGTH_LONG).show();});}else runOnUiThread(()->topStatus.setText("NORMAL AUTO  •  WAIT  •  "+sym));}catch(Exception e){runOnUiThread(()->topStatus.setText("NORMAL AUTO  •  DATA ERROR"));}});}
  private List<StrategyEngine.Candle> list(org.json.JSONArray a){List<StrategyEngine.Candle> r=new ArrayList<>();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null)r.add(new StrategyEngine.Candle(a.optJSONObject(i)));return r;}
  private String format(StrategyEngine.Signal s){return "🚨 C.P.D SUPER WIZARD AI\n\n"+s.symbol+"  •  "+(s.dir>0?"BUY":"SELL")+"\n\nEntry  "+fmt(s.entry)+"\nSL     "+fmt(s.sl)+"\nTP1    "+fmt(s.tp1)+"\nTP2    "+fmt(s.tp2)+"\nTP3    "+fmt(s.tp3)+"\nFinal  "+fmt(s.tp)+"\n\nConfidence  "+String.format(Locale.US,"%.0f/95",s.confidence)+"\nMode  NORMAL\n\nPattern: "+s.pattern+" ("+s.patternQuality+")\nS/R: "+s.sr+" ("+s.srQuality+")\nBreakout: "+s.breakout+"\n"+s.reason+"\n\nRisk-managed execution only.";}
  private void copySignal(){if(lastNormalSignal==null){Toast.makeText(this,"No Normal signal to copy.",Toast.LENGTH_SHORT).show();return;}((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("CPD Signal",format(lastNormalSignal)));Toast.makeText(this,"Signal copied.",Toast.LENGTH_SHORT).show();}
  private String fmt(double x){return String.format(Locale.US,"%.5f",x);}
  @Override protected void onResume(){super.onResume();bridgeHandler.post(bridgeRefresh);}
  @Override protected void onPause(){bridgeHandler.removeCallbacks(bridgeRefresh);super.onPause();}
  @Override protected void onDestroy(){bridgeHandler.removeCallbacks(bridgeRefresh);io.shutdownNow();super.onDestroy();}
}
