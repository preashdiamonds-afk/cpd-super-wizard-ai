import os, json, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

TOKEN=os.environ.get('CPD_BRIDGE_TOKEN','CHANGE_ME_CPD_DEMO_TOKEN')
PORT=int(os.environ.get('PORT','10000'))
STATE={'accounts':{},'commands':{},'results':{}}

def key(login,server): return f'{login}|{server}'
def auth(h): return h.get('Authorization','') == 'Bearer '+TOKEN

def send(h,code,obj,ctype='application/json'):
    raw=obj if isinstance(obj,bytes) else (obj if isinstance(obj,str) else json.dumps(obj,separators=(',',':')))
    if isinstance(raw,str): raw=raw.encode()
    h.send_response(code); h.send_header('Content-Type',ctype); h.send_header('Access-Control-Allow-Origin','*'); h.send_header('Access-Control-Allow-Headers','Content-Type, Authorization'); h.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS'); h.end_headers(); h.wfile.write(raw)

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_OPTIONS(self): send(self,204,b'')
    def read(self):
        n=int(self.headers.get('Content-Length','0')); return self.rfile.read(n) if n else b''
    def postjson(self):
        try:return json.loads(self.read() or b'{}')
        except:return {}
    def do_GET(self):
        u=urlparse(self.path); p=u.path; q=parse_qs(u.query)
        if p=='/health': return send(self,200,{'ok':True,'service':'CPD MT5 Bridge','version':'7.0','time':int(time.time())})
        if p=='/mt5/poll':
            if q.get('token',[''])[0]!=TOKEN:return send(self,401,{'error':'unauthorized'})
            k=key(q.get('login',[''])[0],q.get('server',[''])[0]); cmds=STATE['commands'].get(k,[]); STATE['commands'][k]=[]
            lines=[]
            for c in cmds:
                lines.append('|'.join([c['id'],c['action'],c['mode'],c.get('symbol',''),str(c.get('volume',0)),str(c.get('sl',0)),str(c.get('tp',0)),str(c.get('ticket',0))]))
            return send(self,200,'\n'.join(lines),'text/plain')
        return send(self,404,{'error':'not found'})
    def do_POST(self):
        u=urlparse(self.path); p=u.path
        if p.startswith('/mt5/'):
            if not auth(self.headers): return send(self,401,{'error':'unauthorized'})
            data=self.postjson(); k=key(str(data.get('login','')),str(data.get('server','')))
            if p=='/mt5/heartbeat':
                acc=data.get('account',{}); acc['updated']=int(time.time()); STATE['accounts'][k]=acc; return send(self,200,{'ok':True})
            if p=='/mt5/snapshot':
                a=STATE['accounts'].setdefault(k,{}); a.update({x:data.get(x) for x in ('account','positions','ticks','specs') if x in data}); a['updated']=int(time.time()); return send(self,200,{'ok':True})
            if p=='/mt5/report':
                STATE['results'][data.get('id','')]=data; return send(self,200,{'ok':True})
        if not auth(self.headers): return send(self,401,{'error':'unauthorized'})
        data=self.postjson(); login=str(data.get('login','')); server=str(data.get('server','')); k=key(login,server); a=STATE['accounts'].get(k,{})
        if p=='/account':
            acc=a.get('account',a); acc=dict(acc) if isinstance(acc,dict) else {}; acc['bridge_updated']=a.get('updated',0); return send(self,200,acc)
        if p=='/performance':
            acc=a.get('account',{}); return send(self,200,acc.get('stats',{}))
        if p=='/positions': return send(self,200,{'data':a.get('positions',[])})
        if p=='/candles': return send(self,200,{'data':a.get('candles',{}).get(str(data.get('symbol'))+'|'+str(data.get('timeframe')),[])})
        if p=='/tick': return send(self,200,a.get('ticks',{}).get(str(data.get('symbol')),{}))
        if p=='/spec': return send(self,200,a.get('specs',{}).get(str(data.get('symbol')),{}))
        if p=='/trade':
            # Hard safety gate: only a heartbeat explicitly identifying a DEMO account may receive commands.
            if str(a.get('account',{}).get('mode',a.get('mode',''))).upper() not in ('DEMO','ACCOUNT_TRADE_MODE_DEMO'):
                return send(self,403,{'error':'LIVE_LOCKED_OR_ACCOUNT_NOT_VERIFIED'})
            cmd={'id':uuid.uuid4().hex,'action':str(data.get('action','OPEN')).upper(),'mode':str(data.get('mode','NORMAL')).upper(),'symbol':data.get('symbol',''),'volume':float(data.get('volume',0.01)),'sl':float(data.get('sl',0)),'tp':float(data.get('tp',0)),'ticket':int(data.get('ticket',0)),'created':int(time.time())}
            STATE['commands'].setdefault(k,[]).append(cmd); return send(self,202,{'accepted':True,'command_id':cmd['id'],'status':'QUEUED'})
        return send(self,404,{'error':'not found'})

ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
