# C.P.D SUPER WIZARD AI — V1.9 CONSOLIDATED SIGNAL ENGINE

**Manual execution only.** The app scans automatically, generates C.P.D signals and notifications, and shows Entry/SL/TP levels. The user manually places any trade in Exness MT5. The app never sends an automatic order.

## Strategy engine now consolidated
The phone and cloud scanners use the same V10.35-style confluence structure:

- H4 + H1 trend alignment.
- M15 market structure / BOS.
- Liquidity sweep and reclaim.
- Displacement confirmation.
- M15 momentum.
- M5 trigger confirmation.
- 95-point confluence score: 20 + 20 + 15 + 15 + 5 + 10 + 10.
- Normal quality gate: 85/95.
- Aggressive gate remains available internally, but manual execution is still required.

## Pattern intelligence
The engine now checks for:

- Bullish / Bearish Engulfing.
- Hammer / Shooting Star.
- Double Top / Double Bottom with neckline confirmation.
- Head & Shoulders / Inverse Head & Shoulders with neckline confirmation.
- Bullish / Bearish consolidation breakout.
- TRUE breakout versus FALSE breakout / liquidity sweep classification.

A pattern is not accepted simply because its shape appears. The engine requires directional confirmation before using it as the 10-point pattern component.

## Support / resistance intelligence
The engine now classifies nearby levels as:

- STRONG Support / Resistance: clustered pivot evidence, multiple touches and meaningful reaction.
- WEAK Support / Resistance: a single or weaker nearby level.
- Opposing levels can reject a setup instead of being treated as confirmation.

For quality, a normal signal needs a confirmed chart pattern or STRONG S/R confirmation in addition to the core gates. This deliberately reduces low-quality alerts.

## Signal levels
The signal displays:

- Entry
- Stop Loss
- TP1 = 0.80R
- TP2 = 1.60R
- TP3 = 2.60R
- TP4 = 4.00R
- Final = 6.00R

The signal UI also shows the detected pattern, pattern quality, S/R strength and breakout classification.

## Two-minute warning
A qualified setup first becomes **C.P.D SIGNAL INCOMING**. The phone then publishes it after the two-minute confirmation window. Cloud signals include `publish_at`; the phone can complete the two-minute transition locally when it reconnects, rather than waiting for the next scheduled cloud run.

## Market data
- Phone scanner: public market data plus TradingView cross-check and VIX/context checks.
- Cloud scanner: Twelve Data candles for the scheduled quality scan.
- Quotes can differ from Exness. Always verify the displayed entry and spread in Exness MT5 before manual execution.

No Exness password, broker secret or Telegram credential is stored in this project.

## Cloud scanner
The cloud worker is designed for scheduled phone-off scanning through GitHub Actions. The scheduled workflow should extract this project ZIP before running `cloud/signal_worker.py` and should commit `cloud/signals.json` at the repository root so the Android app can read the public signal state.

Scheduled cloud jobs can be delayed or disabled by the platform. This is not a broker-grade execution server.

## Accuracy and safety
The 95/95 number is a **confluence score, not a 95% win probability**. No trading algorithm can guarantee accuracy or profit. Use demo testing, real-tick/backtest validation, out-of-sample testing, and manual verification of spread/news conditions before risking funds.

Telegram automatic publishing is intentionally **not included**.
