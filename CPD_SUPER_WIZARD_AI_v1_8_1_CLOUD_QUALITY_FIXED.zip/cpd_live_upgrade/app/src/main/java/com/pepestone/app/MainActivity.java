package com.pepestone.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** C.P.D SUPER WIZARD AI — Manual mobile signal center. Automatic mode stays locked. */
public class MainActivity extends Activity {
  EditText symbol, entry, stopLoss, takeProfit, confidence, notes;
  Spinner direction;
  TextView signal, activityLog, modeStatus, autoStatus, incomingBanner, weeklyStats, scannerStatus, cloudStatus, cloudHistory;
  Button savePlan, clearPlan, alertButton, manualModeButton, automaticModeButton, copySignal, tp1Button, tp2Button, slButton, weeklyReportButton;
  LinearLayout welcomeScreen, mainScreen, signalActions;
  SignalChartView chart;
  NotificationHelper notifications;
  SignalScheduler scheduler;
  SignalStore store;
  String activeId="";
  StrategyEngine.Signal activeSignal;
  CountDownTimer countdown;
  final android.os.Handler scannerUiHandler=new android.os.Handler(android.os.Looper.getMainLooper());
  final Runnable scannerUiTick=new Runnable(){ public void run(){ refreshScannerState(); scannerUiHandler.postDelayed(this,1500); } };
  String lastScannerSignalKey="";
  CloudSignalClient cloudClient=new CloudSignalClient(); TextToSpeech tts; String lastCloudKey="";

  @Override public void onCreate(Bundle b) {
    super.onCreate(b); setContentView(R.layout.activity_main);
    notifications=new NotificationHelper(this); scheduler=new SignalScheduler(); store=new SignalStore(this); bind();
    tts=new TextToSpeech(this, status -> { if(status==TextToSpeech.SUCCESS){ tts.setLanguage(Locale.US); tts.speak("Welcome Captain Preash. Super Wizard AI is scanning the market for good setups.", TextToSpeech.QUEUE_FLUSH, null, "cpd_welcome"); }});
    if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);
    enterSystem(); refreshStats(); WeeklyReportScheduler.schedule(this); startScanner(); scannerUiHandler.post(scannerUiTick); pollCloud();
    savePlan.setVisibility(View.GONE); alertButton.setVisibility(View.GONE); clearPlan.setVisibility(View.GONE); symbol.setVisibility(View.GONE); direction.setVisibility(View.GONE); entry.setVisibility(View.GONE); stopLoss.setVisibility(View.GONE); takeProfit.setVisibility(View.GONE); confidence.setVisibility(View.GONE); notes.setVisibility(View.GONE); findViewById(R.id.enterSystem).setOnClickListener(v->{welcomeScreen.setVisibility(View.GONE);mainScreen.setVisibility(View.VISIBLE);log("Trading dashboard opened.");});
    savePlan.setOnClickListener(v->queueManualSignal());
    clearPlan.setOnClickListener(v->clearForm());
    alertButton.setOnClickListener(v->queueManualSignal());
    copySignal.setOnClickListener(v->copyCurrentSignal());
    weeklyReportButton.setOnClickListener(v->{int[] x=store.weekStats();notifications.notifyWeekly(x[0],x[1],x[2],store.winRate());});
    tp1Button.setOnClickListener(v->mark("TP1","TP1 = 0.80R. Bank the planned first portion and protect at ENTRY (0R)."));
    tp2Button.setOnClickListener(v->mark("TP2","TP2 = 1.60R. Bank the planned second portion and protect at TP1 (0.80R)."));
    slButton.setOnClickListener(v->mark("SL","The planned stop was reached. Record the loss and wait for the next confirmed setup."));
    manualModeButton.setOnClickListener(v->activateManualMode()); automaticModeButton.setOnClickListener(v->showAutomaticLocked());
  }
  private void bind(){
    welcomeScreen=findViewById(R.id.welcomeScreen);mainScreen=findViewById(R.id.mainScreen);cloudStatus=findViewById(R.id.cloudStatus);cloudHistory=findViewById(R.id.cloudHistory);symbol=findViewById(R.id.symbol);entry=findViewById(R.id.entry);stopLoss=findViewById(R.id.stopLoss);takeProfit=findViewById(R.id.takeProfit);confidence=findViewById(R.id.confidence);notes=findViewById(R.id.notes);direction=findViewById(R.id.direction);signal=findViewById(R.id.signal);activityLog=findViewById(R.id.activityLog);modeStatus=findViewById(R.id.modeStatus);autoStatus=findViewById(R.id.autoStatus);incomingBanner=findViewById(R.id.incomingBanner);weeklyStats=findViewById(R.id.weeklyStats);manualModeButton=findViewById(R.id.manualModeButton);automaticModeButton=findViewById(R.id.automaticModeButton);savePlan=findViewById(R.id.savePlan);clearPlan=findViewById(R.id.clearPlan);alertButton=findViewById(R.id.alertButton);copySignal=findViewById(R.id.copySignal);tp1Button=findViewById(R.id.tp1Button);tp2Button=findViewById(R.id.tp2Button);slButton=findViewById(R.id.slButton);signalActions=findViewById(R.id.signalActions);chart=findViewById(R.id.signalChart);weeklyReportButton=findViewById(R.id.weeklyReportButton);scannerStatus=findViewById(R.id.scannerStatus);
  }

  private void pollCloud(){
    cloudClient.fetch(new CloudSignalClient.Callback(){
      public void ok(org.json.JSONObject j){ runOnUiThread(()->applyCloud(j)); }
      public void error(String e){ runOnUiThread(()->{ if(cloudStatus!=null) cloudStatus.setText("● CLOUD SCANNER • OFFLINE / WAITING FOR DATA"); }); }
    });
    scannerUiHandler.postDelayed(this::pollCloud,60000);
  }
  private void applyCloud(org.json.JSONObject j){
    String st=j.optString("status","C.P.D CLOUD SCANNER • ONLINE"); org.json.JSONObject active=j.optJSONObject("active"); if(active!=null && "INCOMING".equals(active.optString("status"))){try{long p=java.time.Instant.parse(active.optString("publish_at")).toEpochMilli(); if(System.currentTimeMillis()>=p){st="SIGNAL PUBLISHED • MANUAL EXECUTION"; active.put("status","PUBLISHED");}}catch(Exception ignored){}} if(cloudStatus!=null) cloudStatus.setText("● "+st);
    if(scannerStatus!=null) scannerStatus.setText("Market feed: "+j.optString("market_data","cloud")+" • Last cloud update: "+j.optString("updated_at","—"));
    StrategyEngine.Signal s=CloudSignalClient.signal(j); String state=CloudSignalClient.activeStatus(j);
    if(s!=null){
      String key=s.symbol+"|"+s.dir+"|"+String.format(Locale.US,"%.5f",s.entry)+"|"+state;
      activeSignal=s; activeId="cloud_"+key; chart.setSignal(s);
      if(!key.equals(lastCloudKey)){lastCloudKey=key; log("Cloud signal sync: "+s.symbol+" "+(s.dir>0?"BUY":"SELL")+" • "+String.format(Locale.US,"%.0f/95",s.confidence)+" • "+state);}
      signal.setText(formatCloudSignal(j,s,state));
      incomingBanner.setVisibility("INCOMING".equals(state)?View.VISIBLE:View.GONE);
      if("INCOMING".equals(state)){ long p=0; try{p=java.time.Instant.parse(j.getJSONObject("active").optString("publish_at")).toEpochMilli();}catch(Exception ignored){} long left=Math.max(0,p-System.currentTimeMillis()); incomingBanner.setText("✦ C.P.D SIGNAL INCOMING ✦\nPublishing in "+String.format(Locale.US,"%02d:%02d",left/60000,(left/1000)%60)); }
      else { incomingBanner.setText("✓ SIGNAL PUBLISHED • MANUAL EXECUTION"); incomingBanner.setVisibility(View.VISIBLE); }
      signalActions.setVisibility("PUBLISHED".equals(state)?View.VISIBLE:View.GONE);
    } else { signal.setText("No confirmed signal yet.\n\nThe cloud scanner is waiting for a qualified C.P.D setup."); signalActions.setVisibility(View.GONE); }
    cloudHistory.setText(formatHistory(j));
  }
  private String formatCloudSignal(org.json.JSONObject j, StrategyEngine.Signal s, String state){
    org.json.JSONObject a=j.optJSONObject("active"); String d=s.dir>0?"BUY":"SELL"; String tp1="—",tp2="—",tp3="—",tp4="—"; if(a!=null){tp1=fmt(a.optDouble("tp1"));tp2=fmt(a.optDouble("tp2"));tp3=fmt(a.optDouble("tp3"));tp4=fmt(a.optDouble("tp4"));}
    return "C.P.D SUPER WIZARD AI\n"+state+" • "+d+" • "+s.symbol+"\n\nENTRY   "+fmt(s.entry)+"\nSL      "+fmt(s.sl)+"\nTP1 0.80R  "+tp1+"\nTP2 1.60R  "+tp2+"\nTP3 2.60R  "+tp3+"\nTP4 4.00R  "+tp4+"\nFINAL 6.00R  "+fmt(s.tp)+"\n\nCONFIDENCE  "+String.format(Locale.US,"%.0f/95",s.confidence)+"\nPATTERN: "+s.pattern+" ["+s.patternQuality+"]\nS/R: "+s.sr+" ["+s.srQuality+"]\nBREAKOUT: "+s.breakout+"\n\n"+s.reason+"\n\nMANUAL MODE • NO AUTO EXECUTION";
  }
  private String formatHistory(org.json.JSONObject j){ org.json.JSONArray h=j.optJSONArray("history"); if(h==null||h.length()==0)return "No completed cloud signals yet."; StringBuilder b=new StringBuilder(); int n=Math.min(8,h.length()); for(int i=0;i<n;i++){org.json.JSONObject a=h.optJSONObject(i);if(a==null)continue;b.append(a.optString("symbol")).append(" • ").append(a.optString("direction")).append(" • ").append(a.optString("status")).append(" • ").append(a.optString("confidence")).append("/95\n");} return b.toString().trim(); }

  private void startScanner(){ try { Intent i=new Intent(this,TradingService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); log("C.P.D automatic signal scanner started. Manual trade execution only."); } catch(Exception e){ log("Scanner start error: "+e.getMessage()); } }
  private void enterSystem(){welcomeScreen.setVisibility(View.VISIBLE);mainScreen.setVisibility(View.GONE);activateManualMode();}
  private void activateManualMode(){modeStatus.setText("● MANUAL MODE • ACTIVE");autoStatus.setText("MANUAL MODE • ACTIVE");autoStatus.setTextColor(0xFF7EE787);manualModeButton.setText("MANUAL MODE ✓");automaticModeButton.setText("AUTOMATIC MODE 🔒");}
  private void showAutomaticLocked(){autoStatus.setText("AUTOMATIC MODE • LOCKED / COMING LATER");autoStatus.setTextColor(0xFFFFD166);Toast.makeText(this,"Automatic mode is present but locked. It cannot place trades in this version.",Toast.LENGTH_LONG).show();log("Automatic mode selected — locked.");activateManualMode();}


  private void refreshScannerState(){
    try{
      ScannerStateStore ss=new ScannerStateStore(this);
      String st=ss.status();
      if(scannerStatus!=null) scannerStatus.setText(st);
      if(!ss.hasSignal()) return;
      StrategyEngine.Signal sig=ss.signal(); if(sig==null||sig.symbol==null||sig.symbol.isEmpty()) return;
      String key=sig.symbol+"|"+sig.dir+"|"+String.format(Locale.US,"%.5f",sig.entry);
      if(!key.equals(lastScannerSignalKey)){
        lastScannerSignalKey=key; activeSignal=sig; activeId="auto_"+ss.publishAt(); chart.setSignal(sig);
        log("Auto scanner detected "+sig.symbol+" "+(sig.dir>0?"BUY":"SELL")+" • "+String.format(Locale.US,"%.0f/95",sig.confidence)+".");
      }
      if(!ss.isPublished()){
        long left=Math.max(0,ss.publishAt()-System.currentTimeMillis());
        incomingBanner.setText("✦  C.P.D SIGNAL INCOMING  ✦\nConfirmation watch active • publishing in "+String.format(Locale.US,"%02d:%02d",left/60000,(left/1000)%60));
        incomingBanner.setVisibility(View.VISIBLE); signalActions.setVisibility(View.GONE); signal.setText("CONFIRMATION PENDING\n"+formatSignal(sig));
      }else{
        incomingBanner.setText("✓  SIGNAL CONFIRMED & PUBLISHED  ✓"); incomingBanner.setVisibility(View.VISIBLE); signal.setText(formatSignal(sig)); signalActions.setVisibility(View.VISIBLE);
      }
    }catch(Exception ignored){}
  }

  private void queueManualSignal(){
    String s=symbol.getText().toString().trim().toUpperCase(Locale.US), e=entry.getText().toString().trim(), sl=stopLoss.getText().toString().trim();
    if(s.isEmpty()||e.isEmpty()||sl.isEmpty()){toast("Enter symbol, entry and stop loss first.");return;}
    double ep,sp,score=0; try{ep=Double.parseDouble(e);sp=Double.parseDouble(sl);if(!confidence.getText().toString().trim().isEmpty())score=Double.parseDouble(confidence.getText().toString().trim());}catch(Exception ex){toast("Check the numeric fields.");return;}
    if(ep<=0||sp<=0||score<0||score>95){toast("Confidence must be 0–95.");return;}
    boolean buy="BUY".equalsIgnoreCase(direction.getSelectedItem().toString());
    StrategyEngine.Signal sig=new StrategyEngine.Signal(s);sig.valid=true;sig.dir=buy?1:-1;sig.entry=ep;sig.sl=sp;sig.confidence=score;sig.reason=notes.getText().toString().trim().isEmpty()?"Manual confirmation / setup reason not entered.":notes.getText().toString().trim();double r=Math.abs(ep-sp);double finalTp=0;try{if(!takeProfit.getText().toString().trim().isEmpty())finalTp=Double.parseDouble(takeProfit.getText().toString().trim());}catch(Exception ignored){}sig.tp=finalTp>0?finalTp:(buy?ep+6*r:ep-6*r);
    activeSignal=sig; activeId="sig_"+System.currentTimeMillis();
    chart.setSignal(sig); incomingBanner.setText("✦  C.P.D SIGNAL INCOMING  ✦\nConfirmation watch active • publishing in 02:00");incomingBanner.setVisibility(View.VISIBLE);signal.setText("CONFIRMATION PENDING\n"+formatSignal(sig));signalActions.setVisibility(View.GONE);log("Strong setup queued. C.P.D Signal Incoming warning sent; publication delayed 2 minutes.");notifications.notifyIncoming(sig);toast("C.P.D Signal Incoming — check the chart. Publishing in 2 minutes.");
    if(countdown!=null)countdown.cancel();
    countdown=new CountDownTimer(120000,1000){public void onTick(long ms){incomingBanner.setText("✦  C.P.D SIGNAL INCOMING  ✦\nConfirmation watch active • publishing in "+String.format(Locale.US,"%02d:%02d",ms/60000,(ms/1000)%60));}public void onFinish(){publishSignal(sig);}};
    countdown.start();
  }
  private void publishSignal(StrategyEngine.Signal sig){
    store.record(activeId,sig.symbol,sig.dir>0?"BUY":"SELL",sig.confidence,System.currentTimeMillis());
    incomingBanner.setText("✓  SIGNAL CONFIRMED & PUBLISHED  ✓");incomingBanner.setVisibility(View.VISIBLE);signal.setText(formatSignal(sig));signalActions.setVisibility(View.VISIBLE);notifications.notifySignal(sig);log("Manual signal published: "+sig.symbol+" "+(sig.dir>0?"BUY":"SELL")+".");refreshStats();
  }
  private String formatSignal(StrategyEngine.Signal s){
    double r=Math.abs(s.entry-s.sl);double tp1=s.dir>0?s.entry+0.8*r:s.entry-0.8*r,tp2=s.dir>0?s.entry+1.6*r:s.entry-1.6*r,tp3=s.dir>0?s.entry+2.6*r:s.entry-2.6*r;
    String side=s.dir>0?"BUY":"SELL";String reason=s.reason==null?"":s.reason;
    return "C.P.D SUPER WIZARD AI\n"+side+" • "+s.symbol+"\n\nENTRY  "+fmt(s.entry)+"\nSL      "+fmt(s.sl)+"\nTP1 0.80R  "+fmt(tp1)+"\nTP2 1.60R  "+fmt(tp2)+"\nTP3 2.60R  "+fmt(tp3)+"\nFINAL 6.00R  "+fmt(s.tp)+"\n\nCONFIDENCE  "+String.format(Locale.US,"%.0f/95",s.confidence)+"\nPATTERN: "+s.pattern+" ["+s.patternQuality+"]\nS/R: "+s.sr+" ["+s.srQuality+"]\nBREAKOUT: "+s.breakout+"\nREASON\n"+reason+"\n\nMANUAL MODE • NO AUTO EXECUTION";
  }
  private void copyCurrentSignal(){String t=signal.getText().toString();if(t.trim().isEmpty())return;ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("C.P.D Signal",t));toast("Signal copied. Paste it anywhere.");log("Signal copied to clipboard.");}
  private void mark(String result,String instruction){if(activeId.isEmpty()){toast("Publish a signal first.");return;}store.outcome(activeId,result);notifications.notifyMilestone(activeSignal==null?symbol.getText().toString():activeSignal.symbol,result,instruction);log("Trade update recorded: "+result+". "+instruction);refreshStats();}
  private void refreshStats(){int[] s=store.weekStats();weeklyStats.setText(String.format(Locale.US,"THIS WEEK • Signals %d  |  Wins %d  |  Losses %d  |  Win rate %.1f%%",s[0],s[1],s[2],store.winRate()));}
  private void clearForm(){scheduler.cancel();if(countdown!=null)countdown.cancel();symbol.setText("");entry.setText("");stopLoss.setText("");takeProfit.setText("");confidence.setText("");notes.setText("");signal.setText("No signal prepared yet.");incomingBanner.setVisibility(View.GONE);signalActions.setVisibility(View.GONE);chart.clear();activeId="";activeSignal=null;log("Signal planner cleared.");}
  private String fmt(double x){return String.format(Locale.US,"%.5f",x);}
  private void log(String s){String t=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date());activityLog.append("["+t+"] "+s+"\n");}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
  @Override protected void onDestroy(){scheduler.cancel();if(countdown!=null)countdown.cancel();scannerUiHandler.removeCallbacks(scannerUiTick); if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy();}
}
