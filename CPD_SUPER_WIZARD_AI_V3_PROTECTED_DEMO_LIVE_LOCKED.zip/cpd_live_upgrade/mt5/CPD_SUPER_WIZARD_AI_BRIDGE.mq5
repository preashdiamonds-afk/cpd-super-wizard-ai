#property strict
#property version "3.0"
#property description "C.P.D SUPER WIZARD AI — protected MT5 bridge (DEMO enabled, LIVE locked)"

// Broker-side execution boundary for C.P.D SUPER WIZARD AI.
// DEMO execution may be enabled only after the command transport is implemented
// and authenticated. LIVE execution is deliberately locked in this release.

input string CPD_Command_URL = "";
input int PollSeconds = 2;
input bool AllowDemoAuto = false;
input bool AllowNormalAuto = false;
input bool AllowAggressiveAuto = false;
input bool LiveTradingLocked = true;

bool IsRealAccount(){ return (ENUM_ACCOUNT_TRADE_MODE)AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_REAL; }

bool CanExecute(const string requestedMode){
   if(IsRealAccount()){
      Print("CPD SAFETY: LIVE account detected. Live execution is LOCKED in this build.");
      return false;
   }
   if(!AllowDemoAuto){
      Print("CPD SAFETY: Demo execution is disabled until the authenticated command bridge is configured.");
      return false;
   }
   if(requestedMode=="NORMAL" && !AllowNormalAuto) return false;
   if(requestedMode=="AGGRESSIVE" && !AllowAggressiveAuto) return false;
   return true;
}

int OnInit(){
   EventSetTimer(MathMax(1,PollSeconds));
   if(IsRealAccount()) Print("C.P.D: REAL ACCOUNT detected — LIVE LOCK ACTIVE.");
   else Print("C.P.D: DEMO account detected — execution requires explicit demo bridge configuration.");
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ EventKillTimer(); }

void OnTimer(){
   // The transport contract remains intentionally explicit. The Android app is the
   // command center; MT5 is the execution terminal. Do not infer or invent commands.
   // Before processing an order payload, a production bridge must:
   // 1) authenticate the request;
   // 2) verify the account type;
   // 3) reject REAL accounts while LiveTradingLocked is true;
   // 4) validate symbol, volume, SL/TP, spread and risk limits;
   // 5) de-duplicate by command/trade ID;
   // 6) report the actual MT5 result back to the command center.
   if(IsRealAccount() && LiveTradingLocked) return;
}
