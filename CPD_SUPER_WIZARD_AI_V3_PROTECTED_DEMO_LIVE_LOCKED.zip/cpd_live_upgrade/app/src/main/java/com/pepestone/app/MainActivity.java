package com.pepestone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

/** C.P.D SUPER WIZARD AI — V3 protected account-mode command center. */
public class MainActivity extends Activity {
  private final String[] PAIRS={"EURUSD","GBPUSD","USDJPY","GBPJPY","AUDUSD","USDCAD","USDCHF","AUDJPY","AUDCAD","AUDCHF","XAUUSD"};
  private LinearLayout root,content; private TextView title,status,signal,scannerResult,visualInfo,accountInfo,modeBadge;
  private Spinner pairSpinner; private Button normalBtn,aggressiveBtn,copyBtn,scanBtn,uploadBtn;
  private Bitmap uploadedChart; private StrategyEngine.Signal lastNormalSignal;
  private final PublicMarketDataClient market=new PublicMarketDataClient();
  private boolean normalOn=false, aggressiveOn=false;
  private final ExecutorService io=Executors.newSingleThreadExecutor();

  @Override public void onCreate(Bundle b){
    super.onCreate(b); getWindow().setStatusBarColor(bg()); getWindow().setNavigationBarColor(bg());
    build(); welcome();
    if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);
  }

  private int gold(){return Color.rgb(244,194,76);} private int bg(){return Color.rgb(6,8,12);} private int card(){return Color.rgb(17,21,29);} private int white(){return Color.rgb(242,246,252);} private int muted(){return Color.rgb(154,164,178);} private int green(){return Color.rgb(71,211,133);} private int red(){return Color.rgb(255,102,112);} private int blue(){return Color.rgb(85,170,255);}
  private TextView tv(String text,float size,int color){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,2,0,2);return v;}
  private GradientDrawable gd(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);g.setStroke(1,Color.rgb(47,54,65));return g;}
  private LinearLayout cardLayout(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,16,18,16);c.setBackground(gd(card(),22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,10,0,0);c.setLayoutParams(p);return c;}
  private Button btn(String text){Button b=new Button(this);b.setText(text);b.setTextColor(bg());b.setTextSize(12);b.setAllCaps(false);b.setTypeface(null,1);b.setBackground(gd(gold(),18));b.setPadding(10,0,10,0);return b;}
  private Button darkBtn(String text){Button b=btn(text);b.setTextColor(white());b.setBackground(gd(Color.rgb(24,29,38),18));return b;}

  private void build(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg());setContentView(root);
    LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.VERTICAL);top.setPadding(20,18,20,12);top.setBackgroundColor(Color.rgb(10,13,19));
    title=tv("✦ C.P.D SUPER WIZARD AI ✦",22,gold());title.setTypeface(null,1);top.addView(title);
    status=tv("READY • DEMO UNLOCKED • LIVE LOCKED",12,green());status.setPadding(0,5,0,0);top.addView(status);root.addView(top,new LinearLayout.LayoutParams(-1,-2));
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(14,4,14,90);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=new LinearLayout(this);nav.setPadding(8,8,8,8);nav.setBackgroundColor(Color.rgb(12,15,21));String[] tabs={"HOME","AUTO","MANUAL","CPD SCANNER"};for(String t:tabs){Button b=darkBtn(t);b.setOnClickListener(v->showTab(t));nav.addView(b,new LinearLayout.LayoutParams(0,52,1));}root.addView(nav,new LinearLayout.LayoutParams(-1,68));showTab("HOME");
  }

  private void welcome(){new Handler().postDelayed(()->Toast.makeText(this,"WELCOME, CAPTAIN PREASH DIAMOND",Toast.LENGTH_LONG).show(),350);}
  private void showTab(String tab){content.removeAllViews(); if("AUTO".equals(tab))autoTab();else if("MANUAL".equals(tab))manualTab();else if("CPD SCANNER".equals(tab))scannerTab();else homeTab();}

  private void homeTab(){
    LinearLayout hero=cardLayout();hero.addView(tv("WELCOME, CAPTAIN PREASH DIAMOND",20,gold()));hero.addView(tv("Advanced multi-engine trading command center",13,muted()));content.addView(hero);
    accountModeCard();
    LinearLayout a=cardLayout();a.addView(tv("MT5 CONNECTION",15,gold()));accountInfo=tv("STATUS: BRIDGE READY FOR CONFIGURATION\nAccount: —\nBalance: —\nEquity: —\nOpen positions: —",14,white());accountInfo.setPadding(0,10,0,10);a.addView(accountInfo);Button setup=btn("BROKER / MT5 CONNECTION");setup.setOnClickListener(v->Toast.makeText(this,"The Android app uses an MT5-side CPD Bridge. Broker credentials should remain in the MT5 terminal/bridge; the app does not pretend the mobile MT5 client is an EA host.",Toast.LENGTH_LONG).show());a.addView(setup,new LinearLayout.LayoutParams(-1,48));content.addView(a);
    LinearLayout p=cardLayout();p.addView(tv("C.P.D ANALYSIS PAIRS",15,gold()));p.addView(tv("Watchlist used by the Normal Auto and Scanner engines.",12,muted()));for(String x:PAIRS)p.addView(tv("• "+x,13,white()));content.addView(p);
    LinearLayout e=cardLayout();e.addView(tv("MULTI-ENGINE INTELLIGENCE",15,gold()));e.addView(tv("Market Structure • Pattern • Strong/Weak S/R • Liquidity • Momentum • Breakout/Fakeout • MTF • Risk Validation",13,white()));content.addView(e);
    LinearLayout about=cardLayout();about.addView(tv("ABOUT C.P.D SUPER WIZARD AI",15,gold()));about.addView(tv("Normal Auto generates the Normal Signal Center feed. Aggressive Auto is a separate engine. CPD Scanner combines uploaded-chart visual context with available M5/M15/H1/H4 market data. The final engine can return WAIT when evidence is incomplete or conflicting. Confidence is a confluence score, not a promise of profit.",13,white()));content.addView(about);
  }

  private void accountModeCard(){
    LinearLayout m=cardLayout();m.addView(tv("ACCOUNT MODE",15,gold()));
    modeBadge=tv("🟢  DEMO ACCOUNT  •  UNLOCKED",15,green());modeBadge.setPadding(0,8,0,8);m.addView(modeBadge);
    TextView live=tv("🔒  LIVE ACCOUNT  •  LOCKED\n\nReal-money order execution is disabled by default. The lock is enforced in the MT5 bridge as well as the app UI. Live unlock is intentionally not automatic.",14,white());live.setPadding(0,4,0,10);m.addView(live);
    Button locked=darkBtn("🔒 LIVE TRADING LOCKED");locked.setOnClickListener(v->showLiveLockInfo());m.addView(locked,new LinearLayout.LayoutParams(-1,50));
    TextView note=tv("Demo testing can use the same strategy architecture. A real account can be detected and displayed, but no live order should pass while the lock is active.",11,muted());note.setPadding(0,9,0,0);m.addView(note);content.addView(m);
  }

  private void showLiveLockInfo(){
    new AlertDialog.Builder(this).setTitle("LIVE ACCOUNT LOCKED").setMessage("C.P.D SUPER WIZARD AI is currently in protected mode. Live trading cannot be enabled from this screen. The MT5 bridge must independently reject LIVE execution until a deliberate, separately configured live authorization is installed after demo testing.").setPositiveButton("KEEP LOCKED",null).show();
  }

  private void autoTab(){
    LinearLayout c=cardLayout();c.addView(tv("AUTO TRADING",19,gold()));c.addView(tv("DEMO execution path is the testing path. Live execution remains locked.",12,muted()));
    pairSpinner=new Spinner(this);pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS));c.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));
    normalBtn=btn("NORMAL AUTO • OFF");normalBtn.setOnClickListener(v->{normalOn=!normalOn;normalBtn.setText(normalOn?"NORMAL AUTO • ON":"NORMAL AUTO • OFF");status.setText(normalOn?"NORMAL AUTO • SCANNING DEMO PATH":"READY • NORMAL AUTO OFF • LIVE LOCKED");if(normalOn)scanNormal();});c.addView(normalBtn,new LinearLayout.LayoutParams(-1,52));
    aggressiveBtn=btn("AGGRESSIVE AUTO • OFF");aggressiveBtn.setOnClickListener(v->{aggressiveOn=!aggressiveOn;aggressiveBtn.setText(aggressiveOn?"AGGRESSIVE AUTO • ON":"AGGRESSIVE AUTO • OFF");Toast.makeText(this,"Aggressive Auto is isolated from the Normal Signal Center.",Toast.LENGTH_SHORT).show();});LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,52);ap.setMargins(0,8,0,0);c.addView(aggressiveBtn,ap);content.addView(c);
    LinearLayout q=cardLayout();q.addView(tv("NORMAL AUTO ENGINE",15,gold()));q.addView(tv("M5 + M15 + H1 + H4 confirmation • true/false pattern • strong/weak S/R • liquidity • displacement • breakout/fakeout • risk gate • WAIT when evidence conflicts.",13,white()));content.addView(q);
    LinearLayout ag=cardLayout();ag.addView(tv("AGGRESSIVE AUTO ENGINE",15,gold()));ag.addView(tv("Separate risk profile. It does not feed the Normal Manual Signal Center. The previously specified 5% high-water-mark equity protection belongs here when the broker-side execution module is enabled.",13,white()));content.addView(ag);
    LinearLayout warning=cardLayout();warning.addView(tv("EXECUTION ARCHITECTURE",15,gold()));warning.addView(tv("Android = command center. MT5 terminal + EA/bridge = broker execution layer. This build deliberately does not fake direct Android-to-Exness order execution.",12,muted()));content.addView(warning);
  }

  private void manualTab(){
    LinearLayout c=cardLayout();c.addView(tv("MANUAL • NORMAL SIGNAL CENTER",19,gold()));c.addView(tv("Only NORMAL AUTO signals appear here. Aggressive mode is isolated.",12,muted()));signal=tv(lastNormalSignal==null?"No Normal Auto signal yet.":format(lastNormalSignal),14,white());signal.setPadding(0,12,0,12);c.addView(signal);copyBtn=btn("📋 COPY NORMAL SIGNAL FOR TELEGRAM");copyBtn.setOnClickListener(v->copySignal());c.addView(copyBtn,new LinearLayout.LayoutParams(-1,52));content.addView(c);
    LinearLayout live=cardLayout();live.addView(tv("ACTUAL MT5 POSITION MIRROR",15,gold()));live.addView(tv("When the bridge reports an actual Normal Auto position, this panel is designed to mirror pair, BUY/SELL, entry, SL, TP, lot, confidence, reasons, P/L and status. It must never create a duplicate order.",13,white()));content.addView(live);
  }

  private void scannerTab(){
    LinearLayout c=cardLayout();c.addView(tv("CPD SCANNER",21,gold()));c.addView(tv("Upload a chart, choose its pair, then run multi-timeframe confirmation.",12,muted()));
    pairSpinner=new Spinner(this);pairSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,PAIRS));c.addView(pairSpinner,new LinearLayout.LayoutParams(-1,52));
    LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);uploadBtn=btn("UPLOAD CHART");scanBtn=btn("SCAN NOW");row.addView(uploadBtn,new LinearLayout.LayoutParams(0,52,1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,52,1);sp.setMargins(8,0,0,0);row.addView(scanBtn,sp);c.addView(row);
    visualInfo=tv("No screenshot attached.",12,muted());visualInfo.setPadding(0,10,0,0);c.addView(visualInfo);content.addView(c);
    LinearLayout r=cardLayout();r.addView(tv("SCAN RESULT",16,gold()));scannerResult=tv("Select a pair and run CPD Scanner.",14,white());scannerResult.setPadding(0,10,0,0);r.addView(scannerResult);content.addView(r);
    uploadBtn.setOnClickListener(v->pickImage());scanBtn.setOnClickListener(v->runScanner());
  }

  private void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,9001);}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=9001||result!=RESULT_OK||data==null||data.getData()==null)return;try{Uri u=data.getData();uploadedChart=MediaStore.Images.Media.getBitmap(getContentResolver(),u);visualInfo.setText(ChartVisualContext.describe(uploadedChart));}catch(Exception e){visualInfo.setText("Could not read chart screenshot: "+e.getMessage());}}
  private String selected(){return pairSpinner==null?"EURUSD":String.valueOf(pairSpinner.getSelectedItem());}
  private void runScanner(){final String sym=selected();scannerResult.setText("CPD Scanner is checking M5 • M15 • H1 • H4 for "+sym+"…");io.execute(()->{CPDScannerEngine.ScanResult r=CPDScannerEngine.scan(sym,market,uploadedChart!=null);runOnUiThread(()->scannerResult.setText(scannerText(r)));});}
  private String scannerText(CPDScannerEngine.ScanResult r){return "PAIR: "+r.symbol+"\n\nM5   → "+r.timeframes[3]+"\nM15  → "+r.timeframes[2]+"\nH1   → "+r.timeframes[1]+"\nH4   → "+r.timeframes[0]+"\n\nDIRECTION: "+r.direction+"\nENTRY: "+r.entry+"\nSTOP LOSS: "+r.sl+"\nTAKE PROFIT: "+r.tp+"\nCONFIDENCE: "+String.format(Locale.US,"%.0f%%",r.confidence)+"\n\nREASON\n"+r.reason;}

  private void scanNormal(){final String sym=selected();io.execute(()->{try{List<StrategyEngine.Candle> h4=list(market.candles(sym,"4h",250)),h1=list(market.candles(sym,"1h",250)),m15=list(market.candles(sym,"15m",160)),m5=list(market.candles(sym,"5m",160));org.json.JSONObject p=market.price(sym);StrategyEngine.Signal s=new StrategyEngine().evaluate(sym,h4,h1,m15,m5,p.optDouble("bid"),p.optDouble("ask"),false);if(s.valid){lastNormalSignal=s;runOnUiThread(()->{status.setText("NORMAL AUTO • SIGNAL READY • "+sym+" • LIVE LOCKED");Toast.makeText(this,"Normal signal generated. Open MANUAL to copy it.",Toast.LENGTH_LONG).show();});}else runOnUiThread(()->status.setText("NORMAL AUTO • WAIT • NO QUALIFIED "+sym+" SETUP"));}catch(Exception e){runOnUiThread(()->status.setText("NORMAL AUTO • DATA ERROR • LIVE LOCKED"));}});}
  private List<StrategyEngine.Candle> list(org.json.JSONArray a){List<StrategyEngine.Candle> r=new ArrayList<>();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null)r.add(new StrategyEngine.Candle(a.optJSONObject(i)));return r;}
  private String format(StrategyEngine.Signal s){return "🚨 C.P.D SUPER WIZARD AI SIGNAL\n\n💱 "+s.symbol+"\n📊 "+(s.dir>0?"BUY":"SELL")+"\n\n🎯 Entry: "+fmt(s.entry)+"\n🛑 Stop Loss: "+fmt(s.sl)+"\n💰 TP1: "+fmt(s.tp1)+"\n💰 TP2: "+fmt(s.tp2)+"\n💰 TP3: "+fmt(s.tp3)+"\n💰 Final TP: "+fmt(s.tp)+"\n\n🧠 Confidence: "+String.format(Locale.US,"%.0f/95",s.confidence)+"\n⚙️ Mode: NORMAL\n\n📌 Analysis:\n• Pattern: "+s.pattern+" ("+s.patternQuality+")\n• S/R: "+s.sr+" ("+s.srQuality+")\n• Breakout: "+s.breakout+"\n• "+s.reason+"\n\n⚠️ Trade with proper risk management.";}
  private void copySignal(){if(lastNormalSignal==null){Toast.makeText(this,"No Normal Auto signal to copy.",Toast.LENGTH_SHORT).show();return;}((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("CPD Normal Signal",format(lastNormalSignal)));Toast.makeText(this,"Normal signal copied for Telegram.",Toast.LENGTH_SHORT).show();}
  private String fmt(double x){return String.format(Locale.US,"%.5f",x);}
  @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
